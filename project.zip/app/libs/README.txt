CI places sherpa-onnx-1.13.7.aar here
