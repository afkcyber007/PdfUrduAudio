package com.haji.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final int REQ_PDF = 1;

    private ListView list;
    private View emptyView, overlay, continueCard;
    private TextView overlayText, continueTitle, continueSub;
    private ProgressBar continueProgress;
    private final List<Book> books = new ArrayList<>();
    private BookAdapter adapter;
    private SharedPreferences prefs;
    private Book lastBook;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Ui.edgeToEdge(this, findViewById(R.id.header));
        prefs = getSharedPreferences("haji", MODE_PRIVATE);

        list = findViewById(R.id.list);
        emptyView = findViewById(R.id.empty);
        overlay = findViewById(R.id.overlay);
        overlayText = findViewById(R.id.overlayText);
        continueCard = findViewById(R.id.continueCard);
        continueTitle = findViewById(R.id.continueTitle);
        continueSub = findViewById(R.id.continueSub);
        continueProgress = findViewById(R.id.continueProgress);

        adapter = new BookAdapter();
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> openPlayer(books.get(pos).id, false));
        list.setOnItemLongClickListener((p, v, pos, id) -> { confirmDelete(books.get(pos)); return true; });

        findViewById(R.id.addBtn).setOnClickListener(v -> pickPdf());
        findViewById(R.id.settingsBtn).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        findViewById(R.id.videoBtn).setOnClickListener(v -> startActivity(new Intent(this, DubActivity.class)));
        findViewById(R.id.emptyAdd).setOnClickListener(v -> pickPdf());
        continueCard.setOnClickListener(v -> { if (lastBook != null) openPlayer(lastBook.id, false); });
        findViewById(R.id.continuePlay).setOnClickListener(v -> { if (lastBook != null) openPlayer(lastBook.id, true); });

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        books.clear();
        books.addAll(Book.listAll(this));
        adapter.notifyDataSetChanged();
        emptyView.setVisibility(books.isEmpty() ? View.VISIBLE : View.GONE);
        list.setVisibility(books.isEmpty() ? View.GONE : View.VISIBLE);

        lastBook = null;
        String last = prefs.getString("last", null);
        for (Book b : books) if (b.id.equals(last)) lastBook = b;
        if (lastBook != null) {
            continueCard.setVisibility(View.VISIBLE);
            continueTitle.setText(lastBook.title);
            continueSub.setText(lastBook.percent() + "% suni gayi • Jaari rakhein");
            continueProgress.setMax(100);
            continueProgress.setProgress(lastBook.percent());
        } else {
            continueCard.setVisibility(View.GONE);
        }
    }

    private void pickPdf() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/pdf");
        startActivityForResult(i, REQ_PDF);
    }

    private void openPlayer(String id, boolean autoplay) {
        startActivity(new Intent(this, PlayerActivity.class)
                .putExtra(PlayerActivity.EXTRA_ID, id)
                .putExtra(PlayerActivity.EXTRA_AUTOPLAY, autoplay));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PDF || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        final Uri uri = data.getData();
        try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (Exception ignored) { }
        // Ask the book's language first (target is always Urdu; an Urdu book is never translated).
        android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        int pad = Ui.dp(this, 20);
        box.setPadding(pad, Ui.dp(this, 8), pad, 0);
        final android.widget.RadioGroup group = new android.widget.RadioGroup(this);
        for (int i = 0; i < Lang.SOURCES.length; i++) {
            android.widget.RadioButton rb = new android.widget.RadioButton(this);
            rb.setId(500 + i);
            rb.setText(Lang.SOURCE_LABELS[i]);
            rb.setTextSize(15);
            rb.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6));
            group.addView(rb);
        }
        group.check(500);
        box.addView(group);
        final android.widget.CheckBox ocrBox = new android.widget.CheckBox(this);
        ocrBox.setText("OCR se parhein (agar Urdu text ajeeb zubaan main aaye ya scan PDF ho)");
        ocrBox.setPadding(0, Ui.dp(this, 10), 0, 0);
        box.addView(ocrBox);
        android.widget.TextView hint = new android.widget.TextView(this);
        hint.setText(Models.ocrLangs(this, Lang.AUTO) == null
                ? "OCR ke liye pehle Settings → OCR se \"OCR Urdu\" download karein."
                : "Kharab text wale safhe app khud OCR se parhti hai.");
        hint.setTextSize(12);
        hint.setTextColor(0xFF7A7296);
        box.addView(hint);
        new AlertDialog.Builder(this)
                .setTitle("Kitaab ki asal zubaan?")
                .setView(box)
                .setPositiveButton("Shamil karein", (d, w) -> {
                    int idx = Math.max(0, group.getCheckedRadioButtonId() - 500);
                    importBook(uri, Lang.SOURCES[idx], ocrBox.isChecked());
                })
                .setNegativeButton("Wapas", null)
                .show();
    }

    private volatile boolean importCancelled;

    private void importBook(Uri uri, String src, boolean forceOcr) {
        overlay.setVisibility(View.VISIBLE);
        overlayText.setText("PDF khul rahi hai…");
        importCancelled = false;
        overlay.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setMessage("Kitaab shamil karna rokain?")
                .setPositiveButton("Rokain", (d, w) -> importCancelled = true)
                .setNegativeButton("Nahi", null).show());
        new Thread(() -> {
            try {
                final Book b = PdfImporter.importPdf(this, uri, src, forceOcr, new PdfImporter.Progress() {
                    @Override public void onProgress(String m) { runOnUiThread(() -> overlayText.setText(m)); }
                    @Override public boolean cancelled() { return importCancelled; }
                });
                runOnUiThread(() -> {
                    overlay.setVisibility(View.GONE);
                    if (b.missingPages > 0) {
                        Toast.makeText(this, b.missingPages + " safhon main text nahi mila (scan). Settings → OCR se OCR model download karein.",
                                Toast.LENGTH_LONG).show();
                    }
                    openPlayer(b.id, false);
                });
            } catch (Throwable e) {
                final String msg = e instanceof OutOfMemoryError
                        ? "Yeh PDF bohat bari hai, phone ki memory kam par gayi."
                        : String.valueOf(e.getMessage());
                runOnUiThread(() -> {
                    overlay.setVisibility(View.GONE);
                    new AlertDialog.Builder(this)
                            .setTitle("Kitaab shamil nahi ho saki")
                            .setMessage(msg)
                            .setPositiveButton("Theek hai", null)
                            .show();
                });
            }
        }, "import").start();
    }

    private void confirmDelete(Book b) {
        new AlertDialog.Builder(this)
                .setTitle("Kitaab hatayen?")
                .setMessage("\"" + b.title + "\" library se hata di jayegi.")
                .setPositiveButton("Hatayen", (d, w) -> {
                    ReaderService s = ReaderService.instance;
                    if (s != null && s.book == b) s.close();
                    b.delete();
                    refresh();
                })
                .setNegativeButton("Nahi", null)
                .show();
    }

    private class BookAdapter extends BaseAdapter {
        @Override public int getCount() { return books.size(); }
        @Override public Object getItem(int p) { return books.get(p); }
        @Override public long getItemId(int p) { return p; }

        @Override
        public View getView(int pos, View v, ViewGroup parent) {
            if (v == null) v = LayoutInflater.from(MainActivity.this).inflate(R.layout.item_book, parent, false);
            Book b = books.get(pos);
            TextView letter = v.findViewById(R.id.letter);
            TextView title = v.findViewById(R.id.title);
            TextView sub = v.findViewById(R.id.sub);
            ProgressBar prog = v.findViewById(R.id.prog);
            ImageView play = v.findViewById(R.id.playIcon);
            int[] colors = Ui.colorsFor(b.id);
            String t = b.title.isEmpty() ? "K" : b.title.substring(0, 1).toUpperCase();
            letter.setText(t);
            letter.setBackground(Ui.gradient(colors, Ui.dp(MainActivity.this, 16)));
            title.setText(b.title);
            sub.setText(b.pages + " safhe • " + Lang.label(b.src) + " • " + b.percent() + "%");
            prog.setMax(100);
            prog.setProgress(b.percent());
            play.setBackground(Ui.gradient(colors, Ui.dp(MainActivity.this, 22)));
            play.setOnClickListener(x -> openPlayer(b.id, true));
            return v;
        }
    }
}
