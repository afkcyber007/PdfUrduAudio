package com.haji.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Downloads optional models in the background (only when the user asked for it).
 * Job ids: a Models id (e.g. "piper_male") or "mlkit:<code>" for ML Kit translation models.
 */
public class DownloadService extends Service {

    private static final String CHANNEL = "downloads";
    private static final int NOTIF_ID = 9;

    static final ConcurrentLinkedQueue<String> queue = new ConcurrentLinkedQueue<>();
    static volatile String current;
    static volatile String label = "";
    static volatile long done, total;
    static volatile boolean cancelled;
    /** Last result per job id: "ok" or an error message. */
    static final java.util.Map<String, String> results = new java.util.concurrent.ConcurrentHashMap<>();

    private static volatile boolean worker;
    private NotificationManager nm;

    static void enqueue(Context c, String job) {
        if (job.equals(current) || queue.contains(job)) return;
        results.remove(job);
        queue.add(job);
        Intent i = new Intent(c, DownloadService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    static void cancelCurrent() { cancelled = true; }

    static boolean busy(String job) { return job.equals(current) || queue.contains(job); }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Model downloads", NotificationManager.IMPORTANCE_LOW));
        }
        Notification n = notif("Download shuru…", 0, 0);
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(NOTIF_ID, n);
        if (!worker) {
            worker = true;
            new Thread(this::work, "downloads").start();
        }
        return START_NOT_STICKY;
    }

    private void work() {
        try {
            String job;
            while ((job = queue.poll()) != null) {
                current = job;
                cancelled = false;
                done = 0;
                total = 0;
                try {
                    if (job.startsWith("mlkit:")) {
                        String code = job.substring(6);
                        label = "Tarjuma model: " + code;
                        nm.notify(NOTIF_ID, notif(label, 0, 0));
                        Translator.download(code);
                    } else {
                        final String jid = job;
                        Models.install(this, job, new Models.Progress() {
                            long last;
                            @Override public void onProgress(String l, long d, long t) {
                                label = l; done = d; total = t;
                                long now = System.currentTimeMillis();
                                if (now - last > 1000) {
                                    last = now;
                                    nm.notify(NOTIF_ID, notif(l + (t > 0 ? " — " + (d * 100 / t) + "%" : ""), d, t));
                                }
                            }
                            @Override public boolean cancelled() { return cancelled; }
                        });
                        if (cancelled) throw new java.io.IOException("cancelled");
                        if (!Models.installed(this, jid)) throw new java.io.IOException("Install mukammal nahi hua");
                    }
                    results.put(job, "ok");
                } catch (Throwable e) {
                    String m = e.getMessage() == null ? e.toString() : e.getMessage();
                    if (cancelled || "cancelled".equals(m)) {
                        results.put(job, "Download rok diya gaya");
                    } else {
                        results.put(job, m);
                    }
                    if (!job.startsWith("mlkit:")) {
                        // Remove half-downloaded files so a broken model is never shown as installed.
                        Models.delete(this, job);
                    }
                }
                current = null;
            }
        } finally {
            current = null;
            worker = false;
            stopForeground(Service.STOP_FOREGROUND_REMOVE);
            stopSelf();
        }
    }

    private Notification notif(String text, long d, long t) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, SettingsActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        b.setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("HAJI APP — Download")
                .setContentText(text)
                .setContentIntent(pi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setColor(0xFF7B2FF7);
        int max = t > 0 ? 1000 : 0;
        int prog = t > 0 ? (int) (d * 1000 / t) : 0;
        b.setProgress(max, prog, t <= 0);
        return b.build();
    }
}
