package com.haji.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Settings: voice, translation engine, Arabic handling, optional model downloads, storage. */
public class SettingsActivity extends Activity {

    private LinearLayout body;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final List<Row> rows = new ArrayList<>();
    private final Map<String, Boolean> mlkitState = new java.util.concurrent.ConcurrentHashMap<>();
    private RadioGroup voiceGroup;
    private TextView storageText;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            for (Row r : rows) r.update();
            h.postDelayed(this, 700);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout rootL = new LinearLayout(this);
        rootL.setOrientation(LinearLayout.VERTICAL);
        rootL.setBackgroundColor(0xFFF6F2FF);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundResource(R.drawable.bg_topbar);
        top.setPadding(dp(6), dp(8), dp(16), dp(16));
        android.widget.ImageView back = new android.widget.ImageView(this);
        back.setImageResource(R.drawable.ic_back);
        back.setPadding(dp(12), dp(12), dp(12), dp(12));
        back.setOnClickListener(v -> finish());
        top.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        TextView t = new TextView(this);
        t.setText("Settings");
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(20);
        t.setTypeface(null, Typeface.BOLD);
        top.addView(t);
        rootL.addView(top);
        Ui.edgeToEdge(this, top);

        ScrollView sv = new ScrollView(this);
        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(8), dp(14), dp(40));
        sv.addView(body);
        rootL.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(rootL);

        buildVoice();
        buildTranslation();
        buildArabic();

        header("Offline Urdu awaazein (Piper)");
        note("Har awaaz ~60 MB + ek dafa ~7 MB talaffuz data. Download ke baad internet ke baghair chalti hain.");
        rows.add(new ModelRow(Models.VOICE_MALE));
        rows.add(new ModelRow(Models.VOICE_FEMALE));

        header("Tarjuma models (on-device, Google ML Kit)");
        note("Kitaab ka tarjuma phone par hi hota hai — text kahin nahi bheja jata. Har zubaan ~30 MB. "
                + "Urdu model har tarjume ke liye zaroori hai.");
        for (String l : Translator.MLKIT_LANGS) rows.add(new MlkitRow(l));

        header("OCR (scan / tasveer wali PDF)");
        note("Tesseract OCR. Urdu Nastaliq scan par OCR ki ghaltiyan ho sakti hain.");
        rows.add(new ModelRow(Models.OCR_URD));
        rows.add(new ModelRow(Models.OCR_ARA));
        rows.add(new ModelRow(Models.OCR_FAS));
        rows.add(new ModelRow(Models.OCR_ENG));

        header("Video dubbing: awaaz → text (Whisper)");
        note("Video ki baat-cheet ko text banata hai (offline). Urdu par Whisper ki durustgi mehdood hai.");
        rows.add(new ModelRow(Models.ASR_TINY));
        rows.add(new ModelRow(Models.ASR_BASE));

        header("Storage");
        storageText = note("");
        Button clear = button("Temporary files saaf karein", v -> {
            Models.rm(new File(getCacheDir(), "audio"));
            Models.rm(new File(getCacheDir(), "dubwork"));
            Toast.makeText(this, "Saaf ho gaya", Toast.LENGTH_SHORT).show();
            updateStorage();
        });
        body.addView(clear);

        new Thread(this::loadMlkitState, "mlkit-state").start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        h.post(tick);
        updateStorage();
        refreshVoiceGroup();
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
        ReaderService s = ReaderService.instance;
        if (s != null) s.settingsChanged();
    }

    // ------------------------------------------------------------- sections

    private void buildVoice() {
        header("Awaaz (kitaab parhne ke liye)");
        voiceGroup = new RadioGroup(this);
        String[] ids = {Prefs.VOICE_GOOGLE, Prefs.VOICE_MALE, Prefs.VOICE_FEMALE, Prefs.VOICE_PHONE};
        for (int i = 0; i < ids.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(1000 + i);
            rb.setTag(ids[i]);
            rb.setTextSize(15);
            voiceGroup.addView(rb);
        }
        voiceGroup.setOnCheckedChangeListener((g, checked) -> {
            View v = g.findViewById(checked);
            if (v == null) return;
            String id = (String) v.getTag();
            if ((Prefs.VOICE_MALE.equals(id) || Prefs.VOICE_FEMALE.equals(id)) && !Models.voiceInstalled(this, id)) return;
            Prefs.setVoice(this, id);
        });
        card(voiceGroup);
    }

    private void refreshVoiceGroup() {
        String cur = Prefs.voice(this);
        for (int i = 0; i < voiceGroup.getChildCount(); i++) {
            RadioButton rb = (RadioButton) voiceGroup.getChildAt(i);
            String id = (String) rb.getTag();
            boolean piper = Prefs.VOICE_MALE.equals(id) || Prefs.VOICE_FEMALE.equals(id);
            boolean ok = !piper || Models.voiceInstalled(this, id);
            String extra = Prefs.VOICE_GOOGLE.equals(id) ? "  — internet chahiye"
                    : Prefs.VOICE_PHONE.equals(id) ? "  — phone ka TTS engine"
                    : ok ? "  — installed ✓" : "  — pehle neeche download karein";
            rb.setText(Prefs.voiceLabel(id) + extra);
            rb.setEnabled(ok);
            if (id.equals(cur)) rb.setChecked(true);
        }
    }

    private void buildTranslation() {
        header("Tarjuma kaise ho");
        RadioGroup g = new RadioGroup(this);
        RadioButton a = new RadioButton(this);
        a.setId(2001);
        a.setText("Phone par (offline, private) — ML Kit models chahiye");
        RadioButton b = new RadioButton(this);
        b.setId(2002);
        b.setText("Online Google Translate — text Google ko jata hai");
        g.addView(a);
        g.addView(b);
        g.check(Prefs.TR_GOOGLE.equals(Prefs.trEngine(this)) ? 2002 : 2001);
        g.setOnCheckedChangeListener((grp, id) -> {
            if (id == 2001) { Prefs.setTrEngine(this, Prefs.TR_MLKIT); return; }
            if (Prefs.googleConsent(this)) { Prefs.setTrEngine(this, Prefs.TR_GOOGLE); return; }
            new AlertDialog.Builder(this)
                    .setTitle("Online tarjuma?")
                    .setMessage("Is option main aap ki kitaab ka text Google Translate ke server par bheja jayega. "
                            + "Private kitaab ke liye 'Phone par' wala option behtar hai.\n\nKya aap raazi hain?")
                    .setPositiveButton("Haan, raazi hoon", (d, w) -> {
                        Prefs.setGoogleConsent(this, true);
                        Prefs.setTrEngine(this, Prefs.TR_GOOGLE);
                    })
                    .setNegativeButton("Nahi", (d, w) -> grp.check(2001))
                    .setOnCancelListener(d -> grp.check(2001))
                    .show();
        });
        card(g);
    }

    private void buildArabic() {
        header("Urdu kitaab main Arabic ibaarat (Quran / Hadith)");
        RadioGroup g = new RadioGroup(this);
        RadioButton a = new RadioButton(this);
        a.setId(3001);
        a.setText("Arabic ko waise hi parhein, tarjuma na karein (default)");
        RadioButton b = new RadioButton(this);
        b.setId(3002);
        b.setText("Sirf woh Arabic tarjuma karein jis ke foran baad Urdu tarjuma na likha ho");
        g.addView(a);
        g.addView(b);
        g.check(Lang.ARABIC_TRANSLATE_IF_ALONE.equals(Prefs.arabicMode(this)) ? 3002 : 3001);
        g.setOnCheckedChangeListener((grp, id) ->
                Prefs.setArabicMode(this, id == 3002 ? Lang.ARABIC_TRANSLATE_IF_ALONE : Lang.ARABIC_KEEP));
        card(g);
        note("Jab kitaab ki zubaan 'Arabic' chuni ho to Arabic hamesha Urdu main tarjuma hota hai. Urdu text kabhi tarjuma ya tabdeel nahi hota.");
    }

    private void updateStorage() {
        long models = Models.du(Models.root(this));
        long cache = Models.du(getCacheDir());
        long books = Models.du(Book.root(this));
        storageText.setText("Models: " + Models.mb(models) + "  •  Kitaabein: " + Models.mb(books)
                + "  •  Temporary: " + Models.mb(cache) + "\nPhone main khaali jagah: " + Models.mb(Models.freeBytes(this)));
    }

    private void loadMlkitState() {
        for (String l : Translator.MLKIT_LANGS) {
            String code = Translator.mlkitCode(l);
            mlkitState.put(code, Translator.isDownloaded(code));
        }
    }

    // ------------------------------------------------------------- rows

    private abstract class Row {
        final TextView title, status;
        final Button btn;
        final ProgressBar bar;

        Row(String t, String desc) {
            LinearLayout box = new LinearLayout(SettingsActivity.this);
            box.setOrientation(LinearLayout.VERTICAL);
            title = new TextView(SettingsActivity.this);
            title.setText(t);
            title.setTextColor(0xFF2D1B69);
            title.setTextSize(16);
            title.setTypeface(null, Typeface.BOLD);
            box.addView(title);
            TextView d = new TextView(SettingsActivity.this);
            d.setText(desc);
            d.setTextColor(0xFF7A7296);
            d.setTextSize(12);
            box.addView(d);
            status = new TextView(SettingsActivity.this);
            status.setTextSize(13);
            status.setPadding(0, dp(4), 0, 0);
            box.addView(status);
            bar = new ProgressBar(SettingsActivity.this, null, android.R.attr.progressBarStyleHorizontal);
            bar.setProgressDrawable(getDrawable(R.drawable.bg_progress));
            bar.setMax(1000);
            bar.setVisibility(View.GONE);
            box.addView(bar, new LinearLayout.LayoutParams(-1, dp(8)));
            btn = new Button(SettingsActivity.this);
            btn.setAllCaps(false);
            btn.setOnClickListener(v -> click());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
            lp.topMargin = dp(4);
            box.addView(btn, lp);
            card(box);
        }

        abstract void click();
        abstract void update();
    }

    private class ModelRow extends Row {
        final String id;

        ModelRow(String id) {
            super(Models.ALL.get(id).title, Models.ALL.get(id).desc + "\nLicense: " + Models.ALL.get(id).license);
            this.id = id;
            update();
        }

        @Override void click() {
            if (DownloadService.busy(id)) {
                if (id.equals(DownloadService.current)) DownloadService.cancelCurrent();
                else DownloadService.queue.remove(id);
                return;
            }
            if (Models.installed(SettingsActivity.this, id)) {
                new AlertDialog.Builder(SettingsActivity.this)
                        .setTitle("Delete karein?")
                        .setMessage(Models.ALL.get(id).title + " (" + Models.mb(Models.sizeOnDisk(SettingsActivity.this, id)) + ") phone se hata diya jayega.")
                        .setPositiveButton("Delete", (d, w) -> {
                            if (id.equals(Prefs.voice(SettingsActivity.this))) Prefs.setVoice(SettingsActivity.this, Prefs.VOICE_GOOGLE);
                            if (Models.VOICE_MALE.equals(id) || Models.VOICE_FEMALE.equals(id)) PiperVoice.release();
                            Models.delete(SettingsActivity.this, id);
                            refreshVoiceGroup();
                            updateStorage();
                        })
                        .setNegativeButton("Nahi", null).show();
                return;
            }
            long need = Models.neededBytes(SettingsActivity.this, id);
            long dl = 0;
            for (Models.FileSpec f : Models.ALL.get(id).files) dl += f.approxBytes;
            for (String r : Models.ALL.get(id).requires) if (!Models.installed(SettingsActivity.this, r)) dl += Models.ALL.get(r).approxBytes();
            new AlertDialog.Builder(SettingsActivity.this)
                    .setTitle("Download karein?")
                    .setMessage(Models.ALL.get(id).title + "\n\nDownload: ~" + Models.mb(dl)
                            + "\nZaroori khaali jagah: ~" + Models.mb(need)
                            + "\nAap ke phone main khaali: " + Models.mb(Models.freeBytes(SettingsActivity.this))
                            + "\n\nWi-Fi par download behtar hai.")
                    .setPositiveButton("Download", (d, w) -> DownloadService.enqueue(SettingsActivity.this, id))
                    .setNegativeButton("Nahi", null).show();
        }

        @Override void update() {
            boolean inst = Models.installed(SettingsActivity.this, id);
            if (id.equals(DownloadService.current)) {
                long d = DownloadService.done, t = DownloadService.total;
                status.setTextColor(0xFF7B2FF7);
                status.setText(DownloadService.label + (t > 0 ? "  " + Models.mb(d) + " / " + Models.mb(t) : ""));
                bar.setVisibility(View.VISIBLE);
                bar.setIndeterminate(t <= 0);
                if (t > 0) bar.setProgress((int) (d * 1000 / t));
                btn.setText("Rokain");
            } else if (DownloadService.queue.contains(id)) {
                status.setTextColor(0xFF7B2FF7);
                status.setText("Line main hai…");
                bar.setVisibility(View.GONE);
                btn.setText("Hatayen");
            } else {
                bar.setVisibility(View.GONE);
                String res = DownloadService.results.get(id);
                if (inst) {
                    status.setTextColor(0xFF11998E);
                    status.setText("✓ Installed • " + Models.mb(Models.sizeOnDisk(SettingsActivity.this, id)));
                    btn.setText("Delete");
                } else if (res != null && !"ok".equals(res)) {
                    status.setTextColor(0xFFD32F2F);
                    status.setText("Masla: " + res);
                    btn.setText("Dobara download");
                } else {
                    status.setTextColor(0xFF7A7296);
                    status.setText("Install nahi • download ~" + Models.mb(Models.ALL.get(id).approxBytes()));
                    btn.setText("Download");
                }
                if ("ok".equals(res)) { DownloadService.results.remove(id); refreshVoiceGroup(); updateStorage(); }
            }
        }
    }

    private class MlkitRow extends Row {
        final String code;
        final String job;

        MlkitRow(String lang) {
            super("Tarjuma: " + Translator.langName(lang), "Google ML Kit on-device model • ~30 MB");
            code = Translator.mlkitCode(lang);
            job = "mlkit:" + code;
            update();
        }

        @Override void click() {
            if (DownloadService.busy(job)) return;
            Boolean st = mlkitState.get(code);
            if (st != null && st) {
                new Thread(() -> {
                    try { Translator.delete(code); mlkitState.put(code, false); }
                    catch (Exception e) { runOnUiThread(() -> Toast.makeText(this_(), e.getMessage(), Toast.LENGTH_LONG).show()); }
                }).start();
                return;
            }
            new AlertDialog.Builder(SettingsActivity.this)
                    .setTitle("Download karein?")
                    .setMessage(title.getText() + " model (~30 MB) download hoga.")
                    .setPositiveButton("Download", (d, w) -> DownloadService.enqueue(SettingsActivity.this, job))
                    .setNegativeButton("Nahi", null).show();
        }

        @Override void update() {
            if (DownloadService.busy(job)) {
                status.setTextColor(0xFF7B2FF7);
                status.setText(job.equals(DownloadService.current) ? "Download ho raha hai…" : "Line main hai…");
                bar.setVisibility(View.VISIBLE);
                bar.setIndeterminate(true);
                btn.setText("Intezar…");
                return;
            }
            bar.setVisibility(View.GONE);
            String res = DownloadService.results.remove(job);
            if ("ok".equals(res)) mlkitState.put(code, true);
            else if (res != null) Toast.makeText(SettingsActivity.this, res, Toast.LENGTH_LONG).show();
            Boolean st = mlkitState.get(code);
            if (st == null) { status.setText("Check ho raha hai…"); btn.setText("…"); }
            else if (st) { status.setTextColor(0xFF11998E); status.setText("✓ Installed"); btn.setText("Delete"); }
            else { status.setTextColor(0xFF7A7296); status.setText("Install nahi"); btn.setText("Download"); }
        }
    }

    private SettingsActivity this_() { return this; }

    // ------------------------------------------------------------- tiny view helpers

    private int dp(float v) { return Ui.dp(this, v); }

    private void header(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(0xFF2D1B69);
        t.setTextSize(18);
        t.setTypeface(null, Typeface.BOLD);
        t.setPadding(dp(6), dp(20), dp(6), dp(6));
        body.addView(t);
    }

    private TextView note(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(0xFF7A7296);
        t.setTextSize(13);
        t.setPadding(dp(6), 0, dp(6), dp(6));
        body.addView(t);
        return t;
    }

    private void card(View v) {
        LinearLayout c = new LinearLayout(this);
        c.setBackgroundResource(R.drawable.bg_card);
        c.setElevation(dp(2));
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        c.addView(v, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(6);
        lp.bottomMargin = dp(4);
        body.addView(c, lp);
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }
}
