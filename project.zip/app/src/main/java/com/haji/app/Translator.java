package com.haji.app;

import android.content.Context;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.common.model.RemoteModelManager;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.TranslateRemoteModel;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Translation to Urdu.
 *  - Default: Google ML Kit on-device translation (text never leaves the phone; models downloaded only
 *    when the user taps Download in Settings).
 *  - Optional: Google Translate online, only after the user agreed that text is sent to Google.
 */
final class Translator {
    private Translator() { }

    /** Thrown when an on-device language model is not downloaded yet (message is user-facing). */
    static final class ModelMissing extends IOException {
        ModelMissing(String msg) { super(msg); }
    }

    /** Languages offered for on-device translation (source → Urdu). */
    static final String[] MLKIT_LANGS = {Lang.UR, Lang.EN, Lang.AR, Lang.FA, "hi"};

    private static final Map<String, com.google.mlkit.nl.translate.Translator> clients = new HashMap<>();

    static String mlkitCode(String lang) {
        if (lang == null) return null;
        switch (lang) {
            case Lang.UR: return TranslateLanguage.URDU;
            case Lang.EN: return TranslateLanguage.ENGLISH;
            case Lang.AR: return TranslateLanguage.ARABIC;
            case Lang.FA: return TranslateLanguage.PERSIAN;
            case "hi": return TranslateLanguage.HINDI;
            default: return TranslateLanguage.fromLanguageTag(lang);
        }
    }

    static String langName(String lang) {
        if ("hi".equals(lang)) return "Hindi";
        return Lang.label(lang);
    }

    /** Translate texts from {@code from} into Urdu with the engine chosen in Settings. Blocking. */
    static List<String> toUrdu(Context c, List<String> texts, String from, Net.Cancel cancel) throws IOException {
        if (Prefs.TR_GOOGLE.equals(Prefs.trEngine(c))) {
            return Net.translateBatch(texts, from, cancel);
        }
        List<String> out = new ArrayList<>();
        com.google.mlkit.nl.translate.Translator t = mlkit(c, from);
        for (String s : texts) {
            if (cancel != null && cancel.cancelled()) throw new IOException("cancelled");
            try {
                out.add(Tasks.await(t.translate(s), 60, TimeUnit.SECONDS));
            } catch (Exception e) {
                throw new IOException("On-device tarjuma fail hua: " + e.getMessage());
            }
        }
        return out;
    }

    static String toUrdu(Context c, String text, String from, Net.Cancel cancel) throws IOException {
        List<String> l = new ArrayList<>();
        l.add(text);
        return toUrdu(c, l, from, cancel).get(0);
    }

    private static synchronized com.google.mlkit.nl.translate.Translator mlkit(Context c, String from) throws IOException {
        String src = mlkitCode(from);
        if (src == null) throw new IOException(langName(from) + " ka on-device tarjuma maujood nahi");
        List<String> missing = new ArrayList<>();
        if (!isDownloaded(src)) missing.add(langName(from));
        if (!isDownloaded(TranslateLanguage.URDU)) missing.add("Urdu");
        if (!missing.isEmpty()) {
            throw new ModelMissing("Tarjume ke liye ye model download karein: " + android.text.TextUtils.join(", ", missing)
                    + "\nSettings → Tarjuma models (har ek ~30 MB)");
        }
        com.google.mlkit.nl.translate.Translator t = clients.get(src);
        if (t == null) {
            t = Translation.getClient(new TranslatorOptions.Builder()
                    .setSourceLanguage(src)
                    .setTargetLanguage(TranslateLanguage.URDU)
                    .build());
            clients.put(src, t);
        }
        return t;
    }

    // ------------------------------------------------------------- model management (Settings)

    static boolean isDownloaded(String mlkitCode) {
        try {
            return Tasks.await(RemoteModelManager.getInstance()
                    .isModelDownloaded(new TranslateRemoteModel.Builder(mlkitCode).build()), 20, TimeUnit.SECONDS);
        } catch (Exception e) {
            return false;
        }
    }

    /** Blocking download of one language model. */
    static void download(String mlkitCode) throws IOException {
        try {
            Tasks.await(RemoteModelManager.getInstance().download(
                    new TranslateRemoteModel.Builder(mlkitCode).build(),
                    new DownloadConditions.Builder().build()), 30, TimeUnit.MINUTES);
        } catch (Exception e) {
            throw new IOException("Model download nahi hua: " + e.getMessage() + " (internet check karein)");
        }
    }

    static void delete(String mlkitCode) throws IOException {
        synchronized (Translator.class) {
            com.google.mlkit.nl.translate.Translator t = clients.remove(mlkitCode);
            if (t != null) t.close();
        }
        try {
            Tasks.await(RemoteModelManager.getInstance().deleteDownloadedModel(
                    new TranslateRemoteModel.Builder(mlkitCode).build()), 60, TimeUnit.SECONDS);
        } catch (Exception e) {
            throw new IOException("Model delete nahi hua: " + e.getMessage());
        }
    }
}
