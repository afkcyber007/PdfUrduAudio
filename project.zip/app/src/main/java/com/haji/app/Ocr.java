package com.haji.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.os.ParcelFileDescriptor;

import com.googlecode.tesseract.android.TessBaseAPI;

import java.io.File;
import java.io.IOException;

/** OCR for scanned PDF pages: Android PdfRenderer → bitmap → Tesseract (tessdata_fast). */
final class Ocr {
    private final ParcelFileDescriptor pfd;
    private final PdfRenderer renderer;
    private final TessBaseAPI tess;

    Ocr(Context c, File pdf, String langs) throws IOException {
        pfd = ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY);
        renderer = new PdfRenderer(pfd);
        tess = new TessBaseAPI();
        if (!tess.init(Models.tessDataPath(c), langs)) {
            tess.recycle();
            renderer.close();
            pfd.close();
            throw new IOException("OCR shuru nahi ho saka (" + langs + "). Settings main OCR model dobara download karein.");
        }
    }

    /** Text of one page (0-based). Returns "" if the page could not be rendered. */
    String page(int index) {
        if (index < 0 || index >= renderer.getPageCount()) return "";
        Bitmap bmp = null;
        try (PdfRenderer.Page page = renderer.openPage(index)) {
            int w = page.getWidth(), h = page.getHeight();
            float scale = Math.min(1800f / Math.max(1, w), 3.0f);  // ~200–300 dpi, bounded memory
            int bw = Math.max(1, Math.round(w * scale)), bh = Math.max(1, Math.round(h * scale));
            if ((long) bw * bh > 9_000_000L) { float f = (float) Math.sqrt(9_000_000.0 / ((long) bw * bh)); bw = (int) (bw * f); bh = (int) (bh * f); }
            bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
            bmp.eraseColor(Color.WHITE);
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT);
            tess.setImage(bmp);
            String t = tess.getUTF8Text();
            tess.clear();
            return dedupeLines(t == null ? "" : t);
        } catch (Throwable e) {
            return "";
        } finally {
            if (bmp != null) bmp.recycle();
        }
    }

    /** Remove lines that OCR produced twice in a row. */
    static String dedupeLines(String t) {
        StringBuilder sb = new StringBuilder();
        String prev = null;
        for (String l : t.split("\\r?\\n")) {
            String k = l.trim();
            if (k.isEmpty() || k.equals(prev)) continue;
            sb.append(l).append('\n');
            prev = k;
        }
        return sb.toString();
    }

    void close() {
        try { tess.recycle(); } catch (Throwable ignored) { }
        try { renderer.close(); } catch (Throwable ignored) { }
        try { pfd.close(); } catch (Throwable ignored) { }
    }
}
