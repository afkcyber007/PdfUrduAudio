package com.haji.app;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.Window;

final class Ui {
    private Ui() { }

    static final int[][] PALETTE = {
            {0xFF7B2FF7, 0xFFF107A3},
            {0xFFFF8A3D, 0xFFFF3D77},
            {0xFF00B4DB, 0xFF0083B0},
            {0xFF11998E, 0xFF38EF7D},
            {0xFFF7971E, 0xFFFFC107},
            {0xFF8E2DE2, 0xFF4A00E0},
    };

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    /** Draw behind the status bar and pad the colourful header so text stays visible. */
    @SuppressWarnings("deprecation")
    static void edgeToEdge(Activity a, View header) {
        Window w = a.getWindow();
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        w.setStatusBarColor(Color.TRANSPARENT);
        int id = a.getResources().getIdentifier("status_bar_height", "dimen", "android");
        int sb = id > 0 ? a.getResources().getDimensionPixelSize(id) : dp(a, 24);
        header.setPadding(header.getPaddingLeft(), header.getPaddingTop() + sb,
                header.getPaddingRight(), header.getPaddingBottom());
    }

    static GradientDrawable gradient(int[] colors, float radiusPx) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, colors);
        g.setCornerRadius(radiusPx);
        return g;
    }

    static int[] colorsFor(String key) {
        int h = Math.abs(key.hashCode());
        return PALETTE[h % PALETTE.length];
    }
}
