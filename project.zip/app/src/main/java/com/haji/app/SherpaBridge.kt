package com.haji.app

import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig
import com.k2fsa.sherpa.onnx.OfflineWhisperModelConfig
import com.k2fsa.sherpa.onnx.SileroVadModelConfig
import com.k2fsa.sherpa.onnx.Vad
import com.k2fsa.sherpa.onnx.VadModelConfig

/**
 * Thin Java-friendly wrapper around the sherpa-onnx Kotlin API (v1.13.7).
 * Named arguments keep this working even if later versions add new config fields.
 */
object SherpaBridge {

    // ---------------------------------------------------------------- TTS (Piper / VITS)

    @JvmStatic
    fun createTts(model: String, tokens: String, dataDir: String, threads: Int): OfflineTts {
        val config = OfflineTtsConfig(
            model = OfflineTtsModelConfig(
                vits = OfflineTtsVitsModelConfig(model = model, tokens = tokens, dataDir = dataDir),
                numThreads = threads,
                debug = false,
                provider = "cpu",
            ),
            maxNumSentences = 1,
        )
        return OfflineTts(assetManager = null, config = config)
    }

    @JvmStatic
    fun generate(tts: OfflineTts, text: String, speed: Float): FloatArray =
        tts.generate(text = text, sid = 0, speed = speed).samples

    @JvmStatic
    fun sampleRate(tts: OfflineTts): Int = tts.sampleRate()

    @JvmStatic
    fun release(tts: OfflineTts) = tts.release()

    // ---------------------------------------------------------------- ASR (Whisper)

    /** @param language "" = auto-detect, or a Whisper code like "ur", "en", "ar", "fa", "hi". */
    @JvmStatic
    fun createWhisper(encoder: String, decoder: String, tokens: String, language: String, threads: Int): OfflineRecognizer {
        val config = OfflineRecognizerConfig(
            featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
            modelConfig = OfflineModelConfig(
                whisper = OfflineWhisperModelConfig(
                    encoder = encoder,
                    decoder = decoder,
                    language = language,
                    task = "transcribe",
                ),
                tokens = tokens,
                numThreads = threads,
                modelType = "whisper",
                debug = false,
                provider = "cpu",
            ),
        )
        return OfflineRecognizer(assetManager = null, config = config)
    }

    /** Returns [text, detectedLanguage]. */
    @JvmStatic
    fun recognize(rec: OfflineRecognizer, samples: FloatArray): Array<String> {
        val stream = rec.createStream()
        try {
            stream.acceptWaveform(samples, 16000)
            rec.decode(stream)
            val r = rec.getResult(stream)
            return arrayOf(r.text, r.lang)
        } finally {
            stream.release()
        }
    }

    @JvmStatic
    fun release(rec: OfflineRecognizer) = rec.release()

    // ---------------------------------------------------------------- VAD (Silero)

    @JvmStatic
    fun createVad(model: String): Vad {
        val config = VadModelConfig(
            sileroVadModelConfig = SileroVadModelConfig(
                model = model,
                threshold = 0.5f,
                minSilenceDuration = 0.4f,
                minSpeechDuration = 0.25f,
                windowSize = 512,
                maxSpeechDuration = 20.0f,
            ),
            sampleRate = 16000,
            numThreads = 1,
        )
        return Vad(assetManager = null, config = config)
    }

    @JvmStatic
    fun vadAccept(vad: Vad, samples: FloatArray) = vad.acceptWaveform(samples)

    @JvmStatic
    fun vadFlush(vad: Vad) = vad.flush()

    @JvmStatic
    fun vadEmpty(vad: Vad): Boolean = vad.empty()

    /** Start sample index of the oldest detected speech segment. */
    @JvmStatic
    fun vadFrontStart(vad: Vad): Int = vad.front().start

    @JvmStatic
    fun vadFrontSamples(vad: Vad): FloatArray = vad.front().samples

    @JvmStatic
    fun vadPop(vad: Vad) = vad.pop()

    @JvmStatic
    fun release(vad: Vad) = vad.release()
}
