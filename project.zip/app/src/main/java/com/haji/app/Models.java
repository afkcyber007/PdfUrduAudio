package com.haji.app;

import android.content.Context;
import android.os.StatFs;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Catalog of optional downloadable models. Nothing is downloaded without the user tapping Download.
 * Each model lives in files/models/<id>/ and gets a ".ok" marker once fully installed.
 */
final class Models {
    private Models() { }

    static final String ESPEAK = "espeak";
    static final String VOICE_MALE = Prefs.VOICE_MALE;
    static final String VOICE_FEMALE = Prefs.VOICE_FEMALE;
    static final String VAD = "vad";
    static final String ASR_TINY = "asr_tiny";
    static final String ASR_BASE = "asr_base";
    static final String OCR_URD = "ocr_urd", OCR_ARA = "ocr_ara", OCR_FAS = "ocr_fas", OCR_ENG = "ocr_eng";

    static final class FileSpec {
        final String url, name;
        final long approxBytes;
        final boolean unzip;
        FileSpec(String url, String name, long approxBytes, boolean unzip) {
            this.url = url; this.name = name; this.approxBytes = approxBytes; this.unzip = unzip;
        }
    }

    static final class Model {
        final String id, title, desc, license, group;
        final List<FileSpec> files = new ArrayList<>();
        final List<String> requires = new ArrayList<>();
        Model(String id, String group, String title, String desc, String license) {
            this.id = id; this.group = group; this.title = title; this.desc = desc; this.license = license;
        }
        Model file(String url, String name, long bytes, boolean unzip) { files.add(new FileSpec(url, name, bytes, unzip)); return this; }
        Model needs(String id) { requires.add(id); return this; }
        long approxBytes() { long t = 0; for (FileSpec f : files) t += f.approxBytes; return t; }
    }

    private static final String HF = "https://huggingface.co/csukuangfj/";
    private static final String TESS = "https://github.com/tesseract-ocr/tessdata_fast/raw/main/";

    static final Map<String, Model> ALL = new LinkedHashMap<>();
    static {
        String vb = BuildConfig.VOICE_BASE;
        add(new Model(ESPEAK, "voice", "Piper zaroori data (espeak-ng)",
                "Piper awaazon ke liye talaffuz data. Awaaz ke saath khud download hota hai.", "GPL-3.0 (espeak-ng)")
                .file(vb + "espeak-ng-data.zip", "espeak.zip", 7_300_000L, true));
        add(new Model(VOICE_MALE, "voice", "Urdu Male — Fasih (Piper)",
                "ur_PK-fasih-medium • offline • 22 kHz", "MIT")
                .file(vb + "ur_PK-fasih-medium.zip", "voice.zip", 60_000_000L, true).needs(ESPEAK));
        add(new Model(VOICE_FEMALE, "voice", "Urdu Female — Aegis (Piper)",
                "ur_PK-aegis_female-medium • offline • 22 kHz", "MIT")
                .file(vb + "ur_PK-aegis_female-medium.zip", "voice.zip", 60_000_000L, true).needs(ESPEAK));
        add(new Model(VAD, "asr", "Silero VAD (awaaz ke hisse pehchanna)",
                "Video main bolne wale hisse alag karta hai. Whisper ke saath khud download hota hai.", "MIT")
                .file("https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/silero_vad.onnx",
                        "silero_vad.onnx", 650_000L, false));
        add(new Model(ASR_TINY, "asr", "Whisper Tiny (video ki awaaz → text)",
                "Multilingual • tez magar kam durust", "MIT (OpenAI Whisper)")
                .file(HF + "sherpa-onnx-whisper-tiny/resolve/main/tiny-encoder.int8.onnx", "encoder.onnx", 12_937_772L, false)
                .file(HF + "sherpa-onnx-whisper-tiny/resolve/main/tiny-decoder.int8.onnx", "decoder.onnx", 89_855_401L, false)
                .file(HF + "sherpa-onnx-whisper-tiny/resolve/main/tiny-tokens.txt", "tokens.txt", 816_730L, false)
                .needs(VAD));
        add(new Model(ASR_BASE, "asr", "Whisper Base (behtar, dheema)",
                "Multilingual • Tiny se behtar, 2–3 guna dheema", "MIT (OpenAI Whisper)")
                .file(HF + "sherpa-onnx-whisper-base/resolve/main/base-encoder.int8.onnx", "encoder.onnx", 29_120_534L, false)
                .file(HF + "sherpa-onnx-whisper-base/resolve/main/base-decoder.int8.onnx", "decoder.onnx", 130_672_026L, false)
                .file(HF + "sherpa-onnx-whisper-base/resolve/main/base-tokens.txt", "tokens.txt", 816_730L, false)
                .needs(VAD));
        add(ocr(OCR_URD, "urd", "Urdu", 1_400_000L));
        add(ocr(OCR_ARA, "ara", "Arabic", 1_500_000L));
        add(ocr(OCR_FAS, "fas", "Persian", 500_000L));
        add(ocr(OCR_ENG, "eng", "English", 4_100_000L));
    }

    private static Model ocr(String id, String code, String name, long bytes) {
        return new Model(id, "ocr", "OCR " + name + " (scan PDF)", "Tesseract tessdata_fast " + code, "Apache-2.0")
                .file(TESS + code + ".traineddata", code + ".traineddata", bytes, false);
    }

    private static void add(Model m) { ALL.put(m.id, m); }

    // ------------------------------------------------------------- paths & state

    static File root(Context c) {
        File r = new File(c.getFilesDir(), "models");
        r.mkdirs();
        return r;
    }

    static File dir(Context c, String id) {
        if (id.startsWith("ocr_")) return new File(root(c), "tessdata");
        return new File(root(c), id);
    }

    static boolean installed(Context c, String id) {
        Model m = ALL.get(id);
        if (m == null) return false;
        if (id.startsWith("ocr_")) return new File(dir(c, id), m.files.get(0).name).length() > 0;
        if (!new File(dir(c, id), ".ok").exists()) return false;
        for (String r : m.requires) if (!installed(c, r)) return false;
        return true;
    }

    static boolean voiceInstalled(Context c, String voice) { return installed(c, voice); }

    static long sizeOnDisk(Context c, String id) {
        if (id.startsWith("ocr_")) return new File(dir(c, id), ALL.get(id).files.get(0).name).length();
        return du(dir(c, id));
    }

    static long du(File f) {
        if (!f.exists()) return 0;
        if (f.isFile()) return f.length();
        long t = 0;
        File[] fs = f.listFiles();
        if (fs != null) for (File x : fs) t += du(x);
        return t;
    }

    static void delete(Context c, String id) {
        if (id.startsWith("ocr_")) new File(dir(c, id), ALL.get(id).files.get(0).name).delete();
        else rm(dir(c, id));
    }

    static void rm(File f) {
        if (f.isDirectory()) { File[] fs = f.listFiles(); if (fs != null) for (File x : fs) rm(x); }
        f.delete();
    }

    static long freeBytes(Context c) {
        try { return new StatFs(c.getFilesDir().getAbsolutePath()).getAvailableBytes(); }
        catch (Exception e) { return Long.MAX_VALUE; }
    }

    /** Space needed to install a model including not-yet-installed requirements (zip needs ~2x). */
    static long neededBytes(Context c, String id) {
        Model m = ALL.get(id);
        long t = 0;
        for (FileSpec f : m.files) t += f.unzip ? f.approxBytes * 2 : f.approxBytes;
        for (String r : m.requires) if (!installed(c, r)) t += neededBytes(c, r);
        return t;
    }

    static String mb(long bytes) {
        if (bytes < 1_000_000L) return Math.max(1, bytes / 1000) + " KB";
        return String.format(java.util.Locale.US, "%.1f MB", bytes / 1_000_000.0);
    }

    // ------------------------------------------------------------- paths used by engines

    static String piperModel(Context c, String voice) { return new File(dir(c, voice), "model.onnx").getAbsolutePath(); }
    static String piperTokens(Context c, String voice) { return new File(dir(c, voice), "tokens.txt").getAbsolutePath(); }
    static String espeakData(Context c) { return new File(dir(c, ESPEAK), "espeak-ng-data").getAbsolutePath(); }
    static String vadModel(Context c) { return new File(dir(c, VAD), "silero_vad.onnx").getAbsolutePath(); }
    static String asrFile(Context c, String id, String name) { return new File(dir(c, id), name).getAbsolutePath(); }
    static String tessDataPath(Context c) { return root(c).getAbsolutePath(); }

    static String ocrLangs(Context c, String src) {
        List<String> l = new ArrayList<>();
        String[][] pref;
        switch (src) {
            case Lang.UR: pref = new String[][]{{OCR_URD, "urd"}, {OCR_ARA, "ara"}}; break;
            case Lang.AR: pref = new String[][]{{OCR_ARA, "ara"}}; break;
            case Lang.FA: pref = new String[][]{{OCR_FAS, "fas"}}; break;
            case Lang.EN: pref = new String[][]{{OCR_ENG, "eng"}}; break;
            default: pref = new String[][]{{OCR_URD, "urd"}, {OCR_ENG, "eng"}, {OCR_ARA, "ara"}};
        }
        for (String[] p : pref) if (installed(c, p[0])) l.add(p[1]);
        if (l.isEmpty()) return null;
        return android.text.TextUtils.join("+", l);
    }

    // ------------------------------------------------------------- downloading (call off the main thread)

    interface Progress {
        void onProgress(String label, long done, long total);
        boolean cancelled();
    }

    static void install(Context c, String id, Progress p) throws IOException {
        Model m = ALL.get(id);
        if (m == null) throw new IOException("Unknown model");
        for (String r : m.requires) if (!installed(c, r)) install(c, r, p);
        long need = neededBytes(c, id);
        long free = freeBytes(c);
        if (free < need + 50_000_000L) {
            throw new IOException("Phone main jagah kam hai: " + mb(need) + " chahiye, sirf " + mb(free) + " khaali hai.");
        }
        File d = dir(c, id);
        d.mkdirs();
        for (FileSpec f : m.files) {
            File out = new File(d, f.name);
            File part = new File(d, f.name + ".part");
            fetch(f.url, part, m.title, p);
            if (p.cancelled()) { part.delete(); throw new IOException("cancelled"); }
            if (f.unzip) {
                unzip(part, d, m.title, p);
                part.delete();
            } else {
                out.delete();
                if (!part.renameTo(out)) throw new IOException("File save nahi hui");
            }
        }
        if (!id.startsWith("ocr_")) new FileOutputStream(new File(d, ".ok")).close();
    }

    private static void fetch(String url, File out, String label, Progress p) throws IOException {
        HttpURLConnection conn = null;
        for (int redirects = 0; redirects < 6; redirects++) {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setInstanceFollowRedirects(false);
            conn.setConnectTimeout(20000);
            conn.setReadTimeout(60000);
            conn.setRequestProperty("User-Agent", "HAJI-APP/3.0 (Android)");
            int code = conn.getResponseCode();
            if (code >= 300 && code < 400) {
                String loc = conn.getHeaderField("Location");
                conn.disconnect();
                if (loc == null) throw new IOException("Download redirect error");
                url = new URL(new URL(url), loc).toString();
                continue;
            }
            if (code == 404) throw new IOException("Model server par nahi mila (404). Shayad abhi publish nahi hua.");
            if (code != 200) throw new IOException("Download error " + code);
            break;
        }
        if (conn == null) throw new IOException("Download error");
        long total = conn.getContentLengthLong();
        long done = 0;
        try (InputStream in = new BufferedInputStream(conn.getInputStream());
             OutputStream os = new FileOutputStream(out)) {
            byte[] buf = new byte[65536];
            int r;
            long lastReport = 0;
            while ((r = in.read(buf)) != -1) {
                if (p.cancelled()) return;
                os.write(buf, 0, r);
                done += r;
                long now = System.currentTimeMillis();
                if (now - lastReport > 300) { p.onProgress(label, done, total); lastReport = now; }
            }
        } finally {
            conn.disconnect();
        }
        if (total > 0 && done != total) throw new IOException("Download adhoora raha — dobara koshish karein");
        p.onProgress(label, done, total);
    }

    private static void unzip(File zip, File dest, String label, Progress p) throws IOException {
        String base = dest.getCanonicalPath() + File.separator;
        try (ZipInputStream zin = new ZipInputStream(new BufferedInputStream(new java.io.FileInputStream(zip)))) {
            ZipEntry e;
            byte[] buf = new byte[65536];
            int count = 0;
            while ((e = zin.getNextEntry()) != null) {
                File f = new File(dest, e.getName());
                if (!f.getCanonicalPath().startsWith(base)) throw new IOException("Kharab zip file");
                if (e.isDirectory()) { f.mkdirs(); continue; }
                f.getParentFile().mkdirs();
                try (OutputStream os = new FileOutputStream(f)) {
                    int r;
                    while ((r = zin.read(buf)) != -1) os.write(buf, 0, r);
                }
                if (++count % 50 == 0) p.onProgress(label + " (khul raha hai)", count, -1);
                if (p.cancelled()) throw new IOException("cancelled");
            }
        }
    }
}
