package com.haji.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/** Video → Urdu dubbing. Local video is the main path; YouTube links get a clear explanation. */
public class DubActivity extends Activity {

    private static final int REQ_VIDEO = 21, REQ_SUBS = 22;
    private static final String[] SPEECH_CODES = {"", "ur", "en", "ar", "fa", "hi"};
    private static final String[] SPEECH_LABELS = {"Auto-detect", "Urdu", "English", "Arabic", "Persian", "Hindi"};

    private Uri video, subs;
    private TextView videoText, subsText, progressText;
    private ProgressBar progress;
    private Spinner speechSpin;
    private RadioGroup asrGroup, voiceGroup;
    private Button startBtn, cancelBtn;
    private LinearLayout listBox;
    private String lastResult;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() { updateProgress(); h.postDelayed(this, 600); }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF6F2FF);
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundResource(R.drawable.bg_topbar);
        top.setPadding(dp(6), dp(8), dp(16), dp(16));
        android.widget.ImageView back = new android.widget.ImageView(this);
        back.setImageResource(R.drawable.ic_back);
        back.setPadding(dp(12), dp(12), dp(12), dp(12));
        back.setOnClickListener(v -> finish());
        top.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        TextView t = new TextView(this);
        t.setText("Video → Urdu dubbing");
        t.setTextColor(0xFFFFFFFF);
        t.setTextSize(20);
        t.setTypeface(null, Typeface.BOLD);
        top.addView(t);
        root.addView(top);
        Ui.edgeToEdge(this, top);

        ScrollView sv = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(14), dp(8), dp(14), dp(40));
        sv.addView(body);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);

        // --- YouTube
        body.addView(header("YouTube link"));
        LinearLayout yt = vbox();
        EditText url = new EditText(this);
        url.setHint("https://youtube.com/…");
        url.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        yt.addView(url);
        yt.addView(button("Link check karein", v -> youtube(url.getText().toString().trim())));
        body.addView(card(yt));

        // --- Local video
        body.addView(header("Phone ki video (zaroori tareeqa)"));
        LinearLayout lv = vbox();
        lv.addView(button("📁  Local video chunain", v -> pick(REQ_VIDEO, "video/*")));
        videoText = small("Koi video nahi chuni");
        lv.addView(videoText);
        lv.addView(button("Subtitle file (SRT/VTT) — agar ho (optional)", v -> pick(REQ_SUBS, "*/*")));
        subsText = small("Subtitle nahi — awaaz se text Whisper banayega");
        lv.addView(subsText);
        lv.addView(small("Video main boli gayi zubaan:"));
        speechSpin = new Spinner(this);
        speechSpin.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, SPEECH_LABELS));
        lv.addView(speechSpin);
        lv.addView(small("Awaaz → text model:"));
        asrGroup = new RadioGroup(this);
        lv.addView(asrGroup);
        lv.addView(small("Urdu dubbing ki awaaz:"));
        voiceGroup = new RadioGroup(this);
        lv.addView(voiceGroup);
        startBtn = button("▶  Dubbing shuru karein", v -> start());
        lv.addView(startBtn);
        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setProgressDrawable(getDrawable(R.drawable.bg_progress));
        progress.setMax(100);
        lv.addView(progress, new LinearLayout.LayoutParams(-1, dp(8)));
        progressText = small("");
        lv.addView(progressText);
        cancelBtn = button("Rokain", v -> DubService.cancelled = true);
        lv.addView(cancelBtn);
        body.addView(card(lv));
        body.addView(small("Note: asal video kabhi badli ya delete nahi hoti. Lip-sync perfect nahi hota — har jumla "
                + "apne waqt par shuru hota hai, lamba ho to offline awaaz thori tez boli jati hai."));

        body.addView(header("Meri dubbed videos"));
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        body.addView(listBox);
        lastResult = DubService.result;
    }

    @Override
    protected void onResume() {
        super.onResume();
        fillChoices();
        refreshList();
        h.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
    }

    private void youtube(String u) {
        if (u.isEmpty()) { Toast.makeText(this, "Pehle link likhein", Toast.LENGTH_SHORT).show(); return; }
        boolean isYt = u.matches("(?i)^(https?://)?(www\\.|m\\.)?(youtube\\.com|youtu\\.be)/.+");
        String msg = isYt
                ? "YouTube ki official policy aur API ke mutabiq koi app doosron ki videos ki awaaz ya captions download "
                  + "nahi kar sakti (captions sirf video ka maalik download kar sakta hai). Is liye HAJI APP YouTube se "
                  + "kuch download nahi karti.\n\nKya karein:\n• Agar video aap ki apni hai ya aap ke paas uski file hai, "
                  + "to 'Local video chunain' se dubbing karein.\n• Agar aap ke paas video ki subtitle (SRT/VTT) file hai to "
                  + "woh bhi saath dein — is se Whisper ki zaroorat nahi rehti aur tarjuma behtar hota hai."
                : "Ye YouTube link nahi lagta. Phone main mehfooz video ke liye 'Local video chunain' istemal karein.";
        new AlertDialog.Builder(this).setTitle("YouTube link").setMessage(msg)
                .setPositiveButton("Local video chunain", (d, w) -> pick(REQ_VIDEO, "video/*"))
                .setNegativeButton("Theek hai", null).show();
    }

    private void pick(int req, String mime) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        startActivityForResult(i, req);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        Uri u = data.getData();
        try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
        catch (Exception ignored) { }
        if (req == REQ_VIDEO) {
            video = u;
            long d = AudioCodec.durationUs(this, u);
            videoText.setText("✓ " + PdfImporter.displayName(this, u) + (d > 0 ? "  (" + (d / 60_000_000L) + " min " + (d / 1_000_000L) % 60 + " s)" : ""));
            if (d > 2L * 60 * 60 * 1_000_000L) Toast.makeText(this, "Video bohat lambi hai — kai ghante lag sakte hain", Toast.LENGTH_LONG).show();
        } else {
            subs = u;
            subsText.setText("✓ Subtitle: " + PdfImporter.displayName(this, u));
        }
    }

    private void fillChoices() {
        asrGroup.removeAllViews();
        for (String id : new String[]{Models.ASR_TINY, Models.ASR_BASE}) {
            RadioButton rb = new RadioButton(this);
            boolean ok = Models.installed(this, id);
            rb.setText(Models.ALL.get(id).title + (ok ? "" : "  (install nahi)"));
            rb.setTag(id);
            rb.setEnabled(ok);
            asrGroup.addView(rb);
            if (ok && asrGroup.getCheckedRadioButtonId() == -1) rb.setChecked(true);
        }
        voiceGroup.removeAllViews();
        for (String v : new String[]{Prefs.VOICE_MALE, Prefs.VOICE_FEMALE, Prefs.VOICE_GOOGLE, Prefs.VOICE_PHONE}) {
            RadioButton rb = new RadioButton(this);
            boolean ok = !(Prefs.VOICE_MALE.equals(v) || Prefs.VOICE_FEMALE.equals(v)) || Models.voiceInstalled(this, v);
            rb.setText(Prefs.voiceLabel(v) + (ok ? "" : "  (install nahi)"));
            rb.setTag(v);
            rb.setEnabled(ok);
            voiceGroup.addView(rb);
            if (ok && voiceGroup.getCheckedRadioButtonId() == -1) rb.setChecked(true);
        }
    }

    private String checkedTag(RadioGroup g) {
        View v = g.findViewById(g.getCheckedRadioButtonId());
        return v == null ? null : (String) v.getTag();
    }

    private void start() {
        if (DubService.running) { Toast.makeText(this, "Ek dubbing pehle se chal rahi hai", Toast.LENGTH_SHORT).show(); return; }
        if (video == null) { Toast.makeText(this, "Pehle video chunain", Toast.LENGTH_SHORT).show(); return; }
        String asr = checkedTag(asrGroup);
        if (subs == null && asr == null) {
            new AlertDialog.Builder(this).setTitle("Model chahiye")
                    .setMessage("Awaaz se text banane ke liye Whisper model download karein (Settings → Video dubbing), "
                            + "ya video ki subtitle file dein.")
                    .setPositiveButton("Settings", (d, w) -> startActivity(new Intent(this, SettingsActivity.class)))
                    .setNegativeButton("Theek hai", null).show();
            return;
        }
        String voice = checkedTag(voiceGroup);
        if (voice == null) voice = Prefs.VOICE_GOOGLE;
        DubProject p = DubProject.create(this, video, PdfImporter.displayName(this, video));
        p.subtitleUri = subs == null ? "" : subs.toString();
        p.speechLang = SPEECH_CODES[speechSpin.getSelectedItemPosition()];
        if (asr != null) p.asrModel = asr;
        p.voice = voice;
        p.durationUs = AudioCodec.durationUs(this, video);
        try { p.save(); } catch (Exception e) { Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show(); return; }
        lastResult = DubService.result;
        DubService.startDub(this, p.id);
        refreshList();
    }

    private void updateProgress() {
        boolean run = DubService.running;
        startBtn.setEnabled(!run);
        cancelBtn.setVisibility(run ? View.VISIBLE : View.GONE);
        progress.setVisibility(run ? View.VISIBLE : View.GONE);
        if (run) {
            progress.setProgress(DubService.percent);
            progressText.setText(DubService.stage + " — " + DubService.percent + "%");
        } else {
            String r = DubService.result;
            progressText.setText(r == null ? "" : r);
            if (r != null && !r.equals(lastResult)) { lastResult = r; refreshList(); }
        }
    }

    private void refreshList() {
        listBox.removeAllViews();
        List<DubProject> all = DubProject.listAll(this);
        if (all.isEmpty()) { listBox.addView(small("Abhi koi dubbed video nahi")); return; }
        for (DubProject p : all) {
            LinearLayout row = vbox();
            TextView title = new TextView(this);
            title.setText(p.title);
            title.setTextColor(0xFF2D1B69);
            title.setTextSize(16);
            title.setTypeface(null, Typeface.BOLD);
            row.addView(title);
            String st = "done".equals(p.status) ? "✓ Tayyar • " + p.segs.size() + " jumle • " + Prefs.voiceLabel(p.voice)
                    : "working".equals(p.status) ? "Chal rahi hai…" : "error".equals(p.status) ? p.error : "Shuru nahi hui";
            row.addView(small(st));
            View c = card(row);
            c.setOnClickListener(v -> {
                if ("done".equals(p.status)) startActivity(new Intent(this, DubPlayerActivity.class).putExtra("id", p.id));
            });
            c.setOnLongClickListener(v -> {
                new AlertDialog.Builder(this).setTitle("Hatayen?")
                        .setMessage("Sirf app ki dubbing files hatengi — asal video mehfooz rahegi.")
                        .setPositiveButton("Hatayen", (d, w) -> { p.delete(); refreshList(); })
                        .setNegativeButton("Nahi", null).show();
                return true;
            });
            listBox.addView(c);
        }
    }

    // ------------------------------------------------------------- view helpers

    private int dp(float v) { return Ui.dp(this, v); }

    private TextView header(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(0xFF2D1B69);
        t.setTextSize(18);
        t.setTypeface(null, Typeface.BOLD);
        t.setPadding(dp(6), dp(18), dp(6), dp(6));
        return t;
    }

    private TextView small(String s) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(0xFF7A7296);
        t.setTextSize(13);
        t.setPadding(dp(2), dp(4), dp(2), dp(4));
        return t;
    }

    private LinearLayout vbox() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private Button button(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private View card(View v) {
        LinearLayout c = new LinearLayout(this);
        c.setBackgroundResource(R.drawable.bg_card);
        c.setElevation(dp(2));
        c.setPadding(dp(14), dp(12), dp(14), dp(12));
        c.addView(v, new LinearLayout.LayoutParams(-1, -2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(6);
        lp.bottomMargin = dp(4);
        c.setLayoutParams(lp);
        return c;
    }
}
