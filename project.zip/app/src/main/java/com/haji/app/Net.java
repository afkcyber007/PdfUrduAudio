package com.haji.app;

import android.text.TextUtils;

import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

/** Translation + speech via Google Translate's public web endpoints. */
final class Net {

    interface Cancel { boolean cancelled(); }

    private interface IoCall<T> { T call() throws IOException; }

    static final class HttpError extends IOException {
        final int code;
        HttpError(int code) { super("Server error " + code); this.code = code; }
    }

    private static final String UA =
            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36";

    private Net() { }

    static int encodedLength(String s) {
        try { return URLEncoder.encode(s, "UTF-8").length(); }
        catch (Exception e) { return s.length() * 6; }
    }

    // ------------------------------------------------------------- translate

    static String translate(String text) throws IOException {
        String url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ur&dt=t&q="
                + URLEncoder.encode(text, "UTF-8");
        String json = new String(get(url), "UTF-8");
        try {
            JSONArray root = new JSONArray(json);
            JSONArray sentences = root.optJSONArray(0);
            if (sentences == null) return "";
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < sentences.length(); i++) {
                JSONArray s = sentences.optJSONArray(i);
                if (s != null && !s.isNull(0)) sb.append(s.optString(0, ""));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new IOException("Tarjuma ka jawab samajh nahi aaya");
        }
    }

    static String translateRetry(final String text, Cancel c) throws IOException {
        return retry(() -> translate(text), c, "Tarjuma");
    }

    /** Translate several segments in one request; falls back to one-by-one if lines don't match. */
    static List<String> translateBatch(List<String> items, Cancel c) throws IOException {
        List<String> out = new ArrayList<>();
        if (items.isEmpty()) return out;
        if (items.size() > 1) {
            String joined = TextUtils.join("\n", items);
            String res = translateRetry(joined, c);
            String[] lines = res.split("\n", -1);
            List<String> clean = new ArrayList<>();
            for (String l : lines) if (!l.trim().isEmpty()) clean.add(l.trim());
            if (clean.size() == items.size()) return clean;
        }
        for (String s : items) out.add(translateRetry(s, c));
        return out;
    }

    // ------------------------------------------------------------- speech

    static byte[] tts(String text) throws IOException {
        String url = "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=ur&ttsspeed=1"
                + "&total=1&idx=0&textlen=" + text.length()
                + "&q=" + URLEncoder.encode(text, "UTF-8");
        byte[] data = get(url);
        if (data.length < 100) throw new IOException("Awaaz ka data khaali aaya");
        return data;
    }

    static byte[] ttsRetry(final String text, Cancel c) throws IOException {
        return retry(() -> tts(text), c, "Awaaz");
    }

    // ------------------------------------------------------------- plumbing

    private static <T> T retry(IoCall<T> call, Cancel c, String what) throws IOException {
        IOException last = null;
        for (int attempt = 0; attempt < 6; attempt++) {
            if (c != null && c.cancelled()) throw new IOException("cancelled");
            try {
                return call.call();
            } catch (IOException e) {
                last = e;
                long wait = (e instanceof HttpError && ((HttpError) e).code == 429)
                        ? 20000L * (attempt + 1)
                        : 1500L * (attempt + 1);
                sleep(wait, c);
            }
        }
        throw new IOException(what + " nahi ho saka: " + (last != null ? last.getMessage() : "")
                + " — internet check karein");
    }

    static void sleep(long ms, Cancel c) throws IOException {
        long end = System.currentTimeMillis() + ms;
        try {
            while (System.currentTimeMillis() < end) {
                if (c != null && c.cancelled()) throw new IOException("cancelled");
                Thread.sleep(Math.min(300, Math.max(1, end - System.currentTimeMillis())));
            }
        } catch (InterruptedException ie) {
            throw new IOException("cancelled");
        }
    }

    private static byte[] get(String urlStr) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
        c.setConnectTimeout(20000);
        c.setReadTimeout(30000);
        c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("Referer", "https://translate.google.com/");
        try {
            int code = c.getResponseCode();
            if (code != 200) throw new HttpError(code);
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) != -1) bos.write(buf, 0, r);
            in.close();
            return bos.toByteArray();
        } finally {
            c.disconnect();
        }
    }
}
