package com.haji.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import com.k2fsa.sherpa.onnx.OfflineRecognizer;
import com.k2fsa.sherpa.onnx.Vad;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.List;

/**
 * Local video → Urdu dub, fully on the phone once models are installed:
 *   1. decode the video's audio to 16 kHz mono (streamed to a temp file, never all in memory)
 *   2. speech segments: Silero VAD + Whisper (sherpa-onnx), or a subtitle file the user supplied
 *   3. translate non-Urdu text to Urdu (Urdu speech is kept as is)
 *   4. Urdu speech for each segment, placed at the original timestamps in a dub WAV
 * Also: export = original video track + dub audio → new MP4 (original file untouched).
 */
public class DubService extends Service {

    private static final String CHANNEL = "dubbing";
    private static final int NOTIF_ID = 11;

    static volatile boolean running;
    static volatile boolean cancelled;
    static volatile String projectId = "";
    static volatile String stage = "";
    static volatile int percent;
    static volatile String result;

    private static volatile boolean worker;
    private NotificationManager nm;
    private PowerManager.WakeLock wl;

    static void startDub(Context c, String id) { start(c, id, null); }

    static void startExport(Context c, String id, Uri out) { start(c, id, out); }

    private static void start(Context c, String id, Uri exportTo) {
        if (running) return;
        running = true;
        cancelled = false;
        projectId = id;
        stage = "Shuru ho raha hai…";
        percent = 0;
        result = null;
        Intent i = new Intent(c, DubService.class).putExtra("id", id);
        if (exportTo != null) i.putExtra("export", exportTo).addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Video dubbing", NotificationManager.IMPORTANCE_LOW));
        }
        Notification n = notif(stage, 0, true);
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(NOTIF_ID, n);
        if (intent == null || worker) return START_NOT_STICKY;
        worker = true;
        final String id = intent.getStringExtra("id");
        final Uri export = intent.getParcelableExtra("export");
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "HajiApp:dub");
        wl.acquire(6 * 60 * 60 * 1000L);
        new Thread(() -> {
            if (export != null) runExport(id, export); else runDub(id);
        }, "dub").start();
        return START_NOT_STICKY;
    }

    private void set(String s, int p) {
        stage = s;
        percent = Math.max(0, Math.min(100, p));
        nm.notify(NOTIF_ID, notif(s + " — " + percent + "%", percent, true));
    }

    // ------------------------------------------------------------- dubbing

    private void runDub(String id) {
        DubProject p = null;
        File work = new File(new File(getCacheDir(), "dubwork"), id);
        Synth synth = null;
        try {
            p = DubProject.load(this, id);
            p.status = "working";
            p.error = "";
            p.segs.clear();
            p.save();
            work.mkdirs();
            Uri video = Uri.parse(p.videoUri);
            if (p.durationUs <= 0) p.durationUs = AudioCodec.durationUs(this, video);
            final Net.Cancel cancel = () -> cancelled;

            // ---- 1+2: speech segments
            if (p.subtitleUri != null && !p.subtitleUri.isEmpty()) {
                set("Subtitle file parh rahe hain", 5);
                String content = readText(Uri.parse(p.subtitleUri));
                List<Subtitles.Cue> cues = Subtitles.parse(content);
                if (cues.isEmpty()) throw new IOException("Subtitle file main koi line nahi mili (SRT/VTT chahiye)");
                for (Subtitles.Cue c : cues) {
                    DubProject.Seg s = new DubProject.Seg();
                    s.start = c.start;
                    s.end = c.end;
                    s.text = c.text;
                    s.lang = p.speechLang.isEmpty() ? guessLang(c.text) : p.speechLang;
                    p.segs.add(s);
                }
            } else {
                if (!Models.installed(this, p.asrModel)) {
                    throw new IOException("Awaaz → text model (" + Models.ALL.get(p.asrModel).title
                            + ") install nahi. Settings → Video dubbing se download karein, ya subtitle file dein.");
                }
                File pcm = new File(work, "audio16k.pcm");
                long needed = Math.max(0, p.durationUs) / 1_000_000L * 32000L;
                if (Models.freeBytes(this) < needed + 100_000_000L) {
                    throw new IOException("Phone main jagah kam hai (is video ke liye ~" + Models.mb(needed + 100_000_000L) + " chahiye)");
                }
                set("Video se awaaz nikal rahe hain", 0);
                try (DataOutputStream os = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(pcm)))) {
                    AudioCodec.decodeToMono(this, video, 16000, (s, n) -> {
                        for (int i = 0; i < n; i++) os.writeShort(AudioCodec.toShort(s[i]));
                    }, new AudioCodec.Progress() {
                        @Override public void onProgress(long d, long t) { if (t > 0) percent = (int) Math.min(20, d * 20 / t); }
                        @Override public boolean cancelled() { return cancelled; }
                    });
                }
                transcribe(p, pcm);
                pcm.delete();
            }
            if (p.segs.isEmpty()) throw new IOException("Video main koi baat-cheet nahi mili");
            p.save();

            // ---- 3: translation
            int n = p.segs.size();
            for (int i = 0; i < n; i++) {
                if (cancelled) throw new IOException("cancelled");
                DubProject.Seg s = p.segs.get(i);
                set("Urdu tarjuma (" + (i + 1) + "/" + n + ")", 60 + i * 15 / n);
                if (isUrdu(s) || Lang.OTHER.equals(s.lang)) s.urdu = s.text;     // Urdu speech: kept, never rewritten
                else s.urdu = Translator.toUrdu(this, s.text, s.lang, cancel);
            }
            p.save();

            // ---- 4: Urdu voice placed on the timeline
            synth = new Synth(this, p.voice, work, cancel);
            double totalSec = p.durationUs > 0 ? p.durationUs / 1e6 : p.segs.get(n - 1).end + 5;
            long totalSamples = (long) (totalSec * Synth.RATE) + Synth.RATE;
            File wavTmp = new File(p.dir, "dub.wav.tmp");
            long prevEnd = 0;
            try (RandomAccessFile raf = AudioCodec.createSilentWav(wavTmp, totalSamples, Synth.RATE)) {
                for (int i = 0; i < n; i++) {
                    if (cancelled) throw new IOException("cancelled");
                    DubProject.Seg s = p.segs.get(i);
                    set("Urdu awaaz ban rahi hai (" + (i + 1) + "/" + n + ")", 75 + i * 25 / n);
                    double slot = (i + 1 < n ? p.segs.get(i + 1).start : totalSec) - s.start;
                    float[] pcm = synth.speak(s.urdu, 1.0f);
                    double dur = pcm.length / (double) Synth.RATE;
                    if (synth.canChangeSpeed() && slot > 0.3 && dur > slot * 1.05) {
                        float sp = (float) Math.min(1.6, dur / slot);
                        pcm = synth.speak(s.urdu, sp);
                    }
                    long at = Math.max((long) (s.start * Synth.RATE), prevEnd);
                    AudioCodec.writeAt(raf, at, pcm);
                    prevEnd = at + pcm.length;
                }
            }
            if (!wavTmp.renameTo(p.dubWav())) throw new IOException("Dub file save nahi hui");
            p.status = "done";
            p.save();
            result = "Dubbing mukammal! Ab video chala kar sunein.";
        } catch (Throwable e) {
            String m = e.getMessage() == null ? e.toString() : e.getMessage();
            result = cancelled ? "Dubbing rok di gayi." : "Dubbing ruk gayi: " + m;
            if (p != null) {
                p.status = "error";
                p.error = result;
                try { p.save(); } catch (Exception ignored) { }
            }
        } finally {
            if (synth != null) synth.close();
            Models.rm(work);
            finish();
        }
    }

    private boolean isUrdu(DubProject.Seg s) {
        if (Lang.UR.equals(s.lang)) return true;
        // Whisper sometimes labels Urdu speech differently; Urdu-only letters mean the text is Urdu.
        Lang.DocStats st = Lang.stats(s.text);
        return st.urduOnly > 0 && st.arabicScript > st.latin;
    }

    private static String guessLang(String text) {
        Lang.DocStats st = Lang.stats(text);
        return st.dominant();
    }

    private void transcribe(DubProject p, File pcm) throws IOException {
        set("Awaaz → text model load ho raha hai", 20);
        OfflineRecognizer rec = null;
        Vad vad = null;
        try {
            int threads = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors() - 1));
            try {
                rec = SherpaBridge.createWhisper(
                        Models.asrFile(this, p.asrModel, "encoder.onnx"),
                        Models.asrFile(this, p.asrModel, "decoder.onnx"),
                        Models.asrFile(this, p.asrModel, "tokens.txt"),
                        p.speechLang, threads);
                vad = SherpaBridge.createVad(Models.vadModel(this));
            } catch (Throwable e) {
                throw new IOException("Whisper/VAD model load nahi hua: " + e.getMessage());
            }
            long totalSamples = pcm.length() / 2;
            long read = 0;
            float[] win = new float[512];
            try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(pcm), 1 << 16))) {
                boolean eof = false;
                while (!eof) {
                    if (cancelled) throw new IOException("cancelled");
                    int k = 0;
                    try {
                        for (; k < win.length; k++) win[k] = in.readShort() / 32768f;
                    } catch (EOFException e) {
                        eof = true;
                    }
                    if (k > 0) {
                        float[] chunk = k == win.length ? win : java.util.Arrays.copyOf(win, k);
                        SherpaBridge.vadAccept(vad, chunk);
                        read += k;
                    }
                    if (eof) SherpaBridge.vadFlush(vad);
                    while (!SherpaBridge.vadEmpty(vad)) {
                        int start = SherpaBridge.vadFrontStart(vad);
                        float[] samples = SherpaBridge.vadFrontSamples(vad);
                        SherpaBridge.vadPop(vad);
                        String[] r = SherpaBridge.recognize(rec, samples);
                        String text = r[0] == null ? "" : r[0].trim();
                        if (text.isEmpty()) continue;
                        DubProject.Seg s = new DubProject.Seg();
                        s.start = start / 16000.0;
                        s.end = s.start + samples.length / 16000.0;
                        s.text = text;
                        String lang = p.speechLang.isEmpty() ? (r[1] == null ? "" : r[1].replace("<|", "").replace("|>", "").trim()) : p.speechLang;
                        s.lang = lang.isEmpty() ? guessLang(text) : lang;
                        p.segs.add(s);
                        set("Awaaz → text (" + p.segs.size() + " hisse)", 20 + (int) (read * 40 / Math.max(1, totalSamples)));
                    }
                }
            }
        } finally {
            if (vad != null) try { SherpaBridge.release(vad); } catch (Throwable ignored) { }
            if (rec != null) try { SherpaBridge.release(rec); } catch (Throwable ignored) { }
        }
    }

    private String readText(Uri u) throws IOException {
        try (InputStream in = getContentResolver().openInputStream(u)) {
            if (in == null) throw new IOException("Subtitle file nahi khuli");
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int r;
            while ((r = in.read(buf)) != -1) {
                bos.write(buf, 0, r);
                if (bos.size() > 20_000_000) throw new IOException("Subtitle file bohat bari hai");
            }
            return new String(bos.toByteArray(), StandardCharsets.UTF_8);
        }
    }

    // ------------------------------------------------------------- export MP4

    private void runExport(String id, Uri out) {
        File tmp = new File(getCacheDir(), "dub_export.mp4");
        try {
            DubProject p = DubProject.load(this, id);
            if (!p.dubWav().exists()) throw new IOException("Pehle dubbing mukammal karein");
            set("MP4 ban rahi hai", 0);
            AudioCodec.muxVideoWithWav(this, Uri.parse(p.videoUri), p.dubWav(), Synth.RATE, tmp, new AudioCodec.Progress() {
                long last;
                @Override public void onProgress(long d, long t) {
                    long now = System.currentTimeMillis();
                    if (t > 0 && now - last > 700) { last = now; set("MP4 ban rahi hai", (int) (d * 95 / t)); }
                }
                @Override public boolean cancelled() { return cancelled; }
            });
            set("File save ho rahi hai", 97);
            try (InputStream in = new FileInputStream(tmp); OutputStream os = getContentResolver().openOutputStream(out, "w")) {
                if (os == null) throw new IOException("File save nahi ho saki");
                byte[] buf = new byte[1 << 16];
                int r;
                while ((r = in.read(buf)) != -1) os.write(buf, 0, r);
            }
            result = "Dubbed video save ho gayi (asal video waisi hi mehfooz hai).";
        } catch (Throwable e) {
            result = cancelled ? "Export rok diya gaya." : "Export nahi hua: " + e.getMessage();
        } finally {
            tmp.delete();
            finish();
        }
    }

    private void finish() {
        running = false;
        worker = false;
        if (wl != null && wl.isHeld()) wl.release();
        stopForeground(Service.STOP_FOREGROUND_REMOVE);
        nm.notify(NOTIF_ID + 1, notif(result, 100, false));
        stopSelf();
    }

    private Notification notif(String text, int p, boolean ongoing) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, DubActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        b.setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("HAJI APP — Video Urdu dubbing")
                .setContentText(text)
                .setContentIntent(pi)
                .setColor(0xFF7B2FF7)
                .setOngoing(ongoing)
                .setOnlyAlertOnce(true);
        if (ongoing) b.setProgress(100, p, false); else b.setAutoCancel(true);
        return b.build();
    }

    @Override
    public void onDestroy() {
        cancelled = true;
        super.onDestroy();
    }
}
