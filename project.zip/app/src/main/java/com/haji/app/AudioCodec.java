package com.haji.app;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;

import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;

/** Audio helpers built only on Android framework codecs (no ffmpeg needed). */
final class AudioCodec {
    private AudioCodec() { }

    interface PcmSink {
        /** Mono float samples at the requested output rate. */
        void accept(float[] samples, int count) throws IOException;
    }

    interface Progress {
        void onProgress(long doneUs, long totalUs);
        boolean cancelled();
    }

    // ------------------------------------------------------------- WAV

    static void writeWav(File f, float[] samples, int rate) throws IOException {
        try (OutputStream os = new BufferedOutputStream(new FileOutputStream(f))) {
            writeWavHeader(os, samples.length, rate);
            byte[] buf = new byte[samples.length * 2];
            for (int i = 0; i < samples.length; i++) {
                short v = toShort(samples[i]);
                buf[2 * i] = (byte) (v & 0xff);
                buf[2 * i + 1] = (byte) ((v >> 8) & 0xff);
            }
            os.write(buf);
        }
    }

    static short toShort(float x) {
        float v = x * 32767f;
        if (v > 32767f) v = 32767f;
        if (v < -32768f) v = -32768f;
        return (short) v;
    }

    static void writeWavHeader(OutputStream os, long numSamples, int rate) throws IOException {
        long dataLen = numSamples * 2;
        ByteBuffer b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN);
        b.put(new byte[]{'R', 'I', 'F', 'F'}).putInt((int) (36 + dataLen))
                .put(new byte[]{'W', 'A', 'V', 'E', 'f', 'm', 't', ' '})
                .putInt(16).putShort((short) 1).putShort((short) 1).putInt(rate).putInt(rate * 2)
                .putShort((short) 2).putShort((short) 16)
                .put(new byte[]{'d', 'a', 't', 'a'}).putInt((int) dataLen);
        os.write(b.array());
    }

    /** A silent WAV of the given length that segments can later be written into. */
    static RandomAccessFile createSilentWav(File f, long numSamples, int rate) throws IOException {
        try (OutputStream os = new BufferedOutputStream(new FileOutputStream(f))) {
            writeWavHeader(os, numSamples, rate);
            byte[] zeros = new byte[65536];
            long left = numSamples * 2;
            while (left > 0) {
                int n = (int) Math.min(zeros.length, left);
                os.write(zeros, 0, n);
                left -= n;
            }
        }
        return new RandomAccessFile(f, "rw");
    }

    static void writeAt(RandomAccessFile raf, long sampleOffset, float[] samples) throws IOException {
        byte[] buf = new byte[samples.length * 2];
        for (int i = 0; i < samples.length; i++) {
            short v = toShort(samples[i]);
            buf[2 * i] = (byte) (v & 0xff);
            buf[2 * i + 1] = (byte) ((v >> 8) & 0xff);
        }
        long pos = 44 + sampleOffset * 2;
        long max = raf.length();
        if (pos >= max) return;
        int len = (int) Math.min(buf.length, max - pos);
        raf.seek(pos);
        raf.write(buf, 0, len);
    }

    // ------------------------------------------------------------- decode anything → mono float at outRate

    static long durationUs(Context c, Uri uri) {
        MediaExtractor ex = new MediaExtractor();
        try {
            ex.setDataSource(c, uri, null);
            long best = 0;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                if (f.containsKey(MediaFormat.KEY_DURATION)) best = Math.max(best, f.getLong(MediaFormat.KEY_DURATION));
            }
            return best;
        } catch (Exception e) {
            return 0;
        } finally {
            ex.release();
        }
    }

    static void decodeToMono(Context c, Uri uri, int outRate, PcmSink sink, Progress p) throws IOException {
        MediaExtractor ex = new MediaExtractor();
        ex.setDataSource(c, uri, null);
        decode(ex, outRate, sink, p);
    }

    static void decodeFileToMono(File f, int outRate, PcmSink sink) throws IOException {
        MediaExtractor ex = new MediaExtractor();
        ex.setDataSource(f.getAbsolutePath());
        decode(ex, outRate, sink, null);
    }

    private static void decode(MediaExtractor ex, int outRate, PcmSink sink, Progress p) throws IOException {
        MediaCodec codec = null;
        try {
            int track = -1;
            MediaFormat fmt = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) { track = i; fmt = f; break; }
            }
            if (track < 0) throw new IOException("Is file main awaaz (audio track) nahi mili");
            ex.selectTrack(track);
            long totalUs = fmt.containsKey(MediaFormat.KEY_DURATION) ? fmt.getLong(MediaFormat.KEY_DURATION) : 0;
            String mime = fmt.getString(MediaFormat.KEY_MIME);
            try {
                codec = MediaCodec.createDecoderByType(mime);
                codec.configure(fmt, null, null, 0);
            } catch (Exception e) {
                throw new IOException("Ye audio format (" + mime + ") is phone par decode nahi hota");
            }
            codec.start();
            int inRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE);
            int channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            Resampler rs = new Resampler(inRate, outRate);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            boolean inputDone = false, outputDone = false;
            float[] mono = new float[0];
            while (!outputDone) {
                if (p != null && p.cancelled()) throw new IOException("cancelled");
                if (!inputDone) {
                    int ii = codec.dequeueInputBuffer(10000);
                    if (ii >= 0) {
                        ByteBuffer ib = codec.getInputBuffer(ii);
                        int n = ex.readSampleData(ib, 0);
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            long t = ex.getSampleTime();
                            codec.queueInputBuffer(ii, 0, n, t, 0);
                            ex.advance();
                            if (p != null) p.onProgress(t, totalUs);
                        }
                    }
                }
                int oi = codec.dequeueOutputBuffer(info, 10000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = codec.getOutputFormat();
                    channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    int newRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    if (newRate != inRate) { inRate = newRate; rs = new Resampler(inRate, outRate); }
                } else if (oi >= 0) {
                    ByteBuffer ob = codec.getOutputBuffer(oi);
                    if (info.size > 0 && ob != null) {
                        ob.position(info.offset);
                        ob.limit(info.offset + info.size);
                        ShortBuffer sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer();
                        int frames = sb.remaining() / Math.max(1, channels);
                        if (mono.length < frames) mono = new float[frames];
                        for (int i = 0; i < frames; i++) {
                            float s = 0;
                            for (int ch = 0; ch < channels; ch++) s += sb.get(i * channels + ch);
                            mono[i] = s / (channels * 32768f);
                        }
                        float[] out = rs.process(mono, frames);
                        if (out.length > 0) sink.accept(out, out.length);
                    }
                    codec.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true;
                }
            }
        } finally {
            if (codec != null) { try { codec.stop(); } catch (Exception ignored) { } codec.release(); }
            ex.release();
        }
    }

    /** Simple streaming linear-interpolation resampler (good enough for speech). */
    static final class Resampler {
        private final double step;
        private double pos;
        private float last;
        private boolean hasLast;

        Resampler(int inRate, int outRate) { step = (double) inRate / outRate; }

        float[] process(float[] in, int n) {
            if (n == 0) return new float[0];
            int cap = (int) ((n + 1) / step) + 2;
            float[] out = new float[cap];
            int k = 0;
            // virtual input: [last, in0, in1, ...] when hasLast
            int offset = hasLast ? 1 : 0;
            int total = n + offset;
            while (pos + 1 < total && k < cap) {
                int i = (int) pos;
                double frac = pos - i;
                float a = at(in, i - offset), b = at(in, i + 1 - offset);
                out[k++] = (float) (a + (b - a) * frac);
                pos += step;
            }
            pos -= (total - 1);
            last = in[n - 1];
            hasLast = true;
            float[] r = new float[k];
            System.arraycopy(out, 0, r, 0, k);
            return r;
        }

        private float at(float[] in, int i) { return i < 0 ? last : in[i]; }
    }

    // ------------------------------------------------------------- streaming AAC (.m4a) writer

    /** Streams mono float PCM into an AAC .m4a file without keeping the whole audio in memory. */
    static final class AacWriter {
        private final MediaCodec enc;
        private final MediaMuxer muxer;
        private final int rate;
        private final MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        private final java.util.ArrayDeque<Object[]> pending = new java.util.ArrayDeque<>();
        private int track = -1;
        private long samplesIn;

        AacWriter(File out, int rate) throws IOException {
            this.rate = rate;
            MediaFormat fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 1);
            fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, 64000);
            fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
            enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            enc.start();
            muxer = new MediaMuxer(out.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        }

        void write(float[] pcm) throws IOException {
            int off = 0;
            while (off < pcm.length) {
                int ii = enc.dequeueInputBuffer(10000);
                if (ii >= 0) {
                    ByteBuffer ib = enc.getInputBuffer(ii);
                    ib.clear();
                    int n = Math.min(pcm.length - off, ib.remaining() / 2);
                    ByteBuffer lb = ib.order(ByteOrder.LITTLE_ENDIAN);
                    for (int i = 0; i < n; i++) lb.putShort(toShort(pcm[off + i]));
                    long pts = samplesIn * 1_000_000L / rate;
                    enc.queueInputBuffer(ii, 0, n * 2, pts, 0);
                    samplesIn += n;
                    off += n;
                }
                drain(false);
            }
        }

        void silence(float seconds) throws IOException { write(new float[(int) (seconds * rate)]); }

        void finish() throws IOException {
            boolean queued = false;
            while (!queued) {
                int ii = enc.dequeueInputBuffer(10000);
                if (ii >= 0) {
                    enc.queueInputBuffer(ii, 0, 0, samplesIn * 1_000_000L / rate, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                    queued = true;
                }
                drain(false);
            }
            drain(true);
            try { enc.stop(); } catch (Exception ignored) { }
            enc.release();
            if (track >= 0) muxer.stop();
            muxer.release();
            if (track < 0) throw new IOException("Audio khaali hai");
        }

        private void drain(boolean untilEos) {
            while (true) {
                int oi = enc.dequeueOutputBuffer(info, untilEos ? 10000 : 0);
                if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) { if (!untilEos) return; else continue; }
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    track = muxer.addTrack(enc.getOutputFormat());
                    muxer.start();
                    while (!pending.isEmpty()) {
                        Object[] f = pending.poll();
                        MediaCodec.BufferInfo bi = (MediaCodec.BufferInfo) f[1];
                        muxer.writeSampleData(track, ByteBuffer.wrap((byte[]) f[0]), bi);
                    }
                    continue;
                }
                if (oi < 0) continue;
                ByteBuffer ob = enc.getOutputBuffer(oi);
                boolean config = (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0;
                if (!config && info.size > 0 && ob != null) {
                    ob.position(info.offset);
                    ob.limit(info.offset + info.size);
                    if (track >= 0) {
                        muxer.writeSampleData(track, ob, info);
                    } else {
                        byte[] d = new byte[info.size];
                        ob.get(d);
                        MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
                        bi.set(0, d.length, info.presentationTimeUs, 0);
                        pending.add(new Object[]{d, bi});
                    }
                }
                boolean eos = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                enc.releaseOutputBuffer(oi, false);
                if (eos) return;
            }
        }
    }

    // ------------------------------------------------------------- export: original video + new audio → MP4

    /**
     * Copies the video track of {@code video} and replaces the sound with {@code wav} (mono 16-bit PCM),
     * encoded to AAC. The original file is only read, never modified.
     */
    static void muxVideoWithWav(Context c, Uri video, File wav, int wavRate, File outMp4, Progress p) throws IOException {
        File aacTmp = new File(outMp4.getParentFile(), outMp4.getName() + ".aac.tmp");
        MediaFormat audioFormat = encodeWavToAacFrames(wav, wavRate, aacTmp, p);

        MediaExtractor ex = new MediaExtractor();
        MediaMuxer muxer = null;
        try {
            ex.setDataSource(c, video, null);
            int vTrack = -1;
            MediaFormat vFmt = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("video/")) { vTrack = i; vFmt = f; break; }
            }
            if (vTrack < 0) throw new IOException("Video track nahi mila");
            muxer = new MediaMuxer(outMp4.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
            if (vFmt.containsKey("rotation-degrees")) muxer.setOrientationHint(vFmt.getInteger("rotation-degrees"));
            int outV;
            try {
                outV = muxer.addTrack(vFmt);
            } catch (Exception e) {
                throw new IOException("Is video ka format MP4 main export nahi ho sakta (sirf app main chalegi)");
            }
            int outA = muxer.addTrack(audioFormat);
            muxer.start();

            ex.selectTrack(vTrack);
            long total = vFmt.containsKey(MediaFormat.KEY_DURATION) ? vFmt.getLong(MediaFormat.KEY_DURATION) : 0;
            ByteBuffer buf = ByteBuffer.allocate(4 * 1024 * 1024);
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            while (true) {
                if (p != null && p.cancelled()) throw new IOException("cancelled");
                int n = ex.readSampleData(buf, 0);
                if (n < 0) break;
                info.offset = 0;
                info.size = n;
                info.presentationTimeUs = ex.getSampleTime();
                info.flags = (ex.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0 ? MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;
                muxer.writeSampleData(outV, buf, info);
                ex.advance();
                if (p != null) p.onProgress(info.presentationTimeUs / 2, total);
            }
            try (DataInputStream in = new DataInputStream(new java.io.BufferedInputStream(new FileInputStream(aacTmp)))) {
                while (true) {
                    int size;
                    try { size = in.readInt(); } catch (java.io.EOFException eof) { break; }
                    long pts = in.readLong();
                    int flags = in.readInt();
                    byte[] data = new byte[size];
                    in.readFully(data);
                    ByteBuffer ab = ByteBuffer.wrap(data);
                    info.offset = 0;
                    info.size = size;
                    info.presentationTimeUs = pts;
                    info.flags = flags;
                    muxer.writeSampleData(outA, ab, info);
                    if (p != null) p.onProgress(total / 2 + pts / 2, total);
                }
            }
            muxer.stop();
        } finally {
            if (muxer != null) try { muxer.release(); } catch (Exception ignored) { }
            ex.release();
            aacTmp.delete();
        }
    }

    /** Encodes WAV PCM to AAC; writes frames as [size][pts][flags][bytes] and returns the AAC track format. */
    private static MediaFormat encodeWavToAacFrames(File wav, int rate, File out, Progress p) throws IOException {
        MediaFormat fmt = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 1);
        fmt.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, 64000);
        fmt.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
        MediaCodec enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
        MediaFormat outFormat = null;
        try (FileInputStream in = new FileInputStream(wav);
             DataOutputStream os = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(out)))) {
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            enc.start();
            if (in.skip(44) != 44) throw new IOException("WAV header error");
            long totalSamples = (wav.length() - 44) / 2;
            long samplesIn = 0;
            byte[] chunk = new byte[8192];
            boolean inputDone = false, outputDone = false;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            while (!outputDone) {
                if (p != null && p.cancelled()) throw new IOException("cancelled");
                if (!inputDone) {
                    int ii = enc.dequeueInputBuffer(10000);
                    if (ii >= 0) {
                        ByteBuffer ib = enc.getInputBuffer(ii);
                        ib.clear();
                        int want = Math.min(chunk.length, ib.remaining());
                        int n = in.read(chunk, 0, want);
                        long pts = samplesIn * 1_000_000L / rate;
                        if (n <= 0) {
                            enc.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inputDone = true;
                        } else {
                            ib.put(chunk, 0, n);
                            enc.queueInputBuffer(ii, 0, n, pts, 0);
                            samplesIn += n / 2;
                        }
                    }
                }
                int oi = enc.dequeueOutputBuffer(info, 10000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    outFormat = enc.getOutputFormat();
                } else if (oi >= 0) {
                    ByteBuffer ob = enc.getOutputBuffer(oi);
                    boolean config = (info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0;
                    if (!config && info.size > 0 && ob != null) {
                        byte[] data = new byte[info.size];
                        ob.position(info.offset);
                        ob.get(data);
                        os.writeInt(info.size);
                        os.writeLong(info.presentationTimeUs);
                        os.writeInt(0);
                        os.write(data);
                    }
                    enc.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true;
                    if (p != null && totalSamples > 0) p.onProgress(0, 1);
                }
            }
        } finally {
            try { enc.stop(); } catch (Exception ignored) { }
            enc.release();
        }
        if (outFormat == null) throw new IOException("Audio encoder ne format nahi diya");
        return outFormat;
    }
}
