package com.haji.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;


public class PlayerActivity extends Activity implements ReaderService.Listener {

    static final String EXTRA_ID = "id";
    static final String EXTRA_AUTOPLAY = "autoplay";
    private static final int REQ_EXPORT = 5;

    private Book book;
    private String bookId;
    private boolean showUrdu = true;
    private boolean autoplay;
    private boolean seekTouching;
    private int lastIndex = -1;
    private int current;

    private ListView segList;
    private ImageView playBtn;
    private TextView status, posText, pctText, speedBtn, voiceBtn, translateBtn, exportBtn, viewToggle;
    private SeekBar seek;
    private SegAdapter adapter;
    private String lastExportResult;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable exportPoll = new Runnable() {
        @Override public void run() {
            updateExport();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        Ui.edgeToEdge(this, findViewById(R.id.topbar));

        bookId = getIntent().getStringExtra(EXTRA_ID);
        autoplay = getIntent().getBooleanExtra(EXTRA_AUTOPLAY, false);
        try {
            book = Book.get(this, bookId);
            book.segments();
        } catch (Exception e) {
            Toast.makeText(this, "Kitaab khul nahi saki", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        current = book.pos;
        lastExportResult = ExportService.result;

        ((TextView) findViewById(R.id.title)).setText(book.title);
        ((TextView) findViewById(R.id.subtitle)).setText(book.pages + " safhe • " + book.count + " hisse");

        segList = findViewById(R.id.segList);
        playBtn = findViewById(R.id.playBtn);
        status = findViewById(R.id.status);
        posText = findViewById(R.id.posText);
        pctText = findViewById(R.id.pctText);
        speedBtn = findViewById(R.id.speedBtn);
        voiceBtn = findViewById(R.id.voiceBtn);
        translateBtn = findViewById(R.id.translateBtn);
        exportBtn = findViewById(R.id.exportBtn);
        viewToggle = findViewById(R.id.viewToggle);
        seek = findViewById(R.id.seek);

        adapter = new SegAdapter();
        segList.setAdapter(adapter);
        segList.setOnItemClickListener((p, v, pos, id) -> {
            ReaderService s = svc();
            if (s == null) return;
            s.jumpTo(pos);
            if (!s.playing) s.play();
        });

        findViewById(R.id.back).setOnClickListener(v -> finish());
        playBtn.setOnClickListener(v -> {
            ReaderService s = svc();
            if (s == null) { ReaderService.open(this, bookId); autoplay = true; return; }
            s.toggle();
        });
        findViewById(R.id.prevBtn).setOnClickListener(v -> { ReaderService s = svc(); if (s != null) s.prev(); });
        findViewById(R.id.nextBtn).setOnClickListener(v -> { ReaderService s = svc(); if (s != null) s.next(); });
        speedBtn.setOnClickListener(v -> {
            ReaderService s = svc();
            if (s == null) return;
            float next = ReaderService.SPEEDS[0];
            for (float f : ReaderService.SPEEDS) if (f > s.speed + 0.01f) { next = f; break; }
            s.setSpeed(next);
        });
        voiceBtn.setOnClickListener(v -> pickVoice());
        translateBtn.setOnClickListener(v -> {
            ReaderService s = svc();
            if (s == null) return;
            int cur = java.util.Arrays.asList(Lang.SOURCES).indexOf(book.src);
            new AlertDialog.Builder(this)
                    .setTitle("Kitaab ki zubaan")
                    .setSingleChoiceItems(Lang.SOURCE_LABELS, Math.max(0, cur), (d, w) -> {
                        d.dismiss();
                        s.setSource(Lang.SOURCES[w]);
                    })
                    .setNegativeButton("Wapas", null)
                    .show();
        });
        viewToggle.setOnClickListener(v -> {
            showUrdu = !showUrdu;
            viewToggle.setText(showUrdu ? "اردو" : "Asal");
            adapter.notifyDataSetChanged();
        });
        exportBtn.setOnClickListener(v -> onExportClick());
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int p, boolean user) {
                if (user) posText.setText(posLabel(p));
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { seekTouching = true; }
            @Override public void onStopTrackingTouch(SeekBar sb) {
                seekTouching = false;
                ReaderService s = svc();
                if (s != null) s.jumpTo(sb.getProgress());
            }
        });

        ReaderService.open(this, bookId);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String id = intent.getStringExtra(EXTRA_ID);
        if (id != null && !id.isEmpty() && !id.equals(bookId)) {
            setIntent(intent);
            recreate();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        ReaderService.addListener(this);
        onReaderUpdate();
        handler.post(exportPoll);
    }

    @Override
    protected void onPause() {
        super.onPause();
        ReaderService.removeListener(this);
        handler.removeCallbacks(exportPoll);
    }

    private ReaderService svc() {
        ReaderService s = ReaderService.instance;
        return (s != null && s.book == book) ? s : null;
    }

    @Override
    public void onReaderUpdate() {
        if (book == null) return;
        ReaderService s = svc();
        if (s != null && autoplay) { autoplay = false; if (!s.playing) s.play(); }
        boolean playing = s != null && s.playing;
        current = s != null ? s.index : book.pos;

        playBtn.setImageResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);
        String st;
        if (s == null) st = "Tayyar…";
        else if (s.message != null) st = s.message;
        else if (s.loading) st = "Awaaz tayyar ho rahi hai…";
        else if (playing) st = "Parh raha hai…";
        else st = "Ruka hua — ▶ dabayen";
        status.setText(st);

        seek.setMax(Math.max(0, book.count - 1));
        if (!seekTouching) {
            seek.setProgress(current);
            posText.setText(posLabel(current));
        }
        pctText.setText(book.count <= 1 ? "0%" : (Math.round(current * 100f / (book.count - 1)) + "%"));
        float sp = s != null ? s.speed : 1f;
        speedBtn.setText(String.valueOf(sp) + "x");
        voiceBtn.setText(Prefs.shortVoiceLabel(s != null ? s.voice : Prefs.voice(this)));
        translateBtn.setText("Zubaan: " + Lang.label(book.src));

        adapter.notifyDataSetChanged();
        if (current != lastIndex) {
            if (lastIndex == -1) segList.setSelectionFromTop(current, Ui.dp(this, 60));
            else segList.smoothScrollToPositionFromTop(current, Ui.dp(this, 60), 350);
            lastIndex = current;
        }
    }

    private String posLabel(int i) {
        int pg = book.page(i);
        return (pg > 0 ? "Safha " + pg + " • " : "") + "Hissa " + (i + 1) + " / " + book.count;
    }

    private String exportVoice() {
        String v = Prefs.voice(this);
        return Prefs.VOICE_PHONE.equals(v) ? Prefs.VOICE_GOOGLE : v;
    }

    private void pickVoice() {
        ReaderService s = svc();
        if (s == null) return;
        final String[] ids = {Prefs.VOICE_GOOGLE, Prefs.VOICE_MALE, Prefs.VOICE_FEMALE, Prefs.VOICE_PHONE};
        String[] labels = new String[ids.length];
        int cur = 0;
        for (int i = 0; i < ids.length; i++) {
            boolean piper = Prefs.VOICE_MALE.equals(ids[i]) || Prefs.VOICE_FEMALE.equals(ids[i]);
            boolean ok = !piper || Models.voiceInstalled(this, ids[i]);
            labels[i] = Prefs.voiceLabel(ids[i]) + (ok ? "" : "  (Settings se download karein)");
            if (ids[i].equals(s.voice)) cur = i;
        }
        new AlertDialog.Builder(this)
                .setTitle("Awaaz chunain")
                .setSingleChoiceItems(labels, cur, (d, w) -> {
                    boolean piper = Prefs.VOICE_MALE.equals(ids[w]) || Prefs.VOICE_FEMALE.equals(ids[w]);
                    if (piper && !Models.voiceInstalled(this, ids[w])) {
                        d.dismiss();
                        startActivity(new Intent(this, SettingsActivity.class));
                        return;
                    }
                    d.dismiss();
                    s.setVoice(ids[w]);
                })
                .setNegativeButton("Wapas", null)
                .show();
    }

    // ------------------------------------------------------------- export

    private void onExportClick() {
        if (ExportService.running) {
            new AlertDialog.Builder(this)
                    .setTitle("Export rokain?")
                    .setMessage("MP3 export abhi chal raha hai. Rok dein?")
                    .setPositiveButton("Rokain", (d, w) -> ExportService.cancelled = true)
                    .setNegativeButton("Chalne dein", null)
                    .show();
            return;
        }
        String v = exportVoice();
        boolean piper = Prefs.VOICE_MALE.equals(v) || Prefs.VOICE_FEMALE.equals(v);
        String note = Prefs.VOICE_PHONE.equals(Prefs.voice(this))
                ? "\n\nPhone ki awaaz file main save nahi ho sakti, is liye Google awaaz istemal hogi." : "";
        new AlertDialog.Builder(this)
                .setTitle("Poori kitaab audio file main")
                .setMessage("Poori kitaab ki ek Urdu audio file banegi (" + Prefs.voiceLabel(v) + ", "
                        + (piper ? ".m4a" : ".mp3") + "). Bari kitaab main kaafi waqt lagta hai — "
                        + "app band karke bhi chalta rahega (notification main progress)." + note)
                .setPositiveButton("Jagah chunain", (d, w) -> {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(piper ? "audio/mp4" : "audio/mpeg");
                    i.putExtra(Intent.EXTRA_TITLE, book.title + " - HAJI APP" + (piper ? ".m4a" : ".mp3"));
                    startActivityForResult(i, REQ_EXPORT);
                })
                .setNegativeButton("Wapas", null)
                .show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_EXPORT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri out = data.getData();
            ExportService.start(this, book.id, out, exportVoice());
            lastExportResult = null;
            updateExport();
        }
    }

    private void updateExport() {
        if (ExportService.running && book.id.equals(ExportService.bookId)) {
            int pct = ExportService.total == 0 ? 0 : ExportService.done * 100 / ExportService.total;
            exportBtn.setText("MP3 " + pct + "% • rokain");
        } else {
            exportBtn.setText("⬇  Audio Export");
            String r = ExportService.result;
            if (r != null && !r.equals(lastExportResult) && book.id.equals(ExportService.bookId)) {
                lastExportResult = r;
                new AlertDialog.Builder(this).setTitle("MP3 Export").setMessage(r)
                        .setPositiveButton("Theek hai", null).show();
            }
        }
    }

    // ------------------------------------------------------------- list

    private class SegAdapter extends BaseAdapter {
        @Override public int getCount() { return book.count; }
        @Override public Object getItem(int p) { return null; }
        @Override public long getItemId(int p) { return p; }

        @Override
        public View getView(int pos, View v, ViewGroup parent) {
            if (v == null) v = LayoutInflater.from(PlayerActivity.this).inflate(R.layout.item_segment, parent, false);
            TextView tv = (TextView) v;
            String text;
            boolean pending = false;
            if (showUrdu) {
                text = book.cachedSpoken(pos);
                if (text == null) { text = book.original(pos); pending = true; }
            } else {
                text = book.original(pos);
            }
            tv.setText(text);
            if (pos == current) {
                tv.setBackgroundResource(R.drawable.bg_highlight);
                tv.setTextColor(0xFF1E1240);
                tv.setTypeface(null, Typeface.BOLD);
            } else {
                tv.setBackground(null);
                tv.setTextColor(pending ? 0xFFA39DB8 : 0xFF4A4466);
                tv.setTypeface(null, Typeface.NORMAL);
            }
            return tv;
        }
    }
}
