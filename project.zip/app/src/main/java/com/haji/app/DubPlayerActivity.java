package com.haji.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Plays the original video (muted) together with the Urdu dub track, kept in sync. */
public class DubPlayerActivity extends Activity implements SurfaceHolder.Callback {

    private static final int REQ_MP4 = 31, REQ_SRT = 32;

    private DubProject p;
    private MediaPlayer video, dub;
    private boolean ready, playing, originalSound;
    private SeekBar seek;
    private TextView subtitle, timeText;
    private Button playBtn, soundBtn, exportBtn;
    private final Handler h = new Handler(Looper.getMainLooper());
    private String lastResult;

    private final Runnable sync = new Runnable() {
        @Override public void run() {
            if (ready) {
                int pos = video.getCurrentPosition();
                if (playing && !originalSound && dub != null) {
                    int d = dub.getCurrentPosition();
                    if (Math.abs(d - pos) > 250 && pos < dub.getDuration()) dub.seekTo(pos);
                }
                seek.setProgress(pos);
                timeText.setText(t(pos) + " / " + t(video.getDuration()));
                subtitle.setText(lineAt(pos / 1000.0));
            }
            if (DubService.running && p.id.equals(DubService.projectId)) exportBtn.setText("MP4 " + DubService.percent + "% • rokain");
            else {
                exportBtn.setText("⬇  MP4 export");
                String r = DubService.result;
                if (r != null && !r.equals(lastResult)) {
                    lastResult = r;
                    new AlertDialog.Builder(DubPlayerActivity.this).setMessage(r).setPositiveButton("Theek hai", null).show();
                }
            }
            h.postDelayed(this, 300);
        }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try {
            p = DubProject.load(this, getIntent().getStringExtra("id"));
        } catch (Exception e) {
            Toast.makeText(this, "Project nahi khula", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        lastResult = DubService.result;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF140A33);
        TextView title = new TextView(this);
        title.setText(p.title);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(17);
        title.setTypeface(null, Typeface.BOLD);
        title.setPadding(dp(16), dp(36), dp(16), dp(8));
        root.addView(title);
        SurfaceView sv = new SurfaceView(this);
        sv.getHolder().addCallback(this);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1));
        subtitle = new TextView(this);
        subtitle.setTextColor(0xFFFFE082);
        subtitle.setTextSize(18);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(dp(12), dp(8), dp(12), dp(8));
        root.addView(subtitle);
        seek = new SeekBar(this);
        seek.setProgressDrawable(getDrawable(R.drawable.bg_progress));
        seek.setThumb(getDrawable(R.drawable.thumb));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean user) { }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { seekTo(s.getProgress()); }
        });
        root.addView(seek);
        timeText = new TextView(this);
        timeText.setTextColor(0xFFCCC4E8);
        timeText.setGravity(Gravity.CENTER);
        root.addView(timeText);
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setPadding(dp(8), dp(8), dp(8), dp(20));
        playBtn = btn("▶ Play", v -> toggle());
        soundBtn = btn("Asal awaaz", v -> toggleSound());
        exportBtn = btn("⬇  MP4 export", v -> export());
        Button srt = btn("Urdu SRT", v -> saveSrt());
        row.addView(playBtn);
        row.addView(soundBtn);
        row.addView(exportBtn);
        row.addView(srt);
        root.addView(row);
        setContentView(root);
    }

    @Override public void surfaceCreated(SurfaceHolder holder) {
        try {
            video = new MediaPlayer();
            video.setDataSource(this, Uri.parse(p.videoUri));
            video.setDisplay(holder);
            video.setVolume(0f, 0f);
            video.prepare();
            dub = new MediaPlayer();
            dub.setDataSource(p.dubWav().getAbsolutePath());
            dub.prepare();
            seek.setMax(video.getDuration());
            video.setOnCompletionListener(m -> { playing = false; playBtn.setText("▶ Play"); dub.pause(); });
            ready = true;
            h.post(sync);
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle("Video nahi chali")
                    .setMessage("Video file khul nahi saki (shayad move ya delete ho gayi): " + e.getMessage())
                    .setPositiveButton("Theek hai", (d, w) -> finish()).show();
        }
    }

    @Override public void surfaceChanged(SurfaceHolder holder, int f, int w, int hgt) { }

    @Override public void surfaceDestroyed(SurfaceHolder holder) { stop(); }

    private void toggle() {
        if (!ready) return;
        if (playing) {
            video.pause();
            dub.pause();
            playing = false;
            playBtn.setText("▶ Play");
        } else {
            int pos = video.getCurrentPosition();
            if (!originalSound && pos < dub.getDuration()) { dub.seekTo(pos); dub.start(); }
            video.start();
            playing = true;
            playBtn.setText("⏸ Pause");
        }
    }

    private void toggleSound() {
        if (!ready) return;
        originalSound = !originalSound;
        video.setVolume(originalSound ? 1f : 0f, originalSound ? 1f : 0f);
        if (originalSound) dub.pause();
        else if (playing) { dub.seekTo(video.getCurrentPosition()); dub.start(); }
        soundBtn.setText(originalSound ? "Urdu awaaz" : "Asal awaaz");
    }

    private void seekTo(int ms) {
        if (!ready) return;
        video.seekTo(ms);
        if (ms < dub.getDuration()) dub.seekTo(ms);
    }

    private String lineAt(double sec) {
        for (DubProject.Seg s : p.segs) if (sec >= s.start && sec <= s.end + 0.5) return s.urdu;
        return "";
    }

    private void export() {
        if (DubService.running) {
            if (p.id.equals(DubService.projectId)) DubService.cancelled = true;
            else Toast.makeText(this, "Pehle chalti dubbing khatam hone dein", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("video/mp4");
        i.putExtra(Intent.EXTRA_TITLE, p.title + " - Urdu.mp4");
        startActivityForResult(i, REQ_MP4);
    }

    private void saveSrt() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/x-subrip");
        i.putExtra(Intent.EXTRA_TITLE, p.title + " - Urdu.srt");
        startActivityForResult(i, REQ_SRT);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        if (req == REQ_MP4) {
            lastResult = DubService.result;
            DubService.startExport(this, p.id, data.getData());
        } else if (req == REQ_SRT) {
            try (OutputStream os = getContentResolver().openOutputStream(data.getData(), "w")) {
                if (os != null) os.write(p.urduSrt().getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this, "Urdu subtitle save ho gaya", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Save nahi hua: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (playing) toggle();
    }

    private void stop() {
        h.removeCallbacks(sync);
        ready = false;
        playing = false;
        if (video != null) { try { video.release(); } catch (Exception ignored) { } video = null; }
        if (dub != null) { try { dub.release(); } catch (Exception ignored) { } dub = null; }
    }

    @Override
    protected void onDestroy() {
        stop();
        super.onDestroy();
    }

    private static String t(int ms) {
        int s = ms / 1000;
        return String.format(java.util.Locale.US, "%d:%02d", s / 60, s % 60);
    }

    private int dp(float v) { return Ui.dp(this, v); }

    private Button btn(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setOnClickListener(l);
        return b;
    }
}
