package com.haji.app;

import android.content.Context;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** One video dubbing job. The original video is only referenced by its URI and never modified. */
final class DubProject {
    static final class Seg {
        double start, end;
        String text = "", lang = "", urdu = "";
    }

    final String id;
    final File dir;
    String title = "";
    String videoUri = "";
    String subtitleUri = "";
    String speechLang = "";   // "" = auto
    String asrModel = Models.ASR_TINY;
    String voice = Prefs.VOICE_MALE;
    long durationUs;
    long created;
    String status = "new";    // new / working / done / error
    String error = "";
    final List<Seg> segs = new ArrayList<>();

    private DubProject(String id, File dir) { this.id = id; this.dir = dir; }

    static File root(Context c) {
        File r = new File(c.getFilesDir(), "dubs");
        r.mkdirs();
        return r;
    }

    static DubProject create(Context c, Uri video, String title) {
        String id = "d" + System.currentTimeMillis();
        File d = new File(root(c), id);
        d.mkdirs();
        DubProject p = new DubProject(id, d);
        p.videoUri = video.toString();
        p.title = title;
        p.created = System.currentTimeMillis();
        return p;
    }

    static DubProject load(Context c, String id) throws IOException {
        DubProject p = new DubProject(id, new File(root(c), id));
        try {
            JSONObject j = new JSONObject(read(new File(p.dir, "meta.json")));
            p.title = j.optString("title");
            p.videoUri = j.optString("video");
            p.subtitleUri = j.optString("subs");
            p.speechLang = j.optString("speechLang");
            p.asrModel = j.optString("asr", Models.ASR_TINY);
            p.voice = j.optString("voice", Prefs.VOICE_MALE);
            p.durationUs = j.optLong("durationUs");
            p.created = j.optLong("created");
            p.status = j.optString("status", "new");
            p.error = j.optString("error");
            File sf = new File(p.dir, "segs.json");
            if (sf.exists()) {
                JSONArray a = new JSONArray(read(sf));
                for (int i = 0; i < a.length(); i++) {
                    JSONObject o = a.getJSONObject(i);
                    Seg s = new Seg();
                    s.start = o.optDouble("s");
                    s.end = o.optDouble("e");
                    s.text = o.optString("t");
                    s.lang = o.optString("l");
                    s.urdu = o.optString("u");
                    p.segs.add(s);
                }
            }
        } catch (Exception e) {
            throw new IOException("Dubbing project khul nahi saka");
        }
        return p;
    }

    static List<DubProject> listAll(Context c) {
        List<DubProject> out = new ArrayList<>();
        File[] fs = root(c).listFiles();
        if (fs != null) for (File f : fs) {
            if (!new File(f, "meta.json").exists()) continue;
            try { out.add(load(c, f.getName())); } catch (Exception ignored) { }
        }
        Collections.sort(out, (a, b) -> Long.compare(b.created, a.created));
        return out;
    }

    synchronized void save() throws IOException {
        try {
            JSONObject j = new JSONObject();
            j.put("title", title);
            j.put("video", videoUri);
            j.put("subs", subtitleUri);
            j.put("speechLang", speechLang);
            j.put("asr", asrModel);
            j.put("voice", voice);
            j.put("durationUs", durationUs);
            j.put("created", created);
            j.put("status", status);
            j.put("error", error);
            write(new File(dir, "meta.json"), j.toString());
            JSONArray a = new JSONArray();
            for (Seg s : segs) {
                JSONObject o = new JSONObject();
                o.put("s", s.start);
                o.put("e", s.end);
                o.put("t", s.text);
                o.put("l", s.lang);
                o.put("u", s.urdu);
                a.put(o);
            }
            write(new File(dir, "segs.json"), a.toString());
        } catch (org.json.JSONException e) {
            throw new IOException(e.getMessage());
        }
    }

    File dubWav() { return new File(dir, "dub.wav"); }

    /** Deletes only the app's own files for this job (never the user's video). */
    void delete() { Models.rm(dir); }

    String urduSrt() {
        List<Subtitles.Cue> cues = new ArrayList<>();
        for (Seg s : segs) cues.add(new Subtitles.Cue(s.start, s.end, s.urdu));
        return Subtitles.toSrt(cues);
    }

    private static void write(File f, String s) throws IOException {
        File tmp = new File(f.getPath() + ".tmp");
        try (Writer w = new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8)) { w.write(s); }
        if (!tmp.renameTo(f)) throw new IOException("save error");
    }

    static String read(File f) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }
}
