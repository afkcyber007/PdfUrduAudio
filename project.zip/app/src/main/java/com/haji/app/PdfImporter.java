package com.haji.app;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

final class PdfImporter {
    interface Progress {
        void onProgress(String message);
        boolean cancelled();
    }

    private PdfImporter() { }

    static Book importPdf(Context c, Uri uri, String src, Progress p) throws Exception {
        PDFBoxResourceLoader.init(c.getApplicationContext());
        String title = displayName(c, uri);
        File tmp = new File(c.getCacheDir(), "import.pdf");
        try (InputStream in = c.getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(tmp)) {
            if (in == null) throw new Exception("PDF file khul nahi saki");
            byte[] buf = new byte[65536];
            int r;
            while ((r = in.read(buf)) != -1) out.write(buf, 0, r);
        }
        PDDocument doc = null;
        Ocr ocr = null;
        try {
            doc = PDDocument.load(tmp);
            int n = doc.getNumberOfPages();
            List<String> pageTexts = new ArrayList<>();
            PDFTextStripper st = new PDFTextStripper();
            int ocrPages = 0, missing = 0;
            String ocrLangs = Models.ocrLangs(c, src);
            for (int pg = 1; pg <= n; pg++) {
                if (p.cancelled()) throw new Exception("Rok diya gaya");
                st.setStartPage(pg);
                st.setEndPage(pg);
                String t = st.getText(doc);
                if (letters(t) < 15) {
                    // Probably a scanned page: try OCR if the user installed OCR data.
                    if (ocrLangs != null) {
                        if (ocr == null) ocr = new Ocr(c, tmp, ocrLangs);
                        p.onProgress("Scan safha OCR ho raha hai…\nSafha " + pg + " / " + n);
                        String o = ocr.page(pg - 1);
                        if (letters(o) >= 15) { t = o; ocrPages++; } else missing++;
                    } else {
                        missing++;
                    }
                } else if (pg % 5 == 0 || pg == n) {
                    p.onProgress("Kitaab parh rahi hai…\nSafha " + pg + " / " + n);
                }
                pageTexts.add(t);
            }
            if (missing == n) {
                throw new Exception(ocrLangs == null
                        ? "Is PDF main text nahi mila — ye scan (tasveer wali) PDF lagti hai.\n\n"
                          + "Settings → OCR se \"OCR Urdu\" (ya kitaab ki zubaan) download karein, phir dobara shamil karein."
                        : "OCR ke baad bhi text nahi mila. Tasveer saaf nahi ya zubaan ka OCR model ghalat hai.");
            }
            HeaderFooter.strip(pageTexts);

            p.onProgress("Zubaan pehchani ja rahi hai…");
            StringBuilder all = new StringBuilder();
            List<String> clean = new ArrayList<>();
            for (String t : pageTexts) {
                String ct = TextUtil.cleanup(t);
                clean.add(ct);
                if (all.length() < 400_000) all.append(ct).append(' ');
            }
            Lang.DocStats stats = Lang.stats(all);
            List<Book.Seg> segs = new ArrayList<>();
            for (int pg = 0; pg < clean.size(); pg++) {
                for (Lang.Run run : Lang.runs(clean.get(pg), src, stats)) {
                    for (String piece : TextUtil.split(run.text, 250)) segs.add(new Book.Seg(piece, run.lang, pg + 1));
                }
            }
            if (segs.isEmpty()) throw new Exception("Kitaab main parhne layak text nahi mila");
            return Book.create(c, title, n, src, segs, ocrPages, missing);
        } finally {
            if (ocr != null) ocr.close();
            if (doc != null) try { doc.close(); } catch (Exception ignored) { }
            tmp.delete();
        }
    }

    static int letters(String t) {
        if (t == null) return 0;
        int k = 0;
        for (int i = 0; i < t.length(); i++) if (Character.isLetter(t.charAt(i))) k++;
        return k;
    }

    static String displayName(Context c, Uri uri) {
        String name = "Kitaab";
        try (Cursor cur = c.getContentResolver().query(uri, null, null, null, null)) {
            if (cur != null && cur.moveToFirst()) {
                int idx = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0 && cur.getString(idx) != null) name = cur.getString(idx);
            }
        } catch (Exception ignored) { }
        int dot = name.lastIndexOf('.');
        if (dot > 0) name = name.substring(0, dot);
        return name.replace('_', ' ').trim();
    }
}
