package com.haji.app;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

final class PdfImporter {
    interface Progress { void onProgress(int page, int total); }

    private PdfImporter() { }

    static Book importPdf(Context c, Uri uri, Progress p) throws Exception {
        PDFBoxResourceLoader.init(c.getApplicationContext());
        String title = displayName(c, uri);
        File tmp = new File(c.getCacheDir(), "import.pdf");
        try (InputStream in = c.getContentResolver().openInputStream(uri);
             OutputStream out = new FileOutputStream(tmp)) {
            if (in == null) throw new Exception("PDF file khul nahi saki");
            byte[] buf = new byte[65536];
            int r;
            while ((r = in.read(buf)) != -1) out.write(buf, 0, r);
        }
        PDDocument doc = null;
        try {
            doc = PDDocument.load(tmp);
            int n = doc.getNumberOfPages();
            StringBuilder sb = new StringBuilder();
            PDFTextStripper st = new PDFTextStripper();
            for (int s = 1; s <= n; s += 10) {
                int e = Math.min(n, s + 9);
                st.setStartPage(s);
                st.setEndPage(e);
                sb.append(st.getText(doc)).append('\n');
                p.onProgress(e, n);
            }
            String text = TextUtil.cleanup(sb.toString());
            if (text.length() < 20) {
                throw new Exception("Is PDF main parhne layak text nahi mila.\n\n"
                        + "Yeh shayad scan ki hui (tasveer wali) PDF hai — aisi kitaab ko pehle OCR karna hoga.");
            }
            List<String> segs = TextUtil.split(text, 250);
            return Book.create(c, title, n, TextUtil.isUrdu(text), segs);
        } finally {
            if (doc != null) try { doc.close(); } catch (Exception ignored) { }
            tmp.delete();
        }
    }

    static String displayName(Context c, Uri uri) {
        String name = "Kitaab";
        try (Cursor cur = c.getContentResolver().query(uri, null, null, null, null)) {
            if (cur != null && cur.moveToFirst()) {
                int idx = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0 && cur.getString(idx) != null) name = cur.getString(idx);
            }
        } catch (Exception ignored) { }
        if (name.toLowerCase().endsWith(".pdf")) name = name.substring(0, name.length() - 4);
        return name.replace('_', ' ').trim();
    }
}
