package com.haji.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Reads a book aloud, segment by segment, like an audiobook player.
 * All public methods must be called on the main thread.
 */
public class ReaderService extends Service {

    public interface Listener { void onReaderUpdate(); }

    static final String EXTRA_BOOK = "book";
    static final String ACT_OPEN = "com.haji.app.OPEN";
    static final String ACT_TOGGLE = "com.haji.app.TOGGLE";
    static final String ACT_NEXT = "com.haji.app.NEXT";
    static final String ACT_PREV = "com.haji.app.PREV";
    static final String ACT_CLOSE = "com.haji.app.CLOSE";
    static final float[] SPEEDS = {0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f};

    private static final String CHANNEL = "player";
    private static final int NOTIF_ID = 7;

    static ReaderService instance;
    private static final List<Listener> listeners = new ArrayList<>();

    static void addListener(Listener l) { if (!listeners.contains(l)) listeners.add(l); }
    static void removeListener(Listener l) { listeners.remove(l); }

    static void open(Context c, String bookId) {
        Intent i = new Intent(c, ReaderService.class).setAction(ACT_OPEN).putExtra(EXTRA_BOOK, bookId);
        c.startService(i);
    }

    // ---- state read by the UI
    Book book;
    int index;
    boolean playing;
    boolean loading;
    String message;
    float speed = 1f;
    boolean online = true;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newFixedThreadPool(2);
    private final ExecutorService waiter = Executors.newCachedThreadPool();
    private final Map<Integer, Future<File>> audio = new HashMap<>();
    private MediaPlayer mp;
    private boolean mpPaused;
    private TextToSpeech tts;
    private boolean ttsReady;
    private int ttsLang = TextToSpeech.LANG_NOT_SUPPORTED;
    private int gen;
    private volatile boolean destroyed;
    private boolean everPlayed;
    private File audioDir;
    private NotificationManager nm;
    private AudioManager am;
    private SharedPreferences prefs;
    private final Net.Cancel cancel = () -> destroyed;

    private final AudioManager.OnAudioFocusChangeListener focus = change -> {
        if (change == AudioManager.AUDIOFOCUS_LOSS || change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            main.post(this::pause);
        }
    };

    private final BroadcastReceiver noisy = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { pause(); }
    };

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        prefs = getSharedPreferences("haji", MODE_PRIVATE);
        speed = prefs.getFloat("speed", 1f);
        online = prefs.getBoolean("online", true);
        audioDir = new File(getCacheDir(), "audio");
        audioDir.mkdirs();
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Kitaab player",
                    NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        IntentFilter f = new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(noisy, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(noisy, f);
        if (!online) initTts();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent != null ? intent.getAction() : null;
        if (ACT_OPEN.equals(a)) openBook(intent.getStringExtra(EXTRA_BOOK));
        else if (ACT_TOGGLE.equals(a)) toggle();
        else if (ACT_NEXT.equals(a)) next();
        else if (ACT_PREV.equals(a)) prev();
        else if (ACT_CLOSE.equals(a)) close();
        return START_NOT_STICKY;
    }

    // ------------------------------------------------------------- commands

    void openBook(String id) {
        if (id == null) return;
        if (book != null && book.id.equals(id)) { notifyUi(); return; }
        stopAll();
        try {
            book = Book.get(this, id);
            book.segments();
        } catch (Exception e) {
            book = null;
            message = "Kitaab khul nahi saki";
            notifyUi();
            return;
        }
        book.opened = System.currentTimeMillis();
        book.saveMeta();
        prefs.edit().putString("last", id).apply();
        index = Math.max(0, Math.min(book.pos, book.count - 1));
        clearAudio();
        message = null;
        notifyUi();
    }

    void toggle() { if (playing) pause(); else play(); }

    void play() {
        if (book == null || book.count == 0) return;
        if (index >= book.count) index = 0;
        playing = true;
        message = null;
        requestFocus();
        goForeground();
        if (online && mp != null && mpPaused) {
            mpPaused = false;
            try { mp.start(); applySpeed(); } catch (Exception e) { playCurrent(); return; }
            notifyUi();
            return;
        }
        playCurrent();
    }

    void pause() {
        if (!playing) return;
        playing = false;
        loading = false;
        if (mp != null && mp.isPlaying()) {
            mp.pause();
            mpPaused = true;
        } else {
            gen++;
            releasePlayer();
        }
        if (tts != null) tts.stop();
        savePos();
        leaveForeground();
        notifyUi();
    }

    void jumpTo(int i) {
        if (book == null) return;
        index = Math.max(0, Math.min(i, book.count - 1));
        savePos();
        message = null;
        if (playing) {
            playCurrent();
        } else {
            gen++;
            releasePlayer();
            if (tts != null) tts.stop();
            notifyUi();
        }
    }

    void next() { jumpTo(index + 1); }

    void prev() { jumpTo(index - 1); }

    void setSpeed(float s) {
        speed = s;
        prefs.edit().putFloat("speed", s).apply();
        if (online) {
            if (mp != null && mp.isPlaying()) applySpeed();
        } else if (playing) {
            playCurrent();
        }
        notifyUi();
    }

    void setOnline(boolean o) {
        if (o == online) return;
        online = o;
        prefs.edit().putBoolean("online", o).apply();
        gen++;
        releasePlayer();
        if (tts != null) tts.stop();
        if (!online) initTts();
        message = null;
        if (playing) playCurrent();
        notifyUi();
    }

    /** true = book is already Urdu (no translation). */
    void setBookUrdu(boolean u) {
        if (book == null || book.urdu == u) return;
        book.urdu = u;
        book.clearTranslations();
        book.saveMeta();
        gen++;
        releasePlayer();
        clearAudio();
        if (playing) playCurrent();
        notifyUi();
    }

    void close() {
        pause();
        stopAll();
        if (Build.VERSION.SDK_INT >= 24) stopForeground(Service.STOP_FOREGROUND_REMOVE);
        nm.cancel(NOTIF_ID);
        everPlayed = false;
        stopSelf();
    }

    // ------------------------------------------------------------- playback core

    private void playCurrent() {
        gen++;
        final int g = gen;
        releasePlayer();
        if (tts != null) tts.stop();
        if (book == null) return;
        if (index >= book.count) { finished(); return; }
        loading = true;
        savePos();
        notifyUi();
        final int idx = index;
        if (online) {
            final Future<File> f = audioFuture(idx);
            audioFuture(idx + 1);
            audioFuture(idx + 2);
            trimCache();
            waiter.execute(() -> {
                try {
                    final File file = f.get();
                    main.post(() -> startFile(file, g));
                } catch (Exception e) {
                    final String m = rootMessage(e);
                    main.post(() -> { if (g == gen && playing) fail(m); });
                }
            });
        } else {
            final Book b = book;
            waiter.execute(() -> {
                try {
                    final String t = b.urdu(idx, cancel);
                    main.post(() -> speakTts(t, g));
                    if (idx + 1 < b.count) b.urdu(idx + 1, cancel); // translate ahead
                } catch (Exception e) {
                    final String m = rootMessage(e);
                    main.post(() -> { if (g == gen && playing) fail(m); });
                }
            });
        }
    }

    private void startFile(File file, int g) {
        if (g != gen || !playing) return;
        if (file == null) { onSegmentDone(g); return; }
        try {
            releasePlayer();
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
            mp.setDataSource(file.getAbsolutePath());
            mp.setOnCompletionListener(p -> { if (g == gen) onSegmentDone(g); });
            mp.setOnErrorListener((p, what, extra) -> {
                if (g == gen) { file.delete(); onSegmentDone(g); }
                return true;
            });
            mp.prepare();
            mp.start();
            applySpeed();
            loading = false;
            notifyUi();
        } catch (Exception e) {
            file.delete();
            onSegmentDone(g);
        }
    }

    private void speakTts(String text, int g) {
        if (g != gen || !playing) return;
        if (tts == null || !ttsReady) {
            initTts();
            fail("Phone ki awaaz abhi tayyar nahi — dobara ▶ dabayen");
            return;
        }
        if (ttsLang < 0) {
            fail("Is phone main Urdu awaaz install nahi. 'Online' awaaz chunain, ya phone Settings → "
                    + "Text-to-speech main Urdu install karein.");
            return;
        }
        if (text == null || text.trim().isEmpty()) { onSegmentDone(g); return; }
        tts.setSpeechRate(speed);
        List<String> parts = TextUtil.split(text, 1000);
        for (int k = 0; k < parts.size(); k++) {
            boolean last = k == parts.size() - 1;
            tts.speak(parts.get(k), k == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD,
                    new Bundle(), g + "|" + (last ? 1 : 0) + "|" + k);
        }
    }

    private void onSegmentDone(int g) {
        if (g != gen || book == null) return;
        releasePlayer();
        index++;
        if (index >= book.count) { finished(); return; }
        savePos();
        if (playing) playCurrent(); else notifyUi();
    }

    private void finished() {
        index = Math.max(0, book.count - 1);
        playing = false;
        loading = false;
        message = "Kitaab mukammal ho gayi! Mubarak ho";
        savePos();
        leaveForeground();
        notifyUi();
    }

    private void fail(String msg) {
        playing = false;
        loading = false;
        message = msg;
        leaveForeground();
        notifyUi();
    }

    private Future<File> audioFuture(int i) {
        if (book == null || i < 0 || i >= book.count) return null;
        Future<File> f = audio.get(i);
        if (f != null) {
            if (!f.isDone()) return f;
            try { f.get(); return f; } catch (Exception ignored) { /* failed before: retry */ }
        }
        final Book b = book;
        final int idx = i;
        f = pool.submit(() -> buildAudio(b, idx));
        audio.put(i, f);
        return f;
    }

    private File buildAudio(Book b, int idx) throws Exception {
        File out = new File(audioDir, b.id + "_" + idx + ".mp3");
        if (out.exists() && out.length() > 0) return out;
        String t = b.urdu(idx, cancel);
        List<String> parts = TextUtil.split(t, 180);
        if (parts.isEmpty()) return null;
        File tmp = new File(audioDir, b.id + "_" + idx + "_" + Thread.currentThread().getId() + ".part");
        try (FileOutputStream fos = new FileOutputStream(tmp)) {
            for (String p : parts) fos.write(Mp3.clean(Net.ttsRetry(p, cancel)));
        }
        if (!tmp.renameTo(out)) { tmp.delete(); if (!out.exists()) throw new IOException("Cache error"); }
        return out;
    }

    private void trimCache() {
        if (book == null) return;
        Iterator<Map.Entry<Integer, Future<File>>> it = audio.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<Integer, Future<File>> e = it.next();
            int k = e.getKey();
            if (k < index - 1 || k > index + 6) {
                it.remove();
                new File(audioDir, book.id + "_" + k + ".mp3").delete();
            }
        }
    }

    private void clearAudio() {
        audio.clear();
        File[] fs = audioDir.listFiles();
        if (fs != null) for (File f : fs) f.delete();
    }

    private void applySpeed() {
        if (mp == null) return;
        try { mp.setPlaybackParams(mp.getPlaybackParams().setSpeed(speed)); } catch (Exception ignored) { }
    }

    private void releasePlayer() {
        if (mp != null) {
            try { mp.release(); } catch (Exception ignored) { }
            mp = null;
        }
        mpPaused = false;
    }

    private void stopAll() {
        gen++;
        playing = false;
        loading = false;
        releasePlayer();
        if (tts != null) tts.stop();
        savePos();
    }

    private void savePos() {
        if (book != null) { book.pos = index; book.saveMeta(); }
    }

    private void initTts() {
        if (tts != null) return;
        tts = new TextToSpeech(getApplicationContext(), status -> main.post(() -> {
            ttsReady = status == TextToSpeech.SUCCESS && tts != null;
            if (!ttsReady) return;
            ttsLang = tts.setLanguage(new Locale("ur", "PK"));
            if (ttsLang < 0) ttsLang = tts.setLanguage(new Locale("ur"));
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) {
                    main.post(() -> { loading = false; notifyUi(); });
                }
                @Override public void onDone(String id) {
                    String[] p = id.split("\\|");
                    if (p.length >= 2 && "1".equals(p[1])) {
                        final int g = Integer.parseInt(p[0]);
                        main.post(() -> onSegmentDone(g));
                    }
                }
                @Override public void onError(String id) {
                    String[] p = id.split("\\|");
                    if (p.length >= 2 && "1".equals(p[1])) {
                        final int g = Integer.parseInt(p[0]);
                        main.post(() -> onSegmentDone(g));
                    }
                }
            });
        }));
    }

    private void requestFocus() {
        try { am.requestAudioFocus(focus, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN); }
        catch (Exception ignored) { }
    }

    private static String rootMessage(Throwable e) {
        while (e.getCause() != null && e.getCause() != e) e = e.getCause();
        String m = e.getMessage();
        return m == null ? "Kuch ghalat ho gaya — internet check karein" : m;
    }

    // ------------------------------------------------------------- UI + notification

    private void notifyUi() {
        for (Listener l : new ArrayList<>(listeners)) l.onReaderUpdate();
        if (everPlayed && book != null) {
            try { nm.notify(NOTIF_ID, buildNotif()); } catch (Exception ignored) { }
        }
    }

    private void goForeground() {
        everPlayed = true;
        try {
            Notification n = buildNotif();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Exception ignored) { }
    }

    private void leaveForeground() {
        try { stopForeground(Service.STOP_FOREGROUND_DETACH); } catch (Exception ignored) { }
    }

    String statusLine() {
        if (message != null) return message;
        if (loading) return "Awaaz tayyar ho rahi hai…";
        if (book == null) return "";
        return "Hissa " + (index + 1) + " / " + book.count;
    }

    private Notification buildNotif() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        Intent open = new Intent(this, PlayerActivity.class)
                .putExtra(PlayerActivity.EXTRA_ID, book != null ? book.id : "")
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent content = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        b.setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(book != null ? book.title : getString(R.string.app_name))
                .setContentText(statusLine())
                .setSubText(getString(R.string.app_name))
                .setContentIntent(content)
                .setOngoing(playing)
                .setShowWhen(false)
                .setOnlyAlertOnce(true)
                .setColor(0xFF7B2FF7)
                .setVisibility(Notification.VISIBILITY_PUBLIC);
        b.addAction(action(R.drawable.ic_prev, "Pichla", ACT_PREV, 1));
        b.addAction(action(playing ? R.drawable.ic_pause : R.drawable.ic_play,
                playing ? "Rokain" : "Chalayen", ACT_TOGGLE, 2));
        b.addAction(action(R.drawable.ic_next, "Agla", ACT_NEXT, 3));
        b.addAction(action(R.drawable.ic_close, "Band", ACT_CLOSE, 4));
        b.setStyle(new Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2));
        return b.build();
    }

    private Notification.Action action(int icon, String title, String act, int req) {
        PendingIntent pi = PendingIntent.getService(this, req,
                new Intent(this, ReaderService.class).setAction(act),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Action.Builder(Icon.createWithResource(this, icon), title, pi).build();
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        if (!playing) close();
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        destroyed = true;
        instance = null;
        releasePlayer();
        if (tts != null) { try { tts.shutdown(); } catch (Exception ignored) { } tts = null; }
        pool.shutdownNow();
        waiter.shutdownNow();
        try { unregisterReceiver(noisy); } catch (Exception ignored) { }
        try { am.abandonAudioFocus(focus); } catch (Exception ignored) { }
        super.onDestroy();
    }
}
