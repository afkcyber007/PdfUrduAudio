package com.haji.app;

import java.util.ArrayList;
import java.util.List;

/**
 * Language handling for books. Pure Java (no Android) so it can be unit-tested.
 *
 * Rules:
 *  - Text detected as Urdu is NEVER translated or rewritten.
 *  - English / Persian are translated to Urdu.
 *  - Arabic is translated only when the book's source language is Arabic, or when the user turned
 *    on "translate Arabic passages that have no Urdu translation next to them".
 *  - Uncertain text is kept as it is (never deleted or skipped).
 */
final class Lang {
    private Lang() { }

    static final String UR = "ur", EN = "en", AR = "ar", FA = "fa", OTHER = "xx";
    static final String AUTO = "auto";

    static final String[] SOURCES = {UR, EN, AR, FA, AUTO};
    static final String[] SOURCE_LABELS = {
            "Urdu kitaab — tarjuma NAHI, seedha Urdu awaaz",
            "English kitaab — Urdu tarjuma + Urdu awaaz",
            "Arabic kitaab — Urdu tarjuma + Urdu awaaz",
            "Persian kitaab — Urdu tarjuma + Urdu awaaz",
            "Mixed / pata nahi — app khud pehchane"};

    static String label(String code) {
        switch (code == null ? "" : code) {
            case UR: return "Urdu";
            case EN: return "English";
            case AR: return "Arabic";
            case FA: return "Persian";
            case AUTO: return "Auto";
            default: return "Other";
        }
    }

    // ------------------------------------------------------------------ characters

    /** Letters used in Urdu but not in Arabic or Persian. */
    private static final String URDU_ONLY = "ٹڈڑںےۓہھۃ";
    /** Letters / marks that point strongly to Arabic text. */
    private static final String ARABIC_STRONG = "ةىأإ";
    private static final String[] PERSIAN_WORDS = {"است", "را", "این", "آن", "برای", "شده", "بود", "نیست", "هست", "خود", "شد", "اند", "باشد"};

    static boolean isArabicScript(char ch) {
        return (ch >= '؀' && ch <= 'ۿ') || (ch >= 'ݐ' && ch <= 'ݿ')
                || (ch >= 'ࢠ' && ch <= 'ࣿ');
    }

    static boolean isLatin(char ch) {
        return (ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') || (ch >= 'À' && ch <= 'ɏ');
    }

    private static boolean isHaraka(char ch) {
        return (ch >= 'ً' && ch <= 'ْ');
    }

    // ------------------------------------------------------------------ document stats

    static final class DocStats {
        int latin, arabicScript, urduOnly, arabicStrong, harakat, persianWords, zwnj;

        /** Default language for Arabic-script words whose language is unclear. */
        String arabicScriptDefault() {
            if (urduOnly > Math.max(5, arabicScript / 100)) return UR;
            if (persianWords >= 3 && persianWords * 4 > arabicStrong) return FA;
            if (arabicScript > 0) return AR;
            return UR;
        }

        String dominant() {
            if (latin > arabicScript) return EN;
            return arabicScriptDefault();
        }
    }

    static DocStats stats(CharSequence t) {
        DocStats s = new DocStats();
        int n = t.length();
        StringBuilder word = new StringBuilder();
        for (int i = 0; i <= n; i++) {
            char ch = i < n ? t.charAt(i) : ' ';
            if (isLatin(ch)) s.latin++;
            else if (isArabicScript(ch)) {
                s.arabicScript++;
                if (URDU_ONLY.indexOf(ch) >= 0) s.urduOnly++;
                if (ARABIC_STRONG.indexOf(ch) >= 0) s.arabicStrong++;
                if (isHaraka(ch)) s.harakat++;
            } else if (ch == '‌') s.zwnj++;
            if (Character.isWhitespace(ch)) {
                if (word.length() > 0) {
                    String w = word.toString();
                    for (String p : PERSIAN_WORDS) if (p.equals(w)) { s.persianWords++; break; }
                    word.setLength(0);
                }
            } else {
                word.append(ch);
            }
        }
        return s;
    }

    /**
     * True when extracted PDF text looks broken (wrong font encoding): for an Urdu/Arabic/Persian book most
     * letters are not Arabic script, or Latin text is full of accented "mojibake" letters (e.g. ÇáÓáÇã).
     */
    static boolean looksGarbled(String text, String src) {
        int letters = 0, arabic = 0, latin = 0, accented = 0, pua = 0;
        for (int i = 0; i < text.length(); i++) {
            char ch = text.charAt(i);
            if (ch >= '\uE000' && ch <= '\uF8FF') { pua++; continue; }   // private-use glyphs
            if (!Character.isLetter(ch)) continue;
            letters++;
            if (isArabicScript(ch)) arabic++;
            else if (isLatin(ch)) { latin++; if (ch >= '\u00C0') accented++; }
        }
        if (pua > 10 && pua * 2 > letters) return true;
        if (letters < 15) return false;
        if (latin >= 20 && accented * 100 / latin > 30) return true;
        boolean scriptBook = UR.equals(src) || AR.equals(src) || FA.equals(src);
        return scriptBook && arabic * 2 < letters;
    }

    // ------------------------------------------------------------------ word classes

    static final int W_NONE = 0, W_LATIN = 1, W_SCRIPT = 2, W_UR = 3, W_AR = 4;

    static int classifyWord(String w, boolean urduDoc) {
        int latin = 0, arab = 0;
        boolean urOnly = false, haraka = false, arStrong = false, arWeak = false;
        for (int i = 0; i < w.length(); i++) {
            char ch = w.charAt(i);
            if (isLatin(ch)) latin++;
            else if (isArabicScript(ch)) {
                arab++;
                if (URDU_ONLY.indexOf(ch) >= 0) urOnly = true;
                if (isHaraka(ch)) haraka = true;
                if (ARABIC_STRONG.indexOf(ch) >= 0) arStrong = true;
                if (ch == 'ي' || ch == 'ك' || ch == 'ه') arWeak = true; // Arabic yeh, kaf, heh
            }
        }
        if (latin == 0 && arab == 0) return W_NONE;
        if (latin > arab) return W_LATIN;
        if (urOnly) return W_UR;
        if (haraka || arStrong) return W_AR;
        // Many Urdu PDFs use Arabic yeh/kaf/heh code points, so only trust them in non-Urdu documents.
        if (arWeak && !urduDoc) return W_AR;
        return W_SCRIPT;
    }

    // ------------------------------------------------------------------ runs

    static final class Run {
        final String lang;
        final String text;
        Run(String lang, String text) { this.lang = lang; this.text = text; }
        @Override public String toString() { return lang + ":" + text; }
    }

    /**
     * Split text into consecutive runs of one language. The words themselves are never changed.
     *
     * @param src the book's source-language setting (auto/ur/en/ar/fa)
     * @param doc whole-document statistics (used for unclear words)
     */
    static List<Run> runs(String text, String src, DocStats doc) {
        List<Run> out = new ArrayList<>();
        if (text == null || text.trim().isEmpty()) return out;
        String scriptDefault;
        switch (src) {
            case UR: scriptDefault = UR; break;
            case AR: scriptDefault = AR; break;
            case FA: scriptDefault = FA; break;
            default: scriptDefault = doc.arabicScriptDefault();
        }
        boolean urduDoc = UR.equals(scriptDefault);

        String[] words = text.trim().split("\\s+");
        int n = words.length;
        int[] cls = new int[n];
        for (int i = 0; i < n; i++) cls[i] = classifyWord(words[i], urduDoc);

        String[] lab = new String[n];
        for (int i = 0; i < n; i++) {
            switch (cls[i]) {
                case W_LATIN: lab[i] = EN; break;
                case W_UR: lab[i] = UR; break;
                case W_AR:
                    // In an Arabic or Persian book an Arabic-looking word just follows the book.
                    lab[i] = (AR.equals(scriptDefault) || FA.equals(scriptDefault)) ? scriptDefault : AR;
                    break;
                default: lab[i] = null;
            }
        }
        // Unclear Arabic-script words: Arabic only when surrounded by Arabic, else the default.
        for (int i = 0; i < n; i++) {
            if (cls[i] != W_SCRIPT) continue;
            String left = nearestScript(lab, cls, i, -1);
            String right = nearestScript(lab, cls, i, +1);
            if (AR.equals(left) && (AR.equals(right) || right == null)) lab[i] = AR;
            else if (AR.equals(right) && left == null) lab[i] = AR;
            else lab[i] = scriptDefault;
        }
        // Words without letters (numbers, punctuation) join their neighbours.
        String prev = null;
        for (int i = 0; i < n; i++) { if (lab[i] != null) prev = lab[i]; else if (prev != null) lab[i] = prev; }
        String next = null;
        for (int i = n - 1; i >= 0; i--) { if (lab[i] != null) next = lab[i]; else lab[i] = next != null ? next : OTHER; }

        // Very short Arabic runs inside non-Arabic text are usually names/terms → keep with surroundings.
        smooth(lab, AR, 3, scriptDefault);
        // Tiny English bits (1–2 words) inside Arabic-script text stay with the surrounding text.
        smooth(lab, EN, 2, null);

        StringBuilder sb = new StringBuilder();
        String cur = lab[0];
        for (int i = 0; i < n; i++) {
            if (!lab[i].equals(cur)) {
                out.add(new Run(cur, sb.toString()));
                sb.setLength(0);
                cur = lab[i];
            }
            if (sb.length() > 0) sb.append(' ');
            sb.append(words[i]);
        }
        if (sb.length() > 0) out.add(new Run(cur, sb.toString()));
        return out;
    }

    private static String nearestScript(String[] lab, int[] cls, int i, int dir) {
        for (int k = 1; k <= 3; k++) {
            int j = i + dir * k;
            if (j < 0 || j >= lab.length) return null;
            if (cls[j] == W_UR || cls[j] == W_AR) return lab[j];
            if (cls[j] == W_LATIN) return null;
        }
        return null;
    }

    /** Runs of {@code lang} shorter than {@code minLen} words take the label of their neighbours. */
    private static void smooth(String[] lab, String lang, int minLen, String fallback) {
        int n = lab.length;
        int i = 0;
        while (i < n) {
            if (!lab[i].equals(lang)) { i++; continue; }
            int j = i;
            while (j < n && lab[j].equals(lang)) j++;
            int len = j - i;
            String left = i > 0 ? lab[i - 1] : null;
            String right = j < n ? lab[j] : null;
            boolean isWhole = left == null && right == null;
            if (len < minLen && !isWhole) {
                String repl = left != null ? left : right;
                if (repl == null || repl.equals(lang)) repl = fallback;
                if (repl != null) for (int k = i; k < j; k++) lab[k] = repl;
            }
            i = j;
        }
    }

    // ------------------------------------------------------------------ what to do with a segment

    static final int KEEP = 0, TRANSLATE = 1;
    static final String ARABIC_KEEP = "keep";
    static final String ARABIC_TRANSLATE_IF_ALONE = "translate_alone";

    /**
     * @param lang       language of this segment
     * @param src        book source setting
     * @param arabicMode what to do with Arabic passages in non-Arabic books
     * @param nextLangs  languages of the following segments (to see if an Urdu translation follows)
     */
    static int action(String lang, String src, String arabicMode, String... nextLangs) {
        // Urdu book chosen by the user: nothing is ever translated, the text is read exactly as it is.
        if (UR.equals(src)) return KEEP;
        if (UR.equals(lang) || OTHER.equals(lang)) return KEEP;
        if (EN.equals(lang) || FA.equals(lang)) return TRANSLATE;
        if (AR.equals(lang)) {
            if (AR.equals(src)) return TRANSLATE;
            if (ARABIC_TRANSLATE_IF_ALONE.equals(arabicMode)) {
                for (String l : nextLangs) if (UR.equals(l)) return KEEP; // Urdu translation already printed
                return TRANSLATE;
            }
            return KEEP;
        }
        return KEEP;
    }
}
