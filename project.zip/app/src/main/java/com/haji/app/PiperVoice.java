package com.haji.app;

import android.content.Context;

import com.k2fsa.sherpa.onnx.OfflineTts;

import java.io.IOException;

/**
 * Offline Piper voice via sherpa-onnx. Only one voice is kept in memory at a time (~70–100 MB RAM).
 * Calls are serialized because the native engine is not documented as thread-safe.
 */
final class PiperVoice {
    private PiperVoice() { }

    private static OfflineTts tts;
    private static String loaded;
    private static int rate;

    static synchronized float[] synth(Context c, String voice, String text, float speed) throws IOException {
        ensure(c, voice);
        try {
            return SherpaBridge.generate(tts, text, speed);
        } catch (Throwable e) {
            throw new IOException("Offline awaaz ne kaam nahi kiya: " + e.getMessage());
        }
    }

    static synchronized int sampleRate(Context c, String voice) throws IOException {
        ensure(c, voice);
        return rate;
    }

    private static void ensure(Context c, String voice) throws IOException {
        if (tts != null && voice.equals(loaded)) return;
        if (!Models.voiceInstalled(c, voice)) {
            throw new IOException(Prefs.voiceLabel(voice) + " install nahi — Settings → Awaazein se download karein");
        }
        release();
        try {
            int threads = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors() - 1));
            tts = SherpaBridge.createTts(Models.piperModel(c, voice), Models.piperTokens(c, voice),
                    Models.espeakData(c), threads);
            rate = SherpaBridge.sampleRate(tts);
            loaded = voice;
        } catch (Throwable e) {
            tts = null;
            loaded = null;
            throw new IOException("Offline awaaz load nahi hui: " + e.getMessage()
                    + " — Settings main awaaz delete karke dobara download karein");
        }
    }

    static synchronized void release() {
        if (tts != null) {
            try { SherpaBridge.release(tts); } catch (Throwable ignored) { }
        }
        tts = null;
        loaded = null;
    }
}
