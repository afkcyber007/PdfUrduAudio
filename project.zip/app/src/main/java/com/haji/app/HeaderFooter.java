package com.haji.app;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Removes running page headers/footers (same line repeated at the top or bottom of many pages) and
 * bare page numbers. Only the first/last line (2nd line too on long pages) is ever considered, and a line must repeat
 * on at least 3 pages and 30% of pages — so normal content is never removed. Pure Java (unit-tested).
 */
final class HeaderFooter {
    private HeaderFooter() { }

    static String key(String line) {
        return line.replaceAll("[0-9٠-٩۰-۹]+", "#").replaceAll("\\s+", " ").trim();
    }

    static boolean isPageNumber(String line) {
        String t = line.replaceAll("[\\s\\-–—|.()\\[\\]]", "")
                .replace("صفحہ", "").replace("صفحه", "").replace("Page", "").replace("page", "");
        return !t.isEmpty() && t.matches("[0-9٠-٩۰-۹]{1,4}");
    }

    static void strip(List<String> pages) {
        int n = pages.size();
        List<List<String>> lines = new ArrayList<>();
        Map<String, Integer> freq = new HashMap<>();
        for (String p : pages) {
            List<String> ls = new ArrayList<>();
            for (String l : p.split("\\r?\\n")) if (!l.trim().isEmpty()) ls.add(l);
            lines.add(ls);
            java.util.Set<String> seen = new java.util.HashSet<>();
            for (int idx : edgeIdx(ls.size())) {
                String k = key(ls.get(idx));
                if (k.length() >= 2 && k.length() <= 80 && seen.add(k)) freq.put(k, freq.containsKey(k) ? freq.get(k) + 1 : 1);
            }
        }
        int threshold = Math.max(3, (int) Math.ceil(n * 0.3));
        for (int i = 0; i < n; i++) {
            List<String> ls = lines.get(i);
            boolean changed = false;
            List<Integer> edges = edgeIdx(ls.size());
            boolean[] drop = new boolean[ls.size()];
            for (int idx : edges) {
                String l = ls.get(idx);
                Integer f = freq.get(key(l));
                if ((n >= 5 && f != null && f >= threshold) || isPageNumber(l)) { drop[idx] = true; changed = true; }
            }
            if (!changed) continue;
            StringBuilder sb = new StringBuilder();
            for (int k = 0; k < ls.size(); k++) if (!drop[k]) sb.append(ls.get(k)).append('\n');
            // Never empty a page completely because of this.
            if (sb.toString().trim().isEmpty()) continue;
            pages.set(i, sb.toString());
        }
    }

    /** First and last line; the 2nd / 2nd-last line only on long pages (≥ 8 lines). */
    private static List<Integer> edgeIdx(int size) {
        List<Integer> r = new ArrayList<>();
        if (size < 3) return r;               // very short page: never touch
        r.add(0);
        if (size >= 8) r.add(1);
        if (size >= 8) r.add(size - 2);
        r.add(size - 1);
        return r;
    }
}
