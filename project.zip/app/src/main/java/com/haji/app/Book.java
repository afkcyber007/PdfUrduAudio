package com.haji.app;

import android.content.Context;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** A book in the library: its text segments, Urdu translations (cached on disk) and progress. */
final class Book {
    private static final Map<String, Book> CACHE = new HashMap<>();

    final String id;
    final File dir;
    String title = "";
    int pages;
    boolean urdu;      // true = text already Urdu, no translation
    int pos;
    int count;
    long created;
    long opened;

    private List<String> segs;
    private final Map<Integer, String> ur = new ConcurrentHashMap<>();
    private final Object translateLock = new Object();
    private final Object fileLock = new Object();

    private Book(String id, File dir) {
        this.id = id;
        this.dir = dir;
    }

    static File root(Context c) {
        File r = new File(c.getFilesDir(), "books");
        if (!r.exists()) r.mkdirs();
        return r;
    }

    static List<Book> listAll(Context c) {
        List<Book> out = new ArrayList<>();
        File[] dirs = root(c).listFiles();
        if (dirs != null) {
            for (File d : dirs) {
                if (!new File(d, "meta.json").exists()) continue;
                try { out.add(get(c, d.getName())); } catch (Exception ignored) { }
            }
        }
        Collections.sort(out, (a, b) -> Long.compare(Math.max(b.opened, b.created), Math.max(a.opened, a.created)));
        return out;
    }

    static synchronized Book get(Context c, String id) throws IOException {
        Book b = CACHE.get(id);
        if (b != null) return b;
        b = new Book(id, new File(root(c), id));
        b.readMeta();
        CACHE.put(id, b);
        return b;
    }

    static synchronized Book create(Context c, String title, int pages, boolean urdu, List<String> segments)
            throws IOException {
        String id = "b" + System.currentTimeMillis();
        File d = new File(root(c), id);
        d.mkdirs();
        Book b = new Book(id, d);
        b.title = title;
        b.pages = pages;
        b.urdu = urdu;
        b.created = System.currentTimeMillis();
        b.opened = b.created;
        List<String> clean = new ArrayList<>();
        for (String s : segments) {
            String t = clean(s);
            if (!t.isEmpty()) clean.add(t);
        }
        try (Writer w = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(new File(d, "segs.txt")), StandardCharsets.UTF_8))) {
            for (String s : clean) { w.write(s); w.write('\n'); }
        }
        b.segs = clean;
        b.count = clean.size();
        b.saveMeta();
        CACHE.put(id, b);
        return b;
    }

    static String clean(String s) {
        return s == null ? "" : s.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ').trim();
    }

    int percent() {
        return count <= 1 ? 0 : Math.min(100, Math.round(pos * 100f / (count - 1)));
    }

    void delete() {
        synchronized (Book.class) { CACHE.remove(id); }
        File[] fs = dir.listFiles();
        if (fs != null) for (File f : fs) f.delete();
        dir.delete();
    }

    // ------------------------------------------------------------- meta

    private void readMeta() throws IOException {
        try {
            JSONObject j = new JSONObject(readFile(new File(dir, "meta.json")));
            title = j.optString("title", "Kitaab");
            pages = j.optInt("pages");
            urdu = j.optBoolean("urdu");
            pos = j.optInt("pos");
            count = j.optInt("count");
            created = j.optLong("created");
            opened = j.optLong("opened");
        } catch (Exception e) {
            throw new IOException("Kitaab ki maloomat parh nahi saka");
        }
    }

    synchronized void saveMeta() {
        try {
            JSONObject j = new JSONObject();
            j.put("title", title);
            j.put("pages", pages);
            j.put("urdu", urdu);
            j.put("pos", pos);
            j.put("count", count);
            j.put("created", created);
            j.put("opened", opened);
            File tmp = new File(dir, "meta.json.tmp");
            try (Writer w = new OutputStreamWriter(new FileOutputStream(tmp), StandardCharsets.UTF_8)) {
                w.write(j.toString());
            }
            tmp.renameTo(new File(dir, "meta.json"));
        } catch (Exception ignored) { }
    }

    // ------------------------------------------------------------- text

    synchronized List<String> segments() {
        if (segs == null) {
            List<String> list = new ArrayList<>();
            try (BufferedReader r = reader(new File(dir, "segs.txt"))) {
                String line;
                while ((line = r.readLine()) != null) if (!line.isEmpty()) list.add(line);
            } catch (Exception ignored) { }
            File uf = new File(dir, "ur.txt");
            if (uf.exists()) {
                try (BufferedReader r = reader(uf)) {
                    String line;
                    while ((line = r.readLine()) != null) {
                        int tab = line.indexOf('\t');
                        if (tab <= 0) continue;
                        try { ur.put(Integer.parseInt(line.substring(0, tab)), line.substring(tab + 1)); }
                        catch (NumberFormatException ignored) { }
                    }
                } catch (Exception ignored) { }
            }
            segs = list;
            count = list.size();
        }
        return segs;
    }

    String original(int i) {
        List<String> s = segments();
        return i >= 0 && i < s.size() ? s.get(i) : "";
    }

    /** Urdu text if already known, else null. Never blocks on the network. */
    String cachedUrdu(int i) {
        if (urdu) return original(i);
        segments();
        return ur.get(i);
    }

    /** Urdu text for segment i, translating (a batch starting at i) if needed. Blocking. */
    String urdu(int i, Net.Cancel cancel) throws IOException {
        if (urdu) return original(i);
        List<String> s = segments();
        String c = ur.get(i);
        if (c != null) return c;
        synchronized (translateLock) {
            c = ur.get(i);
            if (c != null) return c;
            List<Integer> idx = new ArrayList<>();
            List<String> batch = new ArrayList<>();
            int enc = 0;
            for (int j = i; j < s.size() && batch.size() < 12; j++) {
                if (ur.containsKey(j)) break;
                String t = s.get(j);
                int e = Net.encodedLength(t) + 3;
                if (!batch.isEmpty() && enc + e > 5000) break;
                batch.add(t);
                idx.add(j);
                enc += e;
            }
            List<String> res = Net.translateBatch(batch, cancel);
            for (int k = 0; k < idx.size() && k < res.size(); k++) put(idx.get(k), res.get(k));
        }
        String r = ur.get(i);
        return r == null ? "" : r;
    }

    private void put(int i, String t) {
        t = clean(t);
        ur.put(i, t);
        synchronized (fileLock) {
            try (Writer w = new OutputStreamWriter(new FileOutputStream(new File(dir, "ur.txt"), true),
                    StandardCharsets.UTF_8)) {
                w.write(i + "\t" + t + "\n");
            } catch (Exception ignored) { }
        }
    }

    /** Forget translations (used when the user switches translation on/off). */
    void clearTranslations() {
        ur.clear();
        synchronized (fileLock) { new File(dir, "ur.txt").delete(); }
    }

    private static BufferedReader reader(File f) throws IOException {
        return new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8));
    }

    private static String readFile(File f) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = reader(f)) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }
}
