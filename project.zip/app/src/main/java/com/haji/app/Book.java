package com.haji.app;

import android.content.Context;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * A book in the library: its text segments (each with a language and page), Urdu translations
 * (cached on disk) and reading progress.
 *
 * Files in books/<id>/:
 *   meta.json   title, pages, src (source-language setting), pos …
 *   segs.txt    one segment per line, exactly as extracted (never rewritten)
 *   segmeta.txt "<lang>\t<page>" per segment (v3; rebuilt automatically for v2 books)
 *   tr.txt      "<index>\t<fromLang>\t<engine>\t<urdu text>" cached translations
 */
final class Book {
    private static final Map<String, Book> CACHE = new HashMap<>();

    static final class Seg {
        final String text, lang;
        final int page;
        Seg(String text, String lang, int page) { this.text = text; this.lang = lang; this.page = page; }
    }

    final String id;
    final File dir;
    private final Context app;
    String title = "";
    int pages;
    String src = Lang.AUTO;
    int pos;
    int count;
    long created;
    long opened;
    int ocrPages;
    int missingPages;

    private List<String> segs;
    private String[] langs;
    private int[] segPages;
    private final Map<String, String> tr = new ConcurrentHashMap<>();
    private final Object translateLock = new Object();
    private final Object fileLock = new Object();

    private Book(Context c, String id, File dir) {
        this.app = c.getApplicationContext();
        this.id = id;
        this.dir = dir;
    }

    static File root(Context c) {
        File r = new File(c.getFilesDir(), "books");
        if (!r.exists()) r.mkdirs();
        return r;
    }

    static List<Book> listAll(Context c) {
        List<Book> out = new ArrayList<>();
        File[] dirs = root(c).listFiles();
        if (dirs != null) {
            for (File d : dirs) {
                if (!new File(d, "meta.json").exists()) continue;
                try { out.add(get(c, d.getName())); } catch (Exception ignored) { }
            }
        }
        Collections.sort(out, (a, b) -> Long.compare(Math.max(b.opened, b.created), Math.max(a.opened, a.created)));
        return out;
    }

    static synchronized Book get(Context c, String id) throws IOException {
        Book b = CACHE.get(id);
        if (b != null) return b;
        b = new Book(c, id, new File(root(c), id));
        b.readMeta();
        CACHE.put(id, b);
        return b;
    }

    static synchronized Book create(Context c, String title, int pages, String src, List<Seg> segments,
                                    int ocrPages, int missingPages) throws IOException {
        String id = "b" + System.currentTimeMillis();
        File d = new File(root(c), id);
        d.mkdirs();
        Book b = new Book(c, id, d);
        b.title = title;
        b.pages = pages;
        b.src = src;
        b.ocrPages = ocrPages;
        b.missingPages = missingPages;
        b.created = System.currentTimeMillis();
        b.opened = b.created;
        List<String> texts = new ArrayList<>();
        List<String> ls = new ArrayList<>();
        List<Integer> ps = new ArrayList<>();
        for (Seg s : segments) {
            String t = oneLine(s.text);
            if (t.isEmpty()) continue;
            texts.add(t);
            ls.add(s.lang);
            ps.add(s.page);
        }
        try (Writer w = writer(new File(d, "segs.txt"), false)) {
            for (String s : texts) { w.write(s); w.write('\n'); }
        }
        b.segs = texts;
        b.count = texts.size();
        b.langs = ls.toArray(new String[0]);
        b.segPages = new int[ps.size()];
        for (int i = 0; i < ps.size(); i++) b.segPages[i] = ps.get(i);
        b.writeSegMeta();
        b.saveMeta();
        CACHE.put(id, b);
        return b;
    }

    /** Only newlines/tabs are replaced (storage format); the words themselves are untouched. */
    static String oneLine(String s) {
        return s == null ? "" : s.replace('\n', ' ').replace('\r', ' ').replace('\t', ' ').trim();
    }

    int percent() {
        return count <= 1 ? 0 : Math.min(100, Math.round(pos * 100f / (count - 1)));
    }

    void delete() {
        synchronized (Book.class) { CACHE.remove(id); }
        Models.rm(dir);
    }

    // ------------------------------------------------------------- meta

    private void readMeta() throws IOException {
        try {
            JSONObject j = new JSONObject(readFile(new File(dir, "meta.json")));
            title = j.optString("title", "Kitaab");
            pages = j.optInt("pages");
            if (j.has("src")) src = j.optString("src", Lang.AUTO);
            else src = j.optBoolean("urdu") ? Lang.UR : Lang.AUTO; // v2 book
            pos = j.optInt("pos");
            count = j.optInt("count");
            created = j.optLong("created");
            opened = j.optLong("opened");
            ocrPages = j.optInt("ocrPages");
            missingPages = j.optInt("missingPages");
        } catch (Exception e) {
            throw new IOException("Kitaab ki maloomat parh nahi saka");
        }
    }

    synchronized void saveMeta() {
        try {
            JSONObject j = new JSONObject();
            j.put("title", title);
            j.put("pages", pages);
            j.put("src", src);
            j.put("pos", pos);
            j.put("count", count);
            j.put("created", created);
            j.put("opened", opened);
            j.put("ocrPages", ocrPages);
            j.put("missingPages", missingPages);
            File tmp = new File(dir, "meta.json.tmp");
            try (Writer w = writer(tmp, false)) { w.write(j.toString()); }
            tmp.renameTo(new File(dir, "meta.json"));
        } catch (Exception ignored) { }
    }

    // ------------------------------------------------------------- segments

    synchronized List<String> segments() {
        if (segs == null) {
            List<String> list = new ArrayList<>();
            try (BufferedReader r = reader(new File(dir, "segs.txt"))) {
                String line;
                while ((line = r.readLine()) != null) if (!line.isEmpty()) list.add(line);
            } catch (Exception ignored) { }
            segs = list;
            count = list.size();
            if (!readSegMeta()) recomputeLanguages(); // v2 books or after a source change
            loadTranslations();
        }
        return segs;
    }

    private boolean readSegMeta() {
        File f = new File(dir, "segmeta.txt");
        if (!f.exists()) return false;
        String[] ls = new String[count];
        int[] ps = new int[count];
        int i = 0;
        try (BufferedReader r = reader(f)) {
            String line;
            while ((line = r.readLine()) != null && i < count) {
                int tab = line.indexOf('\t');
                ls[i] = tab > 0 ? line.substring(0, tab) : line;
                try { ps[i] = tab > 0 ? Integer.parseInt(line.substring(tab + 1)) : 0; } catch (NumberFormatException e) { ps[i] = 0; }
                i++;
            }
        } catch (Exception e) {
            return false;
        }
        if (i != count) return false;
        langs = ls;
        segPages = ps;
        return true;
    }

    private void writeSegMeta() {
        try (Writer w = writer(new File(dir, "segmeta.txt"), false)) {
            for (int i = 0; i < langs.length; i++) w.write(langs[i] + "\t" + segPages[i] + "\n");
        } catch (Exception ignored) { }
    }

    /** Language of each segment for the current source setting (dominant run by length). */
    synchronized void recomputeLanguages() {
        List<String> s = segs;
        StringBuilder all = new StringBuilder();
        for (String t : s) { all.append(t).append(' '); if (all.length() > 400_000) break; }
        Lang.DocStats st = Lang.stats(all);
        int[] oldPages = segPages;
        langs = new String[s.size()];
        segPages = new int[s.size()];
        for (int i = 0; i < s.size(); i++) {
            langs[i] = dominant(Lang.runs(s.get(i), src, st));
            segPages[i] = oldPages != null && i < oldPages.length ? oldPages[i] : 0;
        }
        writeSegMeta();
    }

    private static String dominant(List<Lang.Run> runs) {
        String best = Lang.OTHER;
        int bestLen = -1;
        Map<String, Integer> len = new HashMap<>();
        for (Lang.Run r : runs) {
            int v = len.containsKey(r.lang) ? len.get(r.lang) : 0;
            v += r.text.length();
            len.put(r.lang, v);
            if (v > bestLen) { bestLen = v; best = r.lang; }
        }
        return best;
    }

    String original(int i) {
        List<String> s = segments();
        return i >= 0 && i < s.size() ? s.get(i) : "";
    }

    String lang(int i) {
        segments();
        return langs != null && i >= 0 && i < langs.length ? langs[i] : Lang.OTHER;
    }

    int page(int i) {
        segments();
        return segPages != null && i >= 0 && i < segPages.length ? segPages[i] : 0;
    }

    /** KEEP (read the original exactly) or TRANSLATE. */
    int action(int i) {
        String l = lang(i);
        return Lang.action(l, src, Prefs.arabicMode(app), lang(i + 1), lang(i + 2));
    }

    // ------------------------------------------------------------- spoken text

    private String cacheKey(int i) { return i + "|" + lang(i) + "|" + Prefs.trEngine(app); }

    /** Text that will be read aloud, if already known; null if a translation is still needed. */
    String cachedSpoken(int i) {
        if (action(i) == Lang.KEEP) return original(i);
        return tr.get(cacheKey(i));
    }

    /** Text to read aloud for segment i (translating it, and a few following ones, if needed). Blocking. */
    String spoken(int i, Net.Cancel cancel) throws IOException {
        if (action(i) == Lang.KEEP) return original(i);
        String c = tr.get(cacheKey(i));
        if (c != null) return c;
        synchronized (translateLock) {
            c = tr.get(cacheKey(i));
            if (c != null) return c;
            String from = lang(i);
            List<Integer> idx = new ArrayList<>();
            List<String> batch = new ArrayList<>();
            int enc = 0;
            for (int j = i; j < count && batch.size() < 8; j++) {
                if (action(j) != Lang.TRANSLATE || !from.equals(lang(j)) || tr.containsKey(cacheKey(j))) {
                    if (j == i) continue;
                    break;
                }
                String t = original(j);
                int e = Net.encodedLength(t) + 3;
                if (!batch.isEmpty() && enc + e > 5000) break;
                batch.add(t);
                idx.add(j);
                enc += e;
            }
            List<String> res = Translator.toUrdu(app, batch, from, cancel);
            for (int k = 0; k < idx.size() && k < res.size(); k++) put(idx.get(k), from, res.get(k));
        }
        String r = tr.get(cacheKey(i));
        return r == null ? "" : r;
    }

    private void put(int i, String from, String t) {
        t = oneLine(t);
        String engine = Prefs.trEngine(app);
        tr.put(i + "|" + from + "|" + engine, t);
        synchronized (fileLock) {
            try (Writer w = writer(new File(dir, "tr.txt"), true)) {
                w.write(i + "\t" + from + "\t" + engine + "\t" + t + "\n");
            } catch (Exception ignored) { }
        }
    }

    private void loadTranslations() {
        File f = new File(dir, "tr.txt");
        if (!f.exists()) return;
        try (BufferedReader r = reader(f)) {
            String line;
            while ((line = r.readLine()) != null) {
                String[] p = line.split("\t", 4);
                if (p.length == 4) tr.put(p[0] + "|" + p[1] + "|" + p[2], p[3]);
            }
        } catch (Exception ignored) { }
    }

    /** Change the source-language setting; segment languages are recomputed (text is not changed). */
    synchronized void setSource(String newSrc) {
        if (newSrc.equals(src)) return;
        src = newSrc;
        segments();
        recomputeLanguages();
        saveMeta();
    }

    // ------------------------------------------------------------- io helpers

    private static Writer writer(File f, boolean append) throws IOException {
        return new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f, append), StandardCharsets.UTF_8));
    }

    private static BufferedReader reader(File f) throws IOException {
        return new BufferedReader(new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8));
    }

    private static String readFile(File f) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = reader(f)) {
            String line;
            while ((line = r.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }
}
