package com.haji.app;

import android.content.Context;
import android.content.SharedPreferences;

/** All user settings in one place. */
final class Prefs {
    private Prefs() { }

    static final String VOICE_GOOGLE = "google";       // online Google Urdu voice (original, kept as fallback)
    static final String VOICE_PHONE = "phone";         // Android system TTS
    static final String VOICE_MALE = "piper_male";     // offline Piper ur_PK-fasih-medium
    static final String VOICE_FEMALE = "piper_female"; // offline Piper ur_PK-aegis_female-medium

    static final String TR_MLKIT = "mlkit";   // on-device, private
    static final String TR_GOOGLE = "google"; // online, sends text to Google

    static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("haji", Context.MODE_PRIVATE);
    }

    static String voice(Context c) {
        SharedPreferences p = p(c);
        String v = p.getString("voice", null);
        if (v == null) v = p.getBoolean("online", true) ? VOICE_GOOGLE : VOICE_PHONE; // v2 setting
        if ((VOICE_MALE.equals(v) || VOICE_FEMALE.equals(v)) && !Models.voiceInstalled(c, v)) return VOICE_GOOGLE;
        return v;
    }

    static void setVoice(Context c, String v) { p(c).edit().putString("voice", v).apply(); }

    static String voiceLabel(String v) {
        switch (v) {
            case VOICE_PHONE: return "Phone awaaz";
            case VOICE_MALE: return "Urdu Male (offline)";
            case VOICE_FEMALE: return "Urdu Female (offline)";
            default: return "Google (online)";
        }
    }

    static String shortVoiceLabel(String v) {
        switch (v) {
            case VOICE_PHONE: return "Phone";
            case VOICE_MALE: return "Male";
            case VOICE_FEMALE: return "Female";
            default: return "Google";
        }
    }

    static String trEngine(Context c) {
        String e = p(c).getString("tr_engine", TR_MLKIT);
        if (TR_GOOGLE.equals(e) && !googleConsent(c)) return TR_MLKIT;
        return e;
    }

    static void setTrEngine(Context c, String e) { p(c).edit().putString("tr_engine", e).apply(); }

    static boolean googleConsent(Context c) { return p(c).getBoolean("google_consent", false); }

    static void setGoogleConsent(Context c, boolean v) { p(c).edit().putBoolean("google_consent", v).apply(); }

    static String arabicMode(Context c) { return p(c).getString("arabic_mode", Lang.ARABIC_KEEP); }

    static void setArabicMode(Context c, String m) { p(c).edit().putString("arabic_mode", m).apply(); }

    static float speed(Context c) { return p(c).getFloat("speed", 1f); }

    static void setSpeed(Context c, float s) { p(c).edit().putFloat("speed", s).apply(); }
}
