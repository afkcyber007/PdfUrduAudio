package com.haji.app;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;

final class TextUtil {
    private TextUtil() { }

    static String cleanup(String t) {
        // NFKC turns Arabic/Urdu "presentation forms" from PDFs back into normal letters.
        t = Normalizer.normalize(t, Normalizer.Form.NFKC);
        return t.replaceAll("-\\r?\\n", "")
                .replaceAll("[\\u0000-\\u0008\\u000B\\u000C\\u000E-\\u001F\\u200B\\uFEFF]", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    /** Split into pieces of at most {@code max} chars, preferring sentence ends. */
    static List<String> split(String text, int max) {
        List<String> out = new ArrayList<>();
        if (text == null) return out;
        String s = text.trim();
        while (!s.isEmpty()) {
            if (s.length() <= max) { out.add(s); break; }
            int cut = lastIndexOfAny(s, max, ".!?۔؟\n");
            if (cut < max / 3) cut = lastIndexOfAny(s, max, ",،;:؛");
            if (cut < max / 3) cut = s.lastIndexOf(' ', max - 1);
            if (cut < max / 3) cut = max - 1;
            String part = s.substring(0, cut + 1).trim();
            if (!part.isEmpty()) out.add(part);
            s = s.substring(cut + 1).trim();
        }
        return out;
    }

    private static int lastIndexOfAny(String s, int max, String chars) {
        int best = -1;
        for (int i = 0; i < chars.length(); i++) {
            int idx = s.lastIndexOf(chars.charAt(i), max - 1);
            if (idx > best) best = idx;
        }
        return best;
    }

    /** Rough guess: is this text already Urdu (so no translation needed)? */
    static boolean isUrdu(String t) {
        int arabicScript = 0, latin = 0, urduOnly = 0, arabicOnly = 0;
        int n = Math.min(t.length(), 30000);
        for (int i = 0; i < n; i++) {
            char ch = t.charAt(i);
            if ((ch >= '؀' && ch <= 'ۿ') || (ch >= 'ݐ' && ch <= 'ݿ')) arabicScript++;
            else if (Character.isLetter(ch)) latin++;
            if ("ٹڈڑںےۓہھ".indexOf(ch) >= 0) urduOnly++;
            if ("ةيكىأإ".indexOf(ch) >= 0) arabicOnly++;
        }
        return arabicScript > latin && urduOnly > 5 && urduOnly * 3 > arabicOnly;
    }
}
