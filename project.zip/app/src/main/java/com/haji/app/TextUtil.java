package com.haji.app;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;

final class TextUtil {
    private TextUtil() { }

    /**
     * Light cleanup that keeps the original words. Only Arabic/Urdu "presentation form" glyphs that PDFs
     * often contain are mapped back to normal letters (NFKC on those characters only); everything else,
     * including Urdu spelling and ZWNJ, is left exactly as extracted.
     */
    static String cleanup(String t) {
        StringBuilder sb = new StringBuilder(t.length());
        for (int i = 0; i < t.length(); i++) {
            char ch = t.charAt(i);
            if (ch == '\uFEFF' || ch == '\u200B') { sb.append(' '); continue; }
            if ((ch >= '\uFB50' && ch <= '\uFDFF') || (ch >= '\uFE70' && ch <= '\uFEFE')) {
                sb.append(Normalizer.normalize(String.valueOf(ch), Normalizer.Form.NFKC));
            } else {
                sb.append(ch);
            }
        }
        return sb.toString()
                .replaceAll("([A-Za-z])-\\r?\\n([a-z])", "$1$2")
                .replaceAll("[\\u0000-\\u0008\\u000B\\u000C\\u000E-\\u001F]", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    /** Split into pieces of at most {@code max} chars, preferring sentence ends. */
    static List<String> split(String text, int max) {
        List<String> out = new ArrayList<>();
        if (text == null) return out;
        String s = text.trim();
        while (!s.isEmpty()) {
            if (s.length() <= max) { out.add(s); break; }
            int cut = lastIndexOfAny(s, max, ".!?۔؟\n");
            if (cut < max / 3) cut = lastIndexOfAny(s, max, ",،;:؛");
            if (cut < max / 3) cut = s.lastIndexOf(' ', max - 1);
            if (cut < max / 3) cut = max - 1;
            String part = s.substring(0, cut + 1).trim();
            if (!part.isEmpty()) out.add(part);
            s = s.substring(cut + 1).trim();
        }
        return out;
    }

    private static int lastIndexOfAny(String s, int max, String chars) {
        int best = -1;
        for (int i = 0; i < chars.length(); i++) {
            int idx = s.lastIndexOf(chars.charAt(i), max - 1);
            if (idx > best) best = idx;
        }
        return best;
    }
}
