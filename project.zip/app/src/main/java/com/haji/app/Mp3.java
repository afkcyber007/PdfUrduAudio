package com.haji.app;

/**
 * Cleans an MP3 piece so many pieces can be joined into one long file.
 * Removes the ID3 tag and the Xing/Info header frame. That header stores the length of
 * ONE small piece, so players would stop after the first few seconds of a joined file
 * (this was why v1 did not read the whole book).
 */
final class Mp3 {
    private static final int[] BR1 = {0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0};
    private static final int[] BR2 = {0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0};
    private static final int[][] SR = {
            {11025, 12000, 8000}, {0, 0, 0}, {22050, 24000, 16000}, {44100, 48000, 32000}};

    private Mp3() { }

    static byte[] clean(byte[] d) {
        int start = 0;
        if (d.length > 10 && d[0] == 'I' && d[1] == 'D' && d[2] == '3') {
            int size = ((d[6] & 0x7f) << 21) | ((d[7] & 0x7f) << 14) | ((d[8] & 0x7f) << 7) | (d[9] & 0x7f);
            start = 10 + size;
            if ((d[5] & 0x10) != 0) start += 10;
            if (start >= d.length) return new byte[0];
        }
        int i = start;
        while (i + 4 < d.length && !((d[i] & 0xFF) == 0xFF && (d[i + 1] & 0xE0) == 0xE0)) i++;
        if (i + 4 >= d.length) return slice(d, start);
        int len = frameLength(d, i);
        if (len > 0 && i + len <= d.length && hasVbrTag(d, i, len)) i += len;
        return slice(d, i);
    }

    private static int frameLength(byte[] d, int i) {
        int ver = (d[i + 1] >> 3) & 3;
        int layer = (d[i + 1] >> 1) & 3;
        if (layer != 1) return -1;
        int bri = (d[i + 2] >> 4) & 0xF;
        int sri = (d[i + 2] >> 2) & 3;
        int pad = (d[i + 2] >> 1) & 1;
        if (ver == 1 || sri == 3 || bri == 0 || bri == 15) return -1;
        int br = (ver == 3 ? BR1 : BR2)[bri] * 1000;
        int sr = SR[ver][sri];
        return (ver == 3 ? 144 : 72) * br / sr + pad;
    }

    private static boolean hasVbrTag(byte[] d, int i, int len) {
        int end = Math.min(i + len, i + 64);
        for (int k = i + 4; k + 4 <= end; k++) {
            if (is(d, k, 'X', 'i', 'n', 'g') || is(d, k, 'I', 'n', 'f', 'o') || is(d, k, 'V', 'B', 'R', 'I'))
                return true;
        }
        return false;
    }

    private static boolean is(byte[] d, int k, char a, char b, char c, char e) {
        return d[k] == a && d[k + 1] == b && d[k + 2] == c && d[k + 3] == e;
    }

    private static byte[] slice(byte[] d, int from) {
        if (from <= 0) return d;
        byte[] r = new byte[d.length - from];
        System.arraycopy(d, from, r, 0, r.length);
        return r;
    }
}
