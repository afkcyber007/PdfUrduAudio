package com.haji.app;

import android.content.Context;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * Speech for the video dubbing pipeline: returns mono float PCM at a fixed rate for any voice
 * (offline Piper, Google online, or the phone's TTS engine). Must be called off the main thread.
 */
final class Synth {
    static final int RATE = 22050;

    private final Context c;
    private final String voice;
    private final Net.Cancel cancel;
    private final File work;
    private TextToSpeech tts;
    private volatile int ttsStatus = Integer.MIN_VALUE;

    Synth(Context c, String voice, File workDir, Net.Cancel cancel) {
        this.c = c.getApplicationContext();
        this.voice = voice;
        this.cancel = cancel;
        this.work = workDir;
        work.mkdirs();
    }

    boolean canChangeSpeed() { return Prefs.VOICE_MALE.equals(voice) || Prefs.VOICE_FEMALE.equals(voice); }

    float[] speak(String text, float speed) throws IOException {
        if (text == null || text.trim().isEmpty()) return new float[0];
        switch (voice) {
            case Prefs.VOICE_MALE:
            case Prefs.VOICE_FEMALE: {
                float[] pcm = PiperVoice.synth(c, voice, text, speed);
                int r = PiperVoice.sampleRate(c, voice);
                return r == RATE ? pcm : new AudioCodec.Resampler(r, RATE).process(pcm, pcm.length);
            }
            case Prefs.VOICE_PHONE:
                return decode(phoneTts(text));
            default: {
                File mp3 = new File(work, "g.mp3");
                try (FileOutputStream os = new FileOutputStream(mp3)) {
                    for (String p : TextUtil.split(text, 180)) os.write(Mp3.clean(Net.ttsRetry(p, cancel)));
                }
                return decode(mp3);
            }
        }
    }

    private float[] decode(File f) throws IOException {
        final List<float[]> parts = new ArrayList<>();
        final int[] total = {0};
        AudioCodec.decodeFileToMono(f, RATE, (s, n) -> {
            float[] copy = new float[n];
            System.arraycopy(s, 0, copy, 0, n);
            parts.add(copy);
            total[0] += n;
        });
        float[] out = new float[total[0]];
        int o = 0;
        for (float[] p : parts) { System.arraycopy(p, 0, out, o, p.length); o += p.length; }
        return out;
    }

    private File phoneTts(String text) throws IOException {
        if (tts == null) {
            final CountDownLatch init = new CountDownLatch(1);
            tts = new TextToSpeech(c, st -> { ttsStatus = st; init.countDown(); });
            try { init.await(15, TimeUnit.SECONDS); } catch (InterruptedException e) { throw new IOException("cancelled"); }
            if (ttsStatus != TextToSpeech.SUCCESS) throw new IOException("Phone ka TTS engine shuru nahi hua");
            int r = tts.setLanguage(new Locale("ur", "PK"));
            if (r < 0) r = tts.setLanguage(new Locale("ur"));
            if (r < 0) throw new IOException("Phone main Urdu awaaz install nahi — dusri awaaz chunain");
        }
        File out = new File(work, "phone.wav");
        out.delete();
        final CountDownLatch done = new CountDownLatch(1);
        final boolean[] ok = {false};
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { }
            @Override public void onDone(String id) { ok[0] = true; done.countDown(); }
            @Override public void onError(String id) { done.countDown(); }
        });
        tts.setSpeechRate(1.0f);
        tts.synthesizeToFile(text, new Bundle(), out, "dub");
        try {
            if (!done.await(120, TimeUnit.SECONDS)) throw new IOException("Phone TTS ne jawab nahi diya");
        } catch (InterruptedException e) {
            throw new IOException("cancelled");
        }
        if (!ok[0] || out.length() < 100) throw new IOException("Phone TTS se awaaz nahi bani");
        return out;
    }

    void close() {
        if (tts != null) { try { tts.shutdown(); } catch (Exception ignored) { } tts = null; }
    }
}
