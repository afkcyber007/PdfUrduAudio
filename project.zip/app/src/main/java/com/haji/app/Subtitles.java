package com.haji.app;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** SRT / WebVTT parsing and SRT writing. Pure Java (unit-tested). */
final class Subtitles {
    private Subtitles() { }

    static final class Cue {
        double start, end;
        String text;
        Cue(double s, double e, String t) { start = s; end = e; text = t; }
    }

    private static final Pattern TIME = Pattern.compile(
            "((?:\\d+:)?\\d{1,2}:\\d{2}[.,]\\d{1,3})\\s*-->\\s*((?:\\d+:)?\\d{1,2}:\\d{2}[.,]\\d{1,3})");

    static List<Cue> parse(String content) {
        List<Cue> out = new ArrayList<>();
        String[] lines = content.replace("﻿", "").split("\\r?\\n");
        int i = 0;
        while (i < lines.length) {
            Matcher m = TIME.matcher(lines[i]);
            if (!m.find()) { i++; continue; }
            double s = seconds(m.group(1)), e = seconds(m.group(2));
            StringBuilder sb = new StringBuilder();
            i++;
            while (i < lines.length && !lines[i].trim().isEmpty()) {
                if (TIME.matcher(lines[i]).find()) break;
                if (sb.length() > 0) sb.append(' ');
                sb.append(lines[i].replaceAll("<[^>]+>", "").trim());
                i++;
            }
            String t = sb.toString().trim();
            if (!t.isEmpty() && e > s) out.add(new Cue(s, e, t));
        }
        return out;
    }

    static double seconds(String t) {
        t = t.replace(',', '.');
        String[] p = t.split(":");
        double v = 0;
        for (String x : p) v = v * 60 + Double.parseDouble(x);
        return v;
    }

    static String fmt(double sec) {
        long ms = Math.round(sec * 1000);
        return String.format(java.util.Locale.US, "%02d:%02d:%02d,%03d", ms / 3600000, (ms / 60000) % 60, (ms / 1000) % 60, ms % 1000);
    }

    static String toSrt(List<Cue> cues) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < cues.size(); i++) {
            Cue c = cues.get(i);
            sb.append(i + 1).append('\n').append(fmt(c.start)).append(" --> ").append(fmt(c.end)).append('\n')
                    .append(c.text).append("\n\n");
        }
        return sb.toString();
    }
}
