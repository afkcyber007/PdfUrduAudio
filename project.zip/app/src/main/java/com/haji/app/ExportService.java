package com.haji.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** Saves the whole book as ONE Urdu MP3 file, in the background. */
public class ExportService extends Service {

    private static final String CHANNEL = "export";
    private static final int NOTIF_ID = 8;

    static volatile boolean running;
    static volatile boolean cancelled;
    static volatile int done;
    static volatile int total;
    static volatile String bookId = "";
    static volatile String result = null;

    private static volatile boolean workerActive;
    private NotificationManager nm;
    private PowerManager.WakeLock wakeLock;

    static void start(Context c, String bookId, Uri out) {
        Intent i = new Intent(c, ExportService.class)
                .putExtra("book", bookId)
                .putExtra("out", out)
                .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        running = true;
        cancelled = false;
        done = 0;
        total = 0;
        result = null;
        ExportService.bookId = bookId;
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
        else c.startService(i);
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "MP3 export",
                    NotificationManager.IMPORTANCE_LOW));
        }
        Notification n = notif("Shuru ho raha hai…", 0, 0, true);
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(NOTIF_ID, n);

        if (intent == null || workerActive) return START_NOT_STICKY;
        workerActive = true;
        final String id = intent.getStringExtra("book");
        final Uri out = intent.getParcelableExtra("out");
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "HajiApp:export");
        wakeLock.acquire(12 * 60 * 60 * 1000L);
        new Thread(() -> work(id, out), "export").start();
        return START_NOT_STICKY;
    }

    private void work(String id, Uri out) {
        String title = "";
        try {
            Book b = Book.get(this, id);
            title = b.title;
            b.segments();
            total = b.count;
            File cacheDir = new File(getCacheDir(), "audio");
            Net.Cancel c = () -> cancelled;
            try (OutputStream os = getContentResolver().openOutputStream(out, "w")) {
                if (os == null) throw new Exception("MP3 file save nahi ho saki");
                for (int i = 0; i < b.count && !cancelled; i++) {
                    File cached = new File(cacheDir, b.id + "_" + i + ".mp3");
                    if (cached.exists() && cached.length() > 0) {
                        try (InputStream in = new FileInputStream(cached)) {
                            byte[] buf = new byte[16384];
                            int r;
                            while ((r = in.read(buf)) != -1) os.write(buf, 0, r);
                        }
                    } else {
                        String t = b.urdu(i, c);
                        for (String p : TextUtil.split(t, 180)) {
                            if (cancelled) break;
                            os.write(Mp3.clean(Net.ttsRetry(p, c)));
                            Thread.sleep(120);
                        }
                    }
                    done = i + 1;
                    if (i % 3 == 0) nm.notify(NOTIF_ID, notif(title + " — " + percent() + "%", done, total, true));
                }
                os.flush();
            }
            result = cancelled
                    ? "Export rok diya gaya. Jitna bana woh MP3 main save hai."
                    : "MP3 tayyar hai! \"" + title + "\" poori save ho gayi.";
        } catch (Throwable e) {
            result = cancelled ? "Export rok diya gaya." : "Export ruk gaya: " + e.getMessage();
        } finally {
            running = false;
            workerActive = false;
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
            stopForeground(Service.STOP_FOREGROUND_REMOVE);
            nm.notify(NOTIF_ID + 1, notif(result, 0, 0, false));
            stopSelf();
        }
    }

    private int percent() { return total == 0 ? 0 : done * 100 / total; }

    private Notification notif(String text, int d, int t, boolean ongoing) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        b.setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("HAJI APP — MP3 Export")
                .setContentText(text)
                .setContentIntent(pi)
                .setColor(0xFF7B2FF7)
                .setOngoing(ongoing)
                .setOnlyAlertOnce(true);
        if (ongoing) b.setProgress(t, d, t == 0);
        else b.setAutoCancel(true);
        return b.build();
    }

    @Override
    public void onDestroy() {
        cancelled = true;
        super.onDestroy();
    }
}
