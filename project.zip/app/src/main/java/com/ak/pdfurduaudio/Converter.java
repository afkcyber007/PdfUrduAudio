package com.ak.pdfurduaudio;

import android.content.Context;
import android.net.Uri;

import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;

import org.json.JSONArray;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;

/**
 * PDF -> text -> (Urdu translation) -> Urdu speech (MP3).
 * Uses Google Translate's public web endpoints, so internet is required.
 */
public class Converter {

    public interface Listener {
        void onProgress(String message, int done, int total);
        boolean isCancelled();
    }

    private static final String UA =
            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36";
    private static final int TRANSLATE_CHUNK = 700;
    private static final int TTS_CHUNK = 180;

    /** Result of a PDF read. */
    public static class PdfText {
        public String text;
        public int pageCount;
        public int fromPage;
        public int toPage;
    }

    public static PdfText extractText(Context ctx, Uri pdf, int from, int to) throws IOException {
        PDFBoxResourceLoader.init(ctx.getApplicationContext());
        InputStream in = ctx.getContentResolver().openInputStream(pdf);
        if (in == null) throw new IOException("PDF file open nahi ho saki");
        PDDocument doc = null;
        try {
            doc = PDDocument.load(in);
            int n = doc.getNumberOfPages();
            if (from < 1) from = 1;
            if (to < 1 || to > n) to = n;
            if (from > to) from = to;
            PDFTextStripper stripper = new PDFTextStripper();
            stripper.setStartPage(from);
            stripper.setEndPage(to);
            String t = stripper.getText(doc);
            // NFKC turns Arabic/Urdu "presentation forms" back into normal letters.
            t = Normalizer.normalize(t, Normalizer.Form.NFKC);
            t = t.replaceAll("-\\r?\\n", "")
                 .replaceAll("[\\u0000-\\u0008\\u000B\\u000C\\u000E-\\u001F]", " ")
                 .replaceAll("\\s+", " ")
                 .trim();
            PdfText r = new PdfText();
            r.text = t;
            r.pageCount = n;
            r.fromPage = from;
            r.toPage = to;
            return r;
        } finally {
            if (doc != null) try { doc.close(); } catch (Exception ignored) { }
            try { in.close(); } catch (Exception ignored) { }
        }
    }

    /** Main pipeline: translate piece by piece and stream MP3 data straight into {@code out}. */
    public static void convert(String text, boolean alreadyUrdu, OutputStream out, Listener l)
            throws Exception {
        List<String> parts = split(text, TRANSLATE_CHUNK);
        int total = parts.size();
        for (int i = 0; i < total; i++) {
            if (l.isCancelled()) return;
            l.onProgress("Hissa " + (i + 1) + " / " + total
                    + (alreadyUrdu ? " — awaaz ban rahi hai" : " — tarjuma + awaaz"), i, total);
            String urdu = alreadyUrdu ? parts.get(i) : translateWithRetry(parts.get(i), l);
            if (urdu.trim().isEmpty()) continue;
            for (String piece : split(urdu, TTS_CHUNK)) {
                if (l.isCancelled()) return;
                byte[] mp3 = ttsWithRetry(piece, l);
                out.write(stripId3(mp3));
                Thread.sleep(250); // be gentle with the server
            }
            out.flush();
        }
        l.onProgress("Mukammal!", total, total);
    }

    // ---------------------------------------------------------------- splitting

    static List<String> split(String text, int max) {
        List<String> out = new ArrayList<>();
        String s = text.trim();
        while (!s.isEmpty()) {
            if (s.length() <= max) { out.add(s); break; }
            int cut = lastIndexOfAny(s, max, ".!?۔؟\n");
            if (cut < max / 3) cut = lastIndexOfAny(s, max, ",،;:");
            if (cut < max / 3) cut = s.lastIndexOf(' ', max);
            if (cut < max / 3) cut = max - 1;
            String part = s.substring(0, cut + 1).trim();
            if (!part.isEmpty()) out.add(part);
            s = s.substring(cut + 1).trim();
        }
        return out;
    }

    private static int lastIndexOfAny(String s, int max, String chars) {
        int best = -1;
        for (int i = 0; i < chars.length(); i++) {
            int idx = s.lastIndexOf(chars.charAt(i), max - 1);
            if (idx > best) best = idx;
        }
        return best;
    }

    // ---------------------------------------------------------------- network

    static String translate(String text) throws IOException {
        String url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ur&dt=t&q="
                + URLEncoder.encode(text, "UTF-8");
        String json = new String(get(url), "UTF-8");
        try {
            JSONArray root = new JSONArray(json);
            JSONArray sentences = root.optJSONArray(0);
            if (sentences == null) return "";
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < sentences.length(); i++) {
                JSONArray s = sentences.optJSONArray(i);
                if (s != null && !s.isNull(0)) sb.append(s.optString(0, ""));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new IOException("Tarjuma ka jawab samajh nahi aaya");
        }
    }

    static byte[] tts(String text) throws IOException {
        String url = "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=ur&ttsspeed=1"
                + "&total=1&idx=0&textlen=" + text.length()
                + "&q=" + URLEncoder.encode(text, "UTF-8");
        byte[] data = get(url);
        if (data.length < 100) throw new IOException("Awaaz ka data khaali aaya");
        return data;
    }

    private static byte[] get(String urlStr) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(urlStr).openConnection();
        c.setConnectTimeout(20000);
        c.setReadTimeout(30000);
        c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("Referer", "https://translate.google.com/");
        try {
            int code = c.getResponseCode();
            if (code != 200) throw new HttpError(code);
            InputStream in = c.getInputStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int r;
            while ((r = in.read(buf)) != -1) bos.write(buf, 0, r);
            in.close();
            return bos.toByteArray();
        } finally {
            c.disconnect();
        }
    }

    static class HttpError extends IOException {
        final int code;
        HttpError(int code) { super("Server error " + code); this.code = code; }
    }

    private static String translateWithRetry(String t, Listener l) throws Exception {
        IOException last = null;
        for (int attempt = 0; attempt < 5; attempt++) {
            if (l.isCancelled()) return "";
            try { return translate(t); }
            catch (IOException e) { last = e; backoff(e, attempt, l); }
        }
        throw new IOException("Tarjuma fail: " + (last != null ? last.getMessage() : "") +
                " (internet check karein)");
    }

    private static byte[] ttsWithRetry(String t, Listener l) throws Exception {
        IOException last = null;
        for (int attempt = 0; attempt < 5; attempt++) {
            if (l.isCancelled()) return new byte[0];
            try { return tts(t); }
            catch (IOException e) { last = e; backoff(e, attempt, l); }
        }
        throw new IOException("Awaaz banana fail: " + (last != null ? last.getMessage() : "") +
                " (internet check karein)");
    }

    private static void backoff(IOException e, int attempt, Listener l) throws InterruptedException {
        long wait = (e instanceof HttpError && ((HttpError) e).code == 429)
                ? 30000L * (attempt + 1)      // rate limited: wait longer
                : 2000L * (attempt + 1);
        l.onProgress("Network masla, " + (wait / 1000) + " second baad dobara koshish...", -1, -1);
        long end = System.currentTimeMillis() + wait;
        while (System.currentTimeMillis() < end && !l.isCancelled()) Thread.sleep(500);
    }

    /** Remove a leading ID3v2 tag so concatenated MP3 pieces play as one stream. */
    static byte[] stripId3(byte[] d) {
        if (d.length > 10 && d[0] == 'I' && d[1] == 'D' && d[2] == '3') {
            int size = ((d[6] & 0x7f) << 21) | ((d[7] & 0x7f) << 14) | ((d[8] & 0x7f) << 7) | (d[9] & 0x7f);
            int start = 10 + size;
            if (start < d.length) {
                byte[] r = new byte[d.length - start];
                System.arraycopy(d, start, r, 0, r.length);
                return r;
            }
        }
        return d;
    }
}
