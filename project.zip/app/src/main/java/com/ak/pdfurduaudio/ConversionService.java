package com.ak.pdfurduaudio;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import java.io.OutputStream;

/** Runs the conversion in the background so it keeps going with the screen off. */
public class ConversionService extends Service {

    public static final String EXTRA_PDF = "pdf";
    public static final String EXTRA_OUT = "out";
    public static final String EXTRA_FROM = "from";
    public static final String EXTRA_TO = "to";
    public static final String EXTRA_URDU = "urdu";

    private static final String CHANNEL = "conversion";
    private static final int NOTIF_ID = 1;

    // Shared state polled by MainActivity.
    public static volatile boolean running = false;
    public static volatile boolean cancelled = false;
    public static volatile String status = "";
    public static volatile int done = 0;
    public static volatile int total = 0;
    public static volatile boolean finishedOk = false;

    private static volatile boolean workerActive = false;
    private PowerManager.WakeLock wakeLock;
    private NotificationManager nm;

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null || workerActive) return START_NOT_STICKY;
        workerActive = true;
        nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Conversion",
                    NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
        }
        startForeground(NOTIF_ID, buildNotif("Shuru ho raha hai...", 0, 0, true));

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PdfUrduAudio:convert");
        wakeLock.acquire(12 * 60 * 60 * 1000L);

        final Uri pdf = intent.getParcelableExtra(EXTRA_PDF);
        final Uri out = intent.getParcelableExtra(EXTRA_OUT);
        final int from = intent.getIntExtra(EXTRA_FROM, 1);
        final int to = intent.getIntExtra(EXTRA_TO, 0);
        final boolean urdu = intent.getBooleanExtra(EXTRA_URDU, false);

        running = true;
        cancelled = false;
        finishedOk = false;
        done = 0;
        total = 0;
        status = "PDF parh raha hai...";

        new Thread(() -> work(pdf, out, from, to, urdu), "converter").start();
        return START_NOT_STICKY;
    }

    private void work(Uri pdf, Uri out, int from, int to, boolean urdu) {
        try {
            update("PDF se text nikal raha hai...", 0, 0);
            Converter.PdfText pt = Converter.extractText(this, pdf, from, to);
            if (pt.text.length() < 20) {
                throw new Exception("Is PDF main parhne layak text nahi mila (safha "
                        + pt.fromPage + "-" + pt.toPage + "). Shayad yeh scan/tasveer wali PDF hai.");
            }
            try (OutputStream os = getContentResolver().openOutputStream(out, "w")) {
                if (os == null) throw new Exception("MP3 file save nahi ho saki");
                Converter.convert(pt.text, urdu, os, new Converter.Listener() {
                    @Override public void onProgress(String m, int d, int t) { update(m, d, t); }
                    @Override public boolean isCancelled() { return cancelled; }
                });
            }
            if (cancelled) {
                status = "Rok diya gaya. Jitna bana, woh MP3 main save hai.";
            } else {
                finishedOk = true;
                status = "Mukammal! MP3 save ho gayi (safha " + pt.fromPage + "-" + pt.toPage
                        + " / kul " + pt.pageCount + ").";
            }
        } catch (Throwable e) {
            status = "Ghalti: " + e.getMessage();
        } finally {
            running = false;
            workerActive = false;
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
            stopForeground(true);
            nm.notify(NOTIF_ID + 1, buildNotif(status, 0, 0, false));
            stopSelf();
        }
    }

    private void update(String msg, int d, int t) {
        status = msg;
        if (d >= 0) { done = d; total = t; }
        nm.notify(NOTIF_ID, buildNotif(msg, done, total, true));
    }

    private Notification buildNotif(String text, int d, int t, boolean ongoing) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        b.setSmallIcon(R.drawable.ic_stat)
         .setContentTitle("PDF → Urdu MP3")
         .setContentText(text)
         .setContentIntent(pi)
         .setOngoing(ongoing)
         .setOnlyAlertOnce(true);
        if (ongoing) b.setProgress(t, d, t == 0);
        else b.setAutoCancel(true);
        return b.build();
    }

    @Override
    public void onDestroy() {
        cancelled = true;
        super.onDestroy();
    }
}
