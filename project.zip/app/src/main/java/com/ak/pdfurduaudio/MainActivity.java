package com.ak.pdfurduaudio;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_PDF = 1;
    private static final int REQ_SAVE = 2;

    private Uri pdfUri;
    private String pdfName = "book";

    private TextView fileText, statusText;
    private EditText fromEdit, toEdit;
    private CheckBox urduCheck;
    private Button pickBtn, startBtn, stopBtn;
    private ProgressBar progress;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable poller = new Runnable() {
        @Override public void run() {
            refresh();
            handler.postDelayed(this, 500);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fileText = findViewById(R.id.fileText);
        statusText = findViewById(R.id.statusText);
        fromEdit = findViewById(R.id.fromPage);
        toEdit = findViewById(R.id.toPage);
        urduCheck = findViewById(R.id.alreadyUrdu);
        pickBtn = findViewById(R.id.pickBtn);
        startBtn = findViewById(R.id.startBtn);
        stopBtn = findViewById(R.id.stopBtn);
        progress = findViewById(R.id.progress);

        pickBtn.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("application/pdf");
            startActivityForResult(i, REQ_PDF);
        });

        startBtn.setOnClickListener(v -> {
            if (pdfUri == null) {
                Toast.makeText(this, "Pehle PDF chunain", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("audio/mpeg");
            i.putExtra(Intent.EXTRA_TITLE, pdfName + "_urdu.mp3");
            startActivityForResult(i, REQ_SAVE);
        });

        stopBtn.setOnClickListener(v -> ConversionService.cancelled = true);

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(poller);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(poller);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_PDF) {
            pdfUri = uri;
            try {
                getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
            } catch (Exception ignored) { }
            pdfName = displayName(uri);
            fileText.setText("Chuni gayi: " + pdfName + ".pdf");
        } else if (requestCode == REQ_SAVE) {
            Intent s = new Intent(this, ConversionService.class);
            s.putExtra(ConversionService.EXTRA_PDF, pdfUri);
            s.putExtra(ConversionService.EXTRA_OUT, uri);
            s.putExtra(ConversionService.EXTRA_FROM, parse(fromEdit, 1));
            s.putExtra(ConversionService.EXTRA_TO, parse(toEdit, 0));
            s.putExtra(ConversionService.EXTRA_URDU, urduCheck.isChecked());
            s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            ConversionService.running = true; // avoid a double tap before service starts
            ConversionService.status = "Shuru ho raha hai...";
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
        }
    }

    private void refresh() {
        boolean running = ConversionService.running;
        startBtn.setEnabled(!running);
        pickBtn.setEnabled(!running);
        stopBtn.setVisibility(running ? View.VISIBLE : View.GONE);
        progress.setVisibility(running ? View.VISIBLE : View.GONE);
        int t = ConversionService.total;
        if (t > 0) {
            progress.setIndeterminate(false);
            progress.setMax(t);
            progress.setProgress(ConversionService.done);
        } else {
            progress.setIndeterminate(true);
        }
        String s = ConversionService.status;
        statusText.setText(s == null || s.isEmpty() ? "" : s);
    }

    private int parse(EditText e, int def) {
        try { return Integer.parseInt(e.getText().toString().trim()); }
        catch (Exception ex) { return def; }
    }

    private String displayName(Uri uri) {
        String name = "book";
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = c.getString(idx);
            }
        } catch (Exception ignored) { }
        if (name.toLowerCase().endsWith(".pdf")) name = name.substring(0, name.length() - 4);
        return name;
    }
}
