# HAJI APP 3.0 — upgrade notes

Base: HAJI APP 2.0 (Java, Android framework UI, PDFBox-Android, Google online TTS, phone TTS).
Everything from 2.0 is kept: library, reader with highlighting, speed, Google voice, phone voice,
background playback, resume position, full-book export.

## Files
Modified: settings.gradle, build.gradle, app/build.gradle, AndroidManifest.xml, Book.java, ExportService.java,
MainActivity.java, Net.java, PdfImporter.java, PlayerActivity.java, ReaderService.java, TextUtil.java,
layout/activity_main.xml, layout/activity_player.xml
Added: Lang, Prefs, Translator, Models, DownloadService, SettingsActivity, PiperVoice, SherpaBridge.kt,
AudioCodec, HeaderFooter, Ocr, Subtitles, Synth, DubProject, DubService, DubActivity, DubPlayerActivity,
app/libs/ (CI puts the sherpa-onnx AAR here), ci/build-apk.yml, tests/
Removed: none (TextUtil.isUrdu replaced by Lang; Book "urdu" flag migrated to "src")

## New dependencies
| Library | Version | License | Source |
|---|---|---|---|
| sherpa-onnx (Piper TTS, Whisper ASR, Silero VAD) | 1.13.7 AAR | Apache-2.0 | github.com/k2-fsa/sherpa-onnx releases (downloaded by CI) |
| Google ML Kit Translate | 17.0.3 | Free, proprietary (ML Kit terms) | Google Maven |
| Tesseract4Android | 4.9.0 | Apache-2.0 | JitPack |
| Kotlin Android plugin | 1.9.24 | Apache-2.0 | (only for the sherpa bridge) |

## Downloadable models (only on user request, Settings)
| Model | Size | License | URL |
|---|---|---|---|
| Urdu Male `ur_PK-fasih-medium` | 63.5 MB onnx | MIT | huggingface.co/rhasspy/piper-voices (converted+tested by CI → release voices-v1) |
| Urdu Female `ur_PK-aegis_female-medium` | 63.5 MB onnx | MIT | same |
| espeak-ng-data (needed by Piper) | 6.9 MB (bz2) | GPL-3.0 | sherpa-onnx tts-models release |
| Whisper tiny (int8) | 12.9 + 89.9 + 0.8 MB | MIT | huggingface.co/csukuangfj/sherpa-onnx-whisper-tiny |
| Whisper base (int8) | 29.1 + 130.7 + 0.8 MB | MIT | huggingface.co/csukuangfj/sherpa-onnx-whisper-base |
| Silero VAD | ~0.6 MB | MIT | sherpa-onnx asr-models release |
| Tesseract urd / ara / fas / eng (fast) | urd 1.33 MB; others ~0.5–4 MB | Apache-2.0 | github.com/tesseract-ocr/tessdata_fast |
| ML Kit ur / en / ar / fa / hi | ~30 MB each | ML Kit terms | Google (via ML Kit API) |

## Language rules (Lang.java)
- Source selector: Auto/Mixed, Urdu, English, Arabic, Persian. Target is always Urdu.
- Text is split into word-level language runs; Urdu runs are stored and read exactly as extracted.
- English/Persian → translated. Arabic → translated only for Arabic books, or (setting) when no Urdu
  translation follows it. Default in Urdu books: Arabic is read as-is, nothing is added twice.
- Unknown text is kept, never deleted or skipped.
- Translation default is on-device (ML Kit). Online Google Translate only after an explicit consent dialog.

## Tests run in the build environment (no Android SDK available there)
- All Java sources type-checked against API stubs: 0 errors (found and fixed a Map key-type bug).
- tests/LangTest: 32/32 passed (Urdu kept, Urdu+Quran+Urdu split, Persian, Arabic, English, Urdu written
  with Arabic code points, policy actions).
- tests/LogicTest: 22/22 passed (header/footer removal, SRT/VTT parsing, resampler, WAV writer, Urdu text
  unchanged by cleanup, presentation-form normalization, OCR line de-dup).
- Not testable here: Gradle/Kotlin build, on-device behaviour, sherpa/ML Kit/Tesseract at runtime.
  CI (ci/build-apk.yml) converts both Piper voices and synthesizes an Urdu test sentence with each one;
  the job fails if the audio is silent or too short. Sample WAVs are attached to the voices-v1 release.

## Known limitations
- YouTube: official API only lets a video's owner download captions; no audio download is allowed. The app
  does not download from YouTube; it explains this and offers the local-video path (+ optional SRT/VTT).
- Whisper tiny/base are weak on Urdu speech; the base model is better but slower. Long videos take long.
- ML Kit Arabic/Persian → Urdu quality is limited (likely via English internally; not documented).
- Urdu Nastaliq OCR with Tesseract makes many mistakes; it works better on Naskh fonts.
- Dubbing: no lip sync; each sentence starts at its original time; offline voices are sped up (max 1.6x)
  if a sentence is longer than its slot. The original background audio is not mixed in.
- MP4 export copies the original video track; formats the phone's muxer can't write stay playback-only.
- Offline voices export as .m4a (Android has no built-in MP3 encoder); Google voice export stays .mp3.
