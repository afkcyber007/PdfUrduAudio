package com.haji.app;
import java.util.*;
public class LangTest {
  static int fail=0, pass=0;
  static void check(String name, boolean ok, Object info){ if(ok) pass++; else { fail++; System.out.println("FAIL "+name+" -> "+info);} }
  static String sig(List<Lang.Run> r){ StringBuilder b=new StringBuilder(); for(Lang.Run x:r) b.append(x.lang).append(','); return b.toString(); }
  static String join(List<Lang.Run> r){ StringBuilder b=new StringBuilder(); for(Lang.Run x:r){ if(b.length()>0)b.append(' '); b.append(x.text);} return b.toString(); }
  static void runCase(String name, String text, String src, String docText, String expectSig){
    Lang.DocStats st = Lang.stats(docText==null?text:docText);
    List<Lang.Run> r = Lang.runs(text, src, st);
    check(name+" sig", sig(r).equals(expectSig), sig(r)+"  "+r);
    check(name+" text-preserved", join(r).equals(text.trim().replaceAll("\\s+"," ")), join(r));
  }
  public static void main(String[] a){
    String urdu = "یہ کتاب بچوں کے لیے لکھی گئی ہے اور اس میں بہت سی اچھی باتیں ہیں۔";
    String urduBook = urdu + " " + urdu + " " + urdu;
    runCase("pure urdu auto", urdu, "auto", urduBook, "ur,");
    runCase("pure urdu src=ur", urdu, "ur", null, "ur,");
    String quran = "إِنَّ اللَّهَ مَعَ الصَّابِرِينَ";
    String mixed = "اللہ تعالیٰ فرماتا ہے: " + quran + " یعنی بے شک اللہ صبر کرنے والوں کے ساتھ ہے۔";
    runCase("urdu+quran auto", mixed, "auto", urduBook+" "+mixed, "ur,ar,ur,");
    runCase("urdu+quran src=ur", mixed, "ur", null, "ur,ar,ur,");
    runCase("urdu+quran src=ar", mixed, "ar", null, "ur,ar,ur,");
    String eng = "Patience is the key to success, and every good book teaches it.";
    runCase("english auto", eng, "auto", null, "en,");
    runCase("urdu with PDF word", "یہ PDF فائل بہت اچھی ہے اور میں نے پڑھی ہے", "auto", urduBook, "ur,");
    String arabic = "الحمد لله رب العالمين الرحمن الرحيم مالك يوم الدين إياك نعبد وإياك نستعين";
    runCase("arabic auto", arabic, "auto", arabic+" "+arabic, "ar,");
    String persian = "این کتاب برای کودکان نوشته شده است و خواندن آن بسیار مفید است را";
    runCase("persian auto", persian, "auto", persian+" "+persian, "fa,");
    runCase("persian src=fa", persian, "fa", null, "fa,");
    runCase("en+ur", eng + " " + urdu, "auto", urduBook+" "+eng, "en,ur,");
    // Urdu written with Arabic yeh/kaf code points (common in PDFs) must stay Urdu
    String urduArabicCodes = "يہ كتاب بچوں كے ليے لكھی گئی ہے";
    runCase("urdu w/ arabic codepoints", urduArabicCodes, "auto", urduBook, "ur,");
    // actions
    check("act ur keep", Lang.action("ur","auto","keep")==Lang.KEEP, "");
    check("act en tr", Lang.action("en","ur","keep")==Lang.TRANSLATE, "");
    check("act fa tr", Lang.action("fa","auto","keep")==Lang.TRANSLATE, "");
    check("act ar keep default", Lang.action("ar","ur","keep","ur")==Lang.KEEP, "");
    check("act ar in ar book", Lang.action("ar","ar","keep")==Lang.TRANSLATE, "");
    check("act ar alone translate", Lang.action("ar","auto","translate_alone","en","ar")==Lang.TRANSLATE, "");
    check("act ar followed by urdu keep", Lang.action("ar","auto","translate_alone","ur")==Lang.KEEP, "");
    check("act other keep", Lang.action("xx","auto","keep")==Lang.KEEP, "");
    System.out.println("passed="+pass+" failed="+fail);
  }
}
