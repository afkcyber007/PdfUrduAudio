package com.haji.app;
import java.util.*; import java.io.*;
public class LogicTest {
  static int pass=0, fail=0;
  static void check(String n, boolean ok, Object info){ if(ok) pass++; else { fail++; System.out.println("FAIL "+n+" -> "+info);} }
  public static void main(String[] a) throws Exception {
    // Header/footer
    List<String> pages = new ArrayList<>();
    String[] words = {"نماز","روزہ","زکوٰۃ","حج","صبر","شکر","علم","عمل","اخلاق","دعا"};
    for (int i=1;i<=10;i++) pages.add("کتاب الصلوٰۃ\nیہ "+words[i-1]+" کے بارے میں اصل متن ہے جو باقی رہنا چاہیے۔\n"+words[i-1]+" کی دوسری اہم سطر۔\n- "+i+" -");
    List<String> shortRep = new ArrayList<>(); for (int i=0;i<10;i++) shortRep.add("ایک ہی سطر\nدوسری ایک ہی سطر");
    HeaderFooter.strip(pages);
    check("header removed", !pages.get(3).contains("کتاب الصلوٰۃ"), pages.get(3));
    check("page number removed", !pages.get(3).contains("- 4 -"), pages.get(3));
    check("content kept", pages.get(3).contains("یہ حج کے بارے میں اصل متن ہے") && pages.get(3).contains("حج کی دوسری اہم سطر۔"), pages.get(3));
    HeaderFooter.strip(shortRep);
    check("short repeated pages untouched", shortRep.get(5).contains("ایک ہی سطر") && shortRep.get(5).contains("دوسری ایک ہی سطر"), shortRep.get(5));
    List<String> few = new ArrayList<>(Arrays.asList("Same title\nreal text one\nmore", "Same title\nreal text two\nmore2"));
    HeaderFooter.strip(few);
    check("short doc untouched", few.get(0).contains("Same title"), few.get(0));
    // Subtitles
    String srt = "1\n00:00:01,000 --> 00:00:03,500\nHello <i>world</i>\n\n2\n00:00:04,000 --> 00:00:06,000\nSecond line\nwrapped\n\n";
    List<Subtitles.Cue> cs = Subtitles.parse(srt);
    check("srt count", cs.size()==2, cs.size());
    check("srt times", Math.abs(cs.get(0).start-1.0)<1e-6 && Math.abs(cs.get(0).end-3.5)<1e-6, cs.get(0).start+" "+cs.get(0).end);
    check("srt tags stripped", cs.get(0).text.equals("Hello world"), cs.get(0).text);
    check("srt multiline", cs.get(1).text.equals("Second line wrapped"), cs.get(1).text);
    String vtt = "WEBVTT\n\n00:01.000 --> 00:02.500\nVTT short form\n\n01:00:00.000 --> 01:00:02.000\nhour\n";
    List<Subtitles.Cue> vs = Subtitles.parse(vtt);
    check("vtt parse", vs.size()==2 && Math.abs(vs.get(1).start-3600)<1e-6, vs.size());
    String out = Subtitles.toSrt(cs);
    check("srt roundtrip", Subtitles.parse(out).size()==2 && out.contains("00:00:01,000 --> 00:00:03,500"), out);
    // Resampler 48k -> 16k, chunked
    AudioCodec.Resampler rs = new AudioCodec.Resampler(48000, 16000);
    int n=48000; float[] sig=new float[n]; for(int i=0;i<n;i++) sig[i]=(float)Math.sin(2*Math.PI*440*i/48000.0);
    int total=0; float maxJump=0; float prev=Float.NaN;
    for (int off=0; off<n; off+=1000) { int len=Math.min(1000,n-off); float[] ch=Arrays.copyOfRange(sig,off,off+len);
       float[] o=rs.process(ch,len); for(float v:o){ if(!Float.isNaN(prev)) maxJump=Math.max(maxJump,Math.abs(v-prev)); prev=v; } total+=o.length; }
    check("resample length ~16000", Math.abs(total-16000)<=3, total);
    check("resample smooth", maxJump < 0.2f, maxJump);  // 440Hz at 16k: max step ~0.17
    AudioCodec.Resampler up = new AudioCodec.Resampler(16000, 22050);
    float[] o2 = up.process(new float[16000], 16000);
    check("upsample length", Math.abs(o2.length-22050)<=3, o2.length);
    // WAV
    File f = File.createTempFile("tst",".wav"); AudioCodec.writeWav(f, new float[]{0f,0.5f,-0.5f,1f}, 22050);
    byte[] w = java.nio.file.Files.readAllBytes(f.toPath());
    check("wav size", w.length==44+8, w.length);
    check("wav riff", w[0]=='R'&&w[8]=='W'&&w[36]=='d', "");
    int rate = (w[24]&0xff)|((w[25]&0xff)<<8)|((w[26]&0xff)<<16);
    check("wav rate", rate==22050, rate);
    File g = File.createTempFile("sil",".wav");
    try (RandomAccessFile raf = AudioCodec.createSilentWav(g, 1000, 22050)) { AudioCodec.writeAt(raf, 990, new float[20]); }
    check("silent wav length fixed", g.length()==44+2000, g.length());
    // TextUtil: Urdu preserved byte-for-byte; presentation forms normalized
    String urdu = "یہ کتاب اللّٰہ کے نام سے شروع ہوتی ہے۔ ‌ می‌خواهم";
    check("urdu unchanged", TextUtil.cleanup(urdu).equals(urdu.replaceAll("\\s+"," ").trim()), TextUtil.cleanup(urdu));
    String pres = "ﻟﻠﻪ"; // presentation forms of لله (lam lam heh)
    check("presentation forms", TextUtil.cleanup(pres).equals("لله"), TextUtil.cleanup(pres));
    check("english hyphenation", TextUtil.cleanup("exam-\nple text").equals("example text"), TextUtil.cleanup("exam-\nple text"));
    // OCR dedupe
    check("ocr dedupe", Ocr.dedupeLines("a\na\nb\n\nb\nc").equals("a\nb\nc\n"), Ocr.dedupeLines("a\na\nb\n\nb\nc"));
    System.out.println("passed="+pass+" failed="+fail);
  }
}
