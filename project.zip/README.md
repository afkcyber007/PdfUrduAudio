# HAJI APP 3.0 — PDF kitaabein aur videos, Urdu awaaz main

- PDF (English / Arabic / Urdu / Persian / mixed) → Urdu main parh kar sunati hai; Urdu text kabhi tabdeel nahi hota
- Awaazein: Google (online), Urdu Male + Female (offline Piper), phone TTS
- Tarjuma phone par (ML Kit, offline) ya online Google (sirf ijazat ke baad)
- Scan PDF ke liye OCR (Tesseract)
- Video → Urdu dubbing (local video + Whisper ya subtitle file), in-app player, MP4 export
- Saare bare models Settings se apni marzi par download / delete

Build: GitHub Actions (`ci/build-apk.yml`). Tafseel: UPGRADE_NOTES.md
