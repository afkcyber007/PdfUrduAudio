# HAJI APP — PDF kitaab, Urdu awaaz main

- English / Arabic / Urdu PDF → Urdu main parh kar sunati hai (audiobook player ki tarah)
- Jo hissa parha ja raha hai woh highlight hota hai; kisi bhi hisse par tap karke wahan se sunain
- Speed 0.75x – 2x, Online (Google Urdu) ya Phone ki awaaz
- Screen band ho to bhi chalti rahe, notification se Play/Pause/Agla
- Jahan chhora tha wahin se dobara shuru
- Poori kitaab ki ek MP3 export

Build: GitHub Actions `gradle assembleDebug` (project.zip unzip karke). Signing key `app/haji.p12`
fixed hai taake nayi build purani ke upar update ho sake.
